"""Coordinates two outbound agents; never shells into servers or runs engines."""
from __future__ import annotations

import concurrent.futures
import contextlib
import ipaddress
import secrets
import threading
import time

from .common import PronetError, clean, inbound_ports, secret, utc
from .model import PROFILES, ranking


SCREEN_BATCH = 8          # the agent accepts at most 8 carriers per batch
SOAK_BATCH = 3
REACH_SECONDS = 20


def dialer(plan):
    """Which server opens the carrier connection."""
    spec = PROFILES[plan["profile"]]
    if spec["kind"] == "reverse":
        return "foreign"
    if spec["kind"] == "direct":
        return "iran"
    return "iran" if plan.get("direction", "iran-dials") == "iran-dials" else "foreign"


def screen_batches(plans, size=SCREEN_BATCH):
    """Group carriers that tend to be blocked together into the same batch.

    A batch waits for its slowest member, and a filtered carrier always uses
    the whole reachability window. Keeping UDP/QUIC carriers and carriers that
    Iran dials apart from the usual TCP carriers dialed from abroad lets the
    batches that work finish without that wait. Every carrier is still tested.
    """
    def group(plan):
        if PROFILES[plan["profile"]]["family"] in ("udp", "icmp"):
            return 2
        return 0 if dialer(plan) == "foreign" else 1
    batches = []
    for key in (0, 1, 2):
        members = [plan for plan in plans if group(plan) == key]
        batches += [members[i:i + size] for i in range(0, len(members), size)]
    return batches


class Controller:
    def __init__(self, store, stop_event=None):
        self.store = store
        self.stop = stop_event or threading.Event()
        self.running = set()
        self.busy_nodes = set()
        self.mutex = threading.Lock()

    def rpc(self, pair, node, op, payload, step, timeout=125, on_progress=None):
        if self.store.pair(pair["id"]).get("desired", "run") == "stop" and op != "cleanup":
            raise PronetError("Operator requested a stop; further setup operations were canceled")
        job = self.store.enqueue(pair["id"], node, op, payload, step)
        deadline = time.monotonic() + timeout
        seen, next_check = None, 0
        while time.monotonic() < deadline and not self.stop.is_set():
            result = self.store.job_result(job)
            if result is not None:
                if not result["ok"]:
                    raise PronetError(result.get("error", "Node operation failed"))
                return result.get("data", {})
            if on_progress and time.monotonic() >= next_check:
                next_check = time.monotonic() + .5
                with contextlib.suppress(Exception):
                    progress = self.store.job_progress(job)
                    if progress and progress != seen:
                        seen = progress
                        on_progress(progress)
            self.stop.wait(.2)
        raise PronetError("Node did not complete " + op + " within the bounded timeout")

    def both(self, pair, op, payloads, step, timeout=125):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = {role: pool.submit(self.rpc, pair, pair["iran" if role == "iran" else "foreign_node"],
                                        op, payloads[role], step + ":" + role, timeout)
                       for role in ("iran", "foreign")}
            results, errors = {}, []
            for role, future in futures.items():
                try:
                    results[role] = future.result()
                except Exception as error:
                    errors.append(role + ": " + clean(error))
            if errors:
                raise PronetError("; ".join(errors))
            return results

    def allocate(self, pair, inventories):
        request = pair["request"]
        used_ports = set(inventories["iran"]["ports"]) | set(inventories["foreign"]["ports"])
        used_ports.update(inventories["iran"]["ssh_ports"])
        used_ports.update(inventories["foreign"]["ssh_ports"])
        used_ports.update(inbound_ports(request))
        networks = []
        for info in inventories.values():
            for text in info["routes"] + info["reserved_subnets"]:
                try:
                    network = ipaddress.ip_network(text)
                    if network.prefixlen:
                        networks.append(network)
                except ValueError:
                    pass
        # Never allocate a fixed service port inside a node's ephemeral range:
        # outgoing connections (thousands of user sessions through the
        # gateway/bridge) borrow those ports, and a carrier or helper that
        # restarts later fails with EADDRINUSE on exactly the busiest servers.
        ephemeral = []
        for info in inventories.values():
            try:
                low, high = (int(x) for x in info.get("ephemeral_range", (32768, 60999)))
                if 1 <= low <= high <= 65535:
                    ephemeral.append((low, high))
            except (TypeError, ValueError):
                ephemeral.append((32768, 60999))
        def outside_ephemeral(value):
            return not any(low <= value <= high for low, high in ephemeral)
        def choose_port(control=False):
            common = [443, 8443, 9443, 22443] if control else []
            for value in common:
                if value not in used_ports:
                    used_ports.add(value)
                    return value
            for strict in (True, False):
                for _ in range(400):
                    value = 20000 + secrets.randbelow(45000)
                    if value not in used_ports and (not strict or outside_ephemeral(value)):
                        used_ports.add(value)
                        return value
            raise PronetError("Could not reserve a free port")
        def choose_subnet():
            for pool in ("10.244.0.0/16", "172.29.0.0/16", "192.168.240.0/20"):
                pool = ipaddress.ip_network(pool)
                for _ in range(128):
                    offset = secrets.randbelow(pool.num_addresses // 4) * 4
                    candidate = ipaddress.ip_network((int(pool.network_address) + offset, 30))
                    if not any(candidate.overlaps(existing) for existing in networks):
                        networks.append(candidate)
                        return str(candidate)
            raise PronetError("No collision-free tunnel subnet was found")
        plans = []
        for profile in request["profiles"]:
            if PROFILES[profile]["kind"] == "l3" and not all(info["tun"] for info in inventories.values()):
                continue
            token, subnet = secret(), choose_subnet()
            plan = {"pair_id": pair["id"], "profile": profile, "token": token, "subnet": subnet,
                    "iran_ip": pair["iran_info"]["public_ip"], "foreign_ip": pair["foreign_info"]["public_ip"],
                    "control_port": choose_port(True), "echo_port": choose_port(), "health_port": choose_port(),
                    "data_port": choose_port(), "inbound_port": request["inbound_port"],
                    "inbound_ports": inbound_ports(request),
                    "gateway_bind_ip": request["bind_ip"], "gateway_public_ip": request["public_ip"],
                    "bridge_data_port": choose_port(), "bridge_health_port": choose_port(), "probe_front_port": choose_port(),
                    "direction": PROFILES[profile].get("direction", request["direction"]), "sni": request.get("sni", ""),
                    "test_quality": request.get("quality", "balanced")}
            plans.append(plan)
        if not plans:
            raise PronetError("No selected profile can run with these capabilities")
        return plans

    def live(self, pair, result, names=(), **fields):
        """Per-carrier live state for the progress view (display only)."""
        carriers = result.setdefault("live", {}).setdefault("carriers", {})
        now = time.time()
        for name in names:
            row = carriers.setdefault(name, {})
            if "stage" in fields and fields["stage"] != row.get("stage"):
                row["since"] = now
                row.pop("phase", None)
                row.pop("pct", None)
            row.update(fields)
        with contextlib.suppress(Exception):
            self.store.set_live(pair["id"], result["live"])

    def live_progress(self, pair, result, stage):
        def apply(progress):
            carriers = result.setdefault("live", {}).setdefault("carriers", {})
            for name, row in progress.items():
                if name in carriers and carriers[name].get("stage") == stage:
                    carriers[name].update(phase=row.get("phase"), pct=row.get("pct"))
            with contextlib.suppress(Exception):
                self.store.set_live(pair["id"], result["live"])
        return apply

    def payloads(self, pair, plan):
        return {role: dict(plan, role=role, bind_ip=pair[role + "_info"]["bind_ip"]) for role in ("iran", "foreign")}

    def process(self, pair_id):
        pair = self.store.pair(pair_id)
        result = {"phase": "preflight", "results": [], "warnings": [], "timing": {"started": time.time()}}
        try:
            if pair["state"] != "PAIRED":
                raise PronetError("Hub restarted during setup; safely retire the interrupted setup and create a fresh pairing")
            self.store.update_pair(pair_id, "PREFLIGHT", result)
            info = self.both(pair, "inventory", {"iran": {}, "foreign": {}}, "inventory")
            from . import __version__
            versions = {role: inventory.get("version", "older than 0.2.5") for role, inventory in info.items()}
            if any(version != __version__ for version in versions.values()):
                raise PronetError("Version mismatch (coordinator %s, iran %s, foreign %s). Run the installer on both servers, then create a new pairing."
                                  % (__version__, versions["iran"], versions["foreign"]))
            for role, inventory in info.items():
                if not inventory["systemd"] or not inventory["iptables"] or inventory["arch"] not in ("amd64", "arm64"):
                    raise PronetError(role + ": requires Linux amd64/arm64, systemd, and iptables tools")
                if inventory.get("unresolved_raw_engines"):
                    raise PronetError(role + ": an unmanaged raw tunnel has unknown ports; import or inspect it before installing new carriers")
                if inventory.get("firewall_readable") is False:
                    raise PronetError(role + ": firewall could not be inspected; setup stopped before changes")
            from .runtime import endpoint_occupied, endpoint_has_nat
            client_ports = inbound_ports(pair["request"])
            for number in client_ports:
                if endpoint_occupied(info["iran"], pair["request"]["bind_ip"], number):
                    raise PronetError("Iran public port %d is already occupied; no existing listener was stopped" % number)
            if pair["request"]["bind_ip"] not in info["iran"]["ips"]:
                raise PronetError("Iran gateway IP is not assigned to the host")
            for number in client_ports:
                if endpoint_has_nat(info["iran"], pair["request"]["bind_ip"], number):
                    raise PronetError("An existing DNAT/REDIRECT rule already owns public port %d; it was left unchanged" % number)
                if number in info["iran"]["ssh_ports"] + info["foreign"]["ssh_ports"]:
                    raise PronetError("The requested inbound port %d is used for SSH" % number)
            plans = self.allocate(pair, info)
            running = set()
            total = len(plans)
            batches = screen_batches(plans)
            result["progress"] = {"tested": 0, "total": total, "passed": 0}
            result["live"] = {"phase": "screen", "order": [plan["profile"] for batch in batches for plan in batch],
                              "batches": len(batches), "carriers": {}}
            for plan in plans:
                result["live"]["carriers"][plan["profile"]] = {"stage": "waiting"}
            self.store.update_pair(pair_id, "TRIAL", dict(result, phase="measuring"))
            for batch_index, batch in enumerate(batches):
                if self.stop.is_set():
                    return
                result["live"]["batch"] = batch_index + 1
                self.screen_batch(pair, batch, batch_index, result, running)
                keep = {row["profile"] for row in ranking(result["results"], 1)}
                retire = sorted(running - keep)
                if retire:
                    self.both(pair, "retire_batch", {"iran": {"profiles": retire}, "foreign": {"profiles": retire}},
                              "retire-screen:" + str(batch_index))
                    running.difference_update(retire)
                result["progress"] = {"tested": len(result["results"]), "total": total,
                                      "passed": sum(1 for row in result["results"] if row.get("passed"))}
                self.store.update_pair(pair_id, "TRIAL", dict(result, phase="measuring"))
            screened = ranking(result["results"], all_results=True)
            # Qualify a sufficiently good different carrier family before a
            # second near-identical path; otherwise stopping after two passes
            # silently defeats ranking()'s standby diversity policy.
            preferred = ranking(result["results"], pair["request"]["standby"])
            preferred_names = {row["profile"] for row in preferred}
            screened = preferred + [row for row in screened if row["profile"] not in preferred_names]
            qualified = []
            candidates = screened[:5]
            needed = 1 + pair["request"]["standby"]
            repetitions = 3 if pair["request"].get("quality") == "thorough" else 1
            result["live"] = {"phase": "soak", "order": [row["profile"] for row in candidates], "carriers": {}}
            for row in candidates:
                result["live"]["carriers"][row["profile"]] = {"stage": "waiting"}
            self.store.update_pair(pair_id, "TRIAL", dict(result, phase="longer-test"))
            index = 0
            while index < len(candidates) and len(qualified) < needed and not self.stop.is_set():
                chunk = candidates[index:index + SOAK_BATCH]
                label = "soak-batch:" + str(index)
                index += len(chunk)
                names = [row["profile"] for row in chunk]
                chunk_plans = {name: next(plan for plan in plans if plan["profile"] == name) for name in names}
                self.live(pair, result, names, stage="starting")
                try:
                    started = self.both(pair, "start_batch", {role: {"plans": [self.payloads(pair, chunk_plans[n])[role] for n in names]}
                                                              for role in ("iran", "foreign")}, label + ":start")
                except Exception as error:
                    started = {role: {"profiles": {n: {"error": clean(error)} for n in names}} for role in ("iran", "foreign")}
                running.update(names)
                observations = {name: [] for name in names}
                active = []
                for name in names:
                    replies = [started[role].get("profiles", {}).get(name, {}) for role in ("iran", "foreign")]
                    errors = [r.get("error") for r in replies if not isinstance(r, dict) or r.get("error") or not r.get("started")]
                    if errors:
                        observations[name].append({"profile": name, "passed": False, "echo_ms": [], "success_ratio": 0,
                                                   "error": errors[0] or "start failed", "stage": "start"})
                    else:
                        active.append(name)
                for repetition in range(repetitions):
                    if not active:
                        break
                    self.live(pair, result, active, stage="measuring", run=repetition + 1, runs=repetitions)
                    budget = 80 + REACH_SECONDS + 10
                    measured = self.rpc(pair, pair["iran"], "benchmark_batch",
                                        {"plans": [self.payloads(pair, dict(chunk_plans[n], long_test=True))["iran"] for n in active]},
                                        label + ":" + str(repetition), timeout=60 + budget * len(active),
                                        on_progress=self.live_progress(pair, result, "measuring")).get("profiles", {})
                    for name in active:
                        observations[name].append(measured.get(name) or {"profile": name, "passed": False, "echo_ms": [],
                                                                         "success_ratio": 0, "error": "no result", "stage": "soak"})
                    active = [name for name in active if observations[name][-1].get("passed")]
                for name in names:
                    rows = observations[name]
                    soaked = dict(rows[-1])
                    soaked["passed"] = len(rows) == repetitions and all(row.get("passed") for row in rows)
                    soaked["qualification_runs"] = len(rows)
                    if soaked["passed"]:
                        soaked["echo_ms"] = [sample for row in rows for sample in row["echo_ms"]]
                        soaked["upload_mbps"] = min(row["upload_mbps"] for row in rows)
                        soaked["download_mbps"] = min(row["download_mbps"] for row in rows)
                    soaked["observations"] = rows
                    for row in candidates:
                        if row["profile"] == name: row["soak"] = soaked
                    for row in result["results"]:
                        if row["profile"] == name: row["soak"] = soaked
                    if soaked["passed"]:
                        qualified.append(soaked)
                    self.live(pair, result, [name], stage="qualified" if soaked["passed"] else "failed")
                keep = {row["profile"] for row in ranking(qualified, 1)}
                retire = sorted(running - keep)
                if retire:
                    self.both(pair, "retire_batch", {"iran": {"profiles": retire}, "foreign": {"profiles": retire}}, label + ":retire")
                    running.difference_update(retire)
                self.store.update_pair(pair_id, "TRIAL", dict(result, phase="longer-test"))
            winners = ranking(qualified, pair["request"]["standby"])
            if not winners:
                raise PronetError("No profile passed all integrity, idle, half-close and reachability tests. This is not proof that every possible network path is blocked.")
            selected = [row["profile"] for row in winners]
            result.pop("live", None)
            result.update(phase="committing", selected=selected, active=selected[0])
            self.store.update_pair(pair_id, "STAGED", result)
            self.both(pair, "commit", {"iran": {"profiles": selected}, "foreign": {"profiles": selected}}, "commit")
            self.store.update_pair(pair_id, "VERIFYING", dict(result, phase="verifying"))
            winner = next(plan for plan in plans if plan["profile"] == selected[0])
            proof = self.rpc(pair, pair["iran"], "benchmark", self.payloads(pair, winner)["iran"], "post-commit")
            if not proof.get("passed"):
                raise PronetError("Winner did not pass after permanent service activation")
            active = self.both(pair, "activate", {"iran": {}, "foreign": {}}, "activate")
            if active["foreign"].get("inbound") != "open":
                result["warnings"].append("Tunnel is active, but the foreign inbound port is not open. Install/configure the node before client use.")
            if active["iran"].get("tls") not in ("verified", "not-configured"):
                result["warnings"].append("TLS could not be verified with the configured SNI; inspect the foreign inbound and certificate.")
            result["warnings"].append("An authenticated WS/XHTTP client session through the public Iran address has not been tested automatically.")
            result["timing"]["finished"] = time.time()
            result["inbound"] = active["foreign"].get("inbound", "unknown")
            result.update(phase="complete", endpoint=f"{pair['request']['public_ip']}:" + ",".join(str(x) for x in client_ports))
            self.store.update_pair(pair_id, "ACTIVE", result)
        except Exception as error:
            result["timing"]["finished"] = time.time()
            result.update(phase="rollback", error=clean(error))
            self.store.update_pair(pair_id, "ROLLING_BACK", result)
            self.store.cancel_pending(pair_id)
            try:
                self.both(pair, "cleanup", {"iran": {}, "foreign": {}}, "rollback", timeout=70)
            except Exception as cleanup_error:
                result["warnings"].append("Cleanup unconfirmed: " + clean(cleanup_error) + ". Temporary services expire; inspect committed services locally.")
            result["phase"] = "failed"
            self.store.update_pair(pair_id, "FAILED", result)

    def screen_batch(self, pair, batch, number, result, running):
        """Screen several carriers together.

        Preparing and starting a batch costs two round trips instead of two per
        carrier, and reachability is awaited IN PARALLEL on the Iran agent, so
        filtered carriers fail together within one short window. The reachable
        carriers are then measured in one job: throughput transfers still run
        strictly one at a time, so no number is shared between carriers; only
        latency samples and idle waits overlap.
        """
        label = "batch-" + str(number)
        names = [plan["profile"] for plan in batch]
        def failed(profile, reason, stage):
            result["results"].append({"profile": profile, "passed": False, "error": clean(reason), "stage": stage})
            self.live(pair, result, [profile], stage="failed")
        self.live(pair, result, names, stage="preparing")
        try:
            prepared = self.both(pair, "prepare_batch", {role: {"plans": [self.payloads(pair, plan)[role] for plan in batch]}
                                                         for role in ("iran", "foreign")}, label + ":prepare")
        except Exception as error:
            for name in names:
                failed(name, error, "prepare")
            running.update(names)
            return
        startable = []
        for plan in batch:
            replies = [prepared[role].get("profiles", {}).get(plan["profile"], {}) for role in ("iran", "foreign")]
            errors = [r.get("error") for r in replies if not isinstance(r, dict) or r.get("error") or not r.get("prepared")]
            if errors:
                failed(plan["profile"], errors[0] or "prepare failed", "prepare")
                running.add(plan["profile"])
                continue
            for field in ("server_cert", "server_fingerprint", "server_noise_public_key"):
                if field in replies[0]:
                    plan[field] = replies[0][field]
            startable.append(plan)
        if not startable:
            return
        self.live(pair, result, [plan["profile"] for plan in startable], stage="starting")
        try:
            started = self.both(pair, "start_batch", {role: {"plans": [self.payloads(pair, plan)[role] for plan in startable]}
                                                      for role in ("iran", "foreign")}, label + ":start")
        except Exception as error:
            for plan in startable:
                failed(plan["profile"], error, "start")
            running.update(plan["profile"] for plan in startable)
            return
        live = []
        for plan in startable:
            running.add(plan["profile"])
            replies = [started[role].get("profiles", {}).get(plan["profile"], {}) for role in ("iran", "foreign")]
            errors = [r.get("error") for r in replies if not isinstance(r, dict) or r.get("error") or not r.get("started")]
            if errors:
                failed(plan["profile"], errors[0] or "start failed", "start")
            else:
                live.append(plan)
        if not live:
            return
        self.live(pair, result, [plan["profile"] for plan in live], stage="connecting", window=REACH_SECONDS)
        try:
            probe = self.rpc(pair, pair["iran"], "probe_batch", {"profiles": [plan["profile"] for plan in live],
                                                                  "seconds": REACH_SECONDS}, label + ":reach",
                             timeout=REACH_SECONDS + 60, on_progress=self.live_progress(pair, result, "connecting"))
        except Exception as error:
            for plan in live:
                failed(plan["profile"], error, "reach")
            return
        reachable = []
        for plan in live:
            reach = probe.get("profiles", {}).get(plan["profile"], {})
            if not reach.get("reachable"):
                failed(plan["profile"], reach.get("reason", "unreachable"), "reach")
            else:
                reachable.append((plan, reach))
        if not reachable:
            return
        l3 = {plan["profile"] for plan, _ in reachable if PROFILES[plan["profile"]]["kind"] == "l3"}
        self.live(pair, result, [plan["profile"] for plan, _ in reachable], stage="measuring")
        budget = 70 + REACH_SECONDS + 10
        try:
            measured = self.rpc(pair, pair["iran"], "benchmark_batch",
                                {"plans": [self.payloads(pair, plan)["iran"] for plan, _ in reachable]},
                                label + ":measure", timeout=60 + budget * len(reachable),
                                on_progress=self.live_progress(pair, result, "measuring")).get("profiles", {})
        except Exception as error:
            for plan, _ in reachable:
                failed(plan["profile"], error, "benchmark")
            return
        reverse_needed = [plan for plan, _ in reachable if plan["profile"] in l3 and measured.get(plan["profile"], {}).get("passed")]
        reverse = {}
        if reverse_needed:
            # L3 carriers must also work when the foreign server starts the flow.
            self.live(pair, result, [plan["profile"] for plan in reverse_needed], stage="reverse")
            try:
                reverse = self.rpc(pair, pair["foreign_node"], "benchmark_batch",
                                   {"plans": [self.payloads(pair, plan)["foreign"] for plan in reverse_needed]},
                                   label + ":reverse", timeout=60 + budget * len(reverse_needed),
                                   on_progress=self.live_progress(pair, result, "reverse")).get("profiles", {})
            except Exception as error:
                reverse = {plan["profile"]: {"passed": False, "error": clean(error)} for plan in reverse_needed}
        for plan, reach in reachable:
            name = plan["profile"]
            row = measured.get(name)
            if not isinstance(row, dict):
                failed(name, "benchmark result missing", "benchmark")
                continue
            if name in l3 and row.get("passed"):
                row["reverse_passed"] = bool(reverse.get(name, {}).get("passed"))
                row["passed"] = row["reverse_passed"]
                if not row["passed"]:
                    row["reason"] = "reverse direction (foreign to Iran) failed"
            row["reach_ms"] = reach.get("rtt_ms")
            result["results"].append(row)
            self.live(pair, result, [name], stage="passed" if row.get("passed") else "failed")

    def recover(self, pair_id, pause_id):
        pair = self.store.pair(pair_id)
        result = pair["result"]
        old = result.get("selected", [])
        now = time.time()
        starts = [stamp for stamp in result.get("recovery_starts", [])
                  if type(stamp) in (int, float) and now - 1800 <= stamp <= now]
        if starts:
            # Different pause IDs must not reset the cross-episode work budget.
            result["recovery"] = {"handled_pause_id": pause_id, "state": "cooldown",
                                  "attempted": [], "retry_after": starts[-1] + 1800}
            self.store.update_pair(pair_id, "ACTIVE", result)
            return
        result["recovery_starts"] = starts + [now]
        recovery = {"handled_pause_id": pause_id, "state": "trying", "attempted": []}
        result["recovery"] = recovery
        # Persist the episode before starting anything. A hub restart does not
        # turn one bounded recovery budget into an unlimited retry loop.
        self.store.update_pair(pair_id, "ACTIVE", result)

        prefix = "recovery:" + pause_id + ":"
        passed = ranking(result.get("results", []), all_results=True)
        profiles = [row["profile"] for row in passed if row["profile"] not in old]
        profiles += [profile for profile in old if profile not in profiles]
        for index, profile in enumerate(profiles[:3]):
            if self.stop.is_set(): return
            recovery["attempted"].append(profile)
            commit_attempted = False
            try:
                self.both(pair, "resume", {"iran": {"profile": profile}, "foreign": {"profile": profile}}, prefix + profile + ":resume")
                proof = self.rpc(pair, pair["iran"], "remeasure", {"profile": profile}, prefix + profile + ":measure")
                if not proof.get("passed"): raise PronetError("Recovery candidate did not pass a real transfer")
                selection = [profile] + [item for item in old if item != profile][:1]
                commit_attempted = True
                self.both(pair, "commit", {"iran": {"profiles": selection, "automatic": True},
                                          "foreign": {"profiles": selection, "automatic": True}}, prefix + profile + ":commit")
                self.both(pair, "activate", {"iran": {}, "foreign": {}}, prefix + profile + ":activate")
                recovery.update(state="recovered", active=profile)
                result.update(selected=selection, active=profile)
                self.store.update_pair(pair_id, "ACTIVE", result)
                return
            except Exception as error:
                recovery.setdefault("errors", []).append(profile + ": " + clean(error))
                if commit_attempted and old:
                    try:
                        for restore in old:
                            self.both(pair, "resume", {"iran": {"profile": restore}, "foreign": {"profile": restore}}, prefix + profile + ":restore:" + restore)
                        self.both(pair, "commit", {"iran": {"profiles": old}, "foreign": {"profiles": old}}, prefix + profile + ":restore-commit")
                        self.both(pair, "activate", {"iran": {}, "foreign": {}}, prefix + profile + ":restore-activate")
                    except Exception as restore_error:
                        recovery.setdefault("errors", []).append("Restore unconfirmed: " + clean(restore_error))
                        recovery["state"] = "restore-unconfirmed"
                        self.store.update_pair(pair_id, "ACTIVE", result)
                        return
                if profile not in old:
                    try:
                        self.both(pair, "retire", {"iran": {"profile": profile}, "foreign": {"profile": profile}}, prefix + profile + ":retire", timeout=70)
                    except Exception as retire_error:
                        recovery.setdefault("errors", []).append(clean(retire_error))
            self.store.update_pair(pair_id, "ACTIVE", result)
        recovery["state"] = "exhausted"
        self.store.update_pair(pair_id, "ACTIVE", result)

    def stop_pair(self, pair_id):
        pair = self.store.pair(pair_id)
        result = pair["result"]
        request_id = result.get("stop_request", "initial")
        try:
            if pair["foreign_node"] is None:
                result["phase"] = "stopped-before-pairing"
            else:
                self.both(pair, "cleanup", {"iran": {}, "foreign": {}}, "operator-stop:" + request_id, timeout=125)
                result["phase"] = "stopped-both-ends"
            self.store.update_pair(pair_id, "STOPPED", result)
        except Exception as error:
            result.update(phase="stop-unconfirmed", error=clean(error))
            self.store.update_pair(pair_id, "STOP_UNCONFIRMED", result)

    def launch(self, pair_id, recovery_pause=None):
        pair = self.store.pair(pair_id)
        members = {pair["iran"], pair["foreign_node"]}
        with self.mutex:
            if pair_id in self.running or len(self.running) >= 4 or self.busy_nodes & members:
                return
            self.running.add(pair_id)
            self.busy_nodes.update(members)
        def work():
            try:
                if self.store.pair(pair_id).get("desired") == "stop":
                    self.stop_pair(pair_id)
                elif recovery_pause:
                    self.recover(pair_id, recovery_pause)
                else:
                    self.process(pair_id)
            finally:
                with self.mutex:
                    self.running.discard(pair_id)
                    self.busy_nodes.difference_update(members)
        threading.Thread(target=work, daemon=True, name="pair-" + pair_id[:8]).start()

    def run(self):
        # One unexpected error (a locked database, a malformed row) used to end
        # this thread silently: the HTTPS hub kept answering while no setup,
        # stop or recovery was ever processed again until a manual restart.
        while not self.stop.is_set():
            try:
                self.cycle()
            except Exception as error:
                import sys
                print("Pronet controller: cycle failed: " + clean(error), file=sys.stderr, flush=True)
                self.stop.wait(5)
                continue
            self.stop.wait(2)

    def cycle(self):
        for pair_id in self.store.stopping():
            self.launch(pair_id)
        for pair_id in self.store.pending():
            self.launch(pair_id)
        overview = self.store.overview()
        current = {node["id"] for node in overview["nodes"] if node["telemetry"] == "CURRENT"}
        for pair in overview["pairs"]:
            runtime = pair.get("runtime", {})
            pause = runtime.get("pause_id")
            handled = pair["result"].get("recovery", {}).get("handled_pause_id")
            if (pair["state"] == "ACTIVE" and pair["iran"] in current and pair["foreign"] in current
                    and runtime.get("recovery_paused") and runtime.get("link") == "UNCONFIRMED"
                    and not runtime.get("remote_stopped") and pause and pause != handled):
                policy = runtime.get("health", {}).get("recovery_policy", "stable")
                if policy != "explore":
                    # Keep both committed paths running and probing. A short
                    # common outage must not trigger a whole-family replacement.
                    # overview() deliberately omits internal state. Never write
                    # that public projection back over the full pair record.
                    result = self.store.pair(pair["id"])["result"]
                    held = result.get("recovery_hold", {})
                    if held.get("pause_id") != pause:
                        result["recovery_hold"] = {"pause_id": pause, "policy": "stable",
                                                   "state": "awaiting-operator", "utc": utc()}
                        self.store.update_pair(pair["id"], "ACTIVE", result)
                    continue
                health = runtime.get("health", {})
                if health.get("switches_30m", 0) >= 3:
                    # Exploration must obey the same switch budget as the
                    # watchdog. It remains eligible when the window expires.
                    continue
                self.launch(pair["id"], pause)
