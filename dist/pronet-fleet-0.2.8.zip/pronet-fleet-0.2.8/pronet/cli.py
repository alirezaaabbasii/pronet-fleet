from __future__ import annotations

import argparse
import asyncio
import base64
import contextlib
import hashlib
import ipaddress
import json
import os
import pathlib
import platform
import re
import shutil
import signal
import socket
import ssl
import sys
import threading
import time
import urllib.parse

from . import __version__, engines
from .common import (APP, CONFIG, ROOT, PronetError, atomic_write, canonical, clean, command,
                     identifier, ipv4, lock, port, read_json, secret, write_json)
from .model import DEFAULT_PROFILES, PROFILES, tunnel_ips

INSTALL_URL = "https://raw.githubusercontent.com/alirezaaabbasii/pronet-fleet/main/get.sh"
TOKEN_PREFIX = "PNF1-"
START_ON_IRAN = ("Start on your IRAN server first: run the same install command there and choose 1. "
                 "When it finishes it prints one command; copy it and run it on this foreign server.")
HUB_PORTS = (9443, 8443, 7443, 10443, 20443)
REQUIRED_TOOLS = ("ip", "ss", "iptables", "iptables-save", "systemctl", "openssl", "ssh-keygen")


# ---------------------------------------------------------------- helpers

def root_linux():
    if platform.system() != "Linux" or os.geteuid() != 0:
        raise PronetError("This needs Linux and root. Run it with sudo.")


def node_config():
    return read_json(CONFIG / "node.json")


def node_client():
    from .hub import Client
    config = node_config()
    return Client(config["hub_url"], config["node_id"] + ":" + config["node_secret"], config.get("ca_file"))


def say(text=""):
    print(text, flush=True)


def ask(prompt, default=""):
    shown = " [%s]" % default if default != "" else ""
    try:
        value = input("%s%s: " % (prompt, shown)).strip()
    except EOFError:
        value = ""
    return value or str(default)


def check_tools():
    missing = [name for name in REQUIRED_TOOLS if not shutil.which(name)]
    if missing:
        raise PronetError("Missing system tools: " + ", ".join(missing)
                          + ". On Debian/Ubuntu install: python3 iproute2 iptables openssl openssh-client")


def route_source(target="1.1.1.1"):
    """IPv4 this host uses to reach target (the address peers will see unless NAT)."""
    with contextlib.suppress(PronetError, ValueError, IndexError, KeyError, TypeError):
        route = json.loads(command(["ip", "-j", "-4", "route", "get", target]).stdout)[0]
        return route.get("prefsrc")
    return None


def is_global(address):
    with contextlib.suppress(ValueError):
        return ipaddress.ip_address(address).is_global
    return False


def guess_public_ip(local_ips):
    source = route_source()
    if source and is_global(source):
        return source
    return next((ip for ip in local_ips if is_global(ip)), "")


def start_service(name, owner, args, directory):
    from .runtime import write_unit, service
    write_unit(name, owner, args, directory, temporary=False)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "start")


def open_firewall_port(number):
    """Open the coordinator port only in a host firewall that is ACTIVE."""
    if shutil.which("ufw"):
        status = command(["ufw", "status"], check=False).stdout
        if "Status: active" in status:
            command(["ufw", "allow", "%d/tcp" % number], check=False)
            return "ufw: allowed %d/tcp" % number
    if shutil.which("firewall-cmd") and command(["firewall-cmd", "--state"], check=False).returncode == 0:
        command(["firewall-cmd", "--permanent", "--add-port=%d/tcp" % number], check=False)
        command(["firewall-cmd", "--reload"], check=False)
        return "firewalld: allowed %d/tcp" % number
    return ""


# ------------------------------------------------------------ coordinator

def init_hub(args, quiet=False):
    root_linux()
    from .hub import Client
    Client(args.url, "validation-only")  # Validate URL before creating anything.
    parsed = urllib.parse.urlsplit(args.url)
    try:
        address = socket.gethostbyname(parsed.hostname)
    except OSError:
        raise PronetError("Coordinator host name does not resolve; check the IP or DNS.")
    listen_port = parsed.port or 443
    directory = CONFIG / "hub"
    path = directory / "hub.json"
    if path.exists():
        raise PronetError("A coordinator is already configured here; it was not overwritten.")
    with socket.socket() as sock:
        try:
            sock.bind((args.bind, listen_port))
        except OSError:
            raise PronetError("Port %d is already in use on this server." % listen_port)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    (ROOT / "hub").mkdir(parents=True, exist_ok=True, mode=0o700)
    if bool(args.cert) != bool(args.key):
        raise PronetError("Give the certificate and key together.")
    if args.cert:
        cert = pathlib.Path(args.cert).read_text()
        key = pathlib.Path(args.key).read_text()
        atomic_write(directory / "server.crt", cert)
        atomic_write(directory / "server.key", key)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(directory / "server.crt"), str(directory / "server.key"))
        ca_pem = pathlib.Path(args.ca).read_text() if args.ca else ""
    else:
        # 127.0.0.1 is included so an agent on this same host can reach the
        # coordinator locally even when the host cannot hairpin its public IP.
        cert = engines.certificate(directory, parsed.hostname, address, extra_ips=["127.0.0.1"])
        ca_pem = cert
    config = {"url": args.url.rstrip("/"), "bind": args.bind, "port": listen_port,
              "enrollment_key": secret(), "admin_key": secret(), "certificate": str(directory / "server.crt"),
              "private_key": str(directory / "server.key"), "database": str(ROOT / "hub" / "hub.sqlite3")}
    write_json(path, config)
    bootstrap = {"schema": 1, "hub_url": config["url"], "enrollment_key": config["enrollment_key"], "ca_pem": ca_pem}
    write_json(CONFIG / "pronet-bootstrap.json", bootstrap)
    atomic_write(CONFIG / "hub-admin-password", config["admin_key"] + "\n")
    # The hub has no need for root or access to node configuration/engines.
    import pwd
    try:
        account = pwd.getpwnam("pronet-fleet-hub")
    except KeyError:
        command(["useradd", "--system", "--home-dir", str(ROOT / "hub"), "--shell", "/usr/sbin/nologin", "pronet-fleet-hub"])
        account = pwd.getpwnam("pronet-fleet-hub")
    CONFIG.chmod(0o711)
    ROOT.chmod(0o711)
    for base in (directory, ROOT / "hub"):
        os.chown(base, account.pw_uid, account.pw_gid)
        for child in base.iterdir():
            os.chown(child, account.pw_uid, account.pw_gid)
    from .runtime import write_unit, unit_path, service
    name = "pronetf-hub.service"
    write_unit(name, "hub", ["/usr/bin/python3", str(APP / "main.py"), "hub-run"], ROOT / "hub", temporary=False)
    content = unit_path(name).read_text().replace("Type=simple\n", "Type=simple\nUser=pronet-fleet-hub\nGroup=pronet-fleet-hub\nNoNewPrivileges=true\nPrivateTmp=true\nProtectHome=true\nProtectSystem=strict\nReadWritePaths=" + str(ROOT / "hub") + "\n")
    if listen_port < 1024:
        content = content.replace("NoNewPrivileges=true\n", "NoNewPrivileges=true\nAmbientCapabilities=CAP_NET_BIND_SERVICE\nCapabilityBoundingSet=CAP_NET_BIND_SERVICE\n")
    atomic_write(unit_path(name), content, 0o644)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "start")
    firewall = open_firewall_port(listen_port)
    if not quiet:
        say("Coordinator created: " + config["url"])
        say("Bootstrap file (secret): %s" % (CONFIG / "pronet-bootstrap.json"))
        say("Dashboard password (user admin): %s" % (CONFIG / "hub-admin-password"))
        if firewall:
            say(firewall)
        say("Port %d must also be open in any datacenter/cloud firewall." % listen_port)
    return bootstrap


def wait_for_port(host, number, seconds=15):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        with contextlib.suppress(OSError):
            with socket.create_connection((host, number), timeout=1):
                return True
        time.sleep(.5)
    return False


def ensure_local_hub(public_ip):
    """Use the coordinator on this host, creating it on the first free port."""
    bootstrap_path = CONFIG / "pronet-bootstrap.json"
    if bootstrap_path.exists():
        return read_json(bootstrap_path), False
    for candidate in HUB_PORTS:
        with socket.socket() as sock:
            try:
                sock.bind(("0.0.0.0", candidate))
            except OSError:
                continue
        bootstrap = init_hub(argparse.Namespace(url="https://%s:%d" % (public_ip, candidate), bind="0.0.0.0",
                                                cert=None, key=None, ca=None), quiet=True)
        if not wait_for_port("127.0.0.1", candidate):
            raise PronetError("The coordinator service did not start; check: journalctl -u pronetf-hub")
        return bootstrap, True
    raise PronetError("No free port for the coordinator (tried %s)." % ", ".join(map(str, HUB_PORTS)))


def local_hub_url(bootstrap):
    """Agents on the coordinator host talk to it over loopback when the
    coordinator certificate covers 127.0.0.1 (certificates made by >= 0.2.5)."""
    hub = read_json(CONFIG / "hub" / "hub.json", {})
    if not (hub and hub.get("url") == bootstrap["hub_url"] and bootstrap.get("ca_pem")):
        return bootstrap["hub_url"]
    try:
        context = ssl.create_default_context(cadata=bootstrap["ca_pem"])
        with socket.create_connection(("127.0.0.1", hub["port"]), timeout=3) as sock:
            with context.wrap_socket(sock, server_hostname="127.0.0.1"):
                pass
    except (OSError, ssl.SSLError, ValueError):
        return bootstrap["hub_url"]
    return "https://127.0.0.1:%d" % hub["port"]


# ------------------------------------------------------------ join token

def make_token(bootstrap, inbound_port, code):
    pem = bootstrap.get("ca_pem") or ""
    fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest() if pem else ""
    data = {"u": bootstrap["hub_url"], "k": bootstrap["enrollment_key"], "f": fingerprint, "p": inbound_port, "c": code}
    return TOKEN_PREFIX + base64.urlsafe_b64encode(canonical(data)).decode().rstrip("=")


def parse_token(text):
    match = re.search(re.escape(TOKEN_PREFIX) + r"([A-Za-z0-9_-]{40,2048})", text or "")
    if not match:
        raise PronetError("No join token found. Paste the full command shown on the Iran server.")
    raw = match.group(1)
    try:
        data = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)))
    except (ValueError, TypeError):
        raise PronetError("The join token is damaged; copy it again in one piece.")
    if (not isinstance(data, dict) or set(data) != {"u", "k", "f", "p", "c"}
            or not isinstance(data["u"], str) or not data["u"].startswith("https://")
            or not isinstance(data["k"], str) or not re.fullmatch(r"[a-f0-9]{64}", data["k"])
            or not isinstance(data["f"], str) or not re.fullmatch(r"([a-f0-9]{64})?", data["f"])
            or not isinstance(data["c"], str) or not re.fullmatch(r"\d{4}", data["c"])):
        raise PronetError("The join token is not valid.")
    port(data["p"])
    return data


def fetch_pinned_ca(url, fingerprint):
    """Download the coordinator certificate and accept it ONLY if it matches
    the SHA-256 pin carried in the join token (no trust on first use)."""
    parsed = urllib.parse.urlsplit(url)
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((parsed.hostname, parsed.port or 443), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=parsed.hostname) as tls:
                der = tls.getpeercert(binary_form=True)
    except OSError as error:
        raise PronetError("Cannot reach the coordinator at %s (%s). Check that the port is open on the Iran server "
                          "and in its datacenter firewall." % (url, clean(error)))
    if hashlib.sha256(der).hexdigest() != fingerprint:
        raise PronetError("Coordinator certificate does not match the join token. Stopped for safety.")
    return ssl.DER_cert_to_PEM_cert(der)


# ------------------------------------------------------------ nodes

def register_node(role, bootstrap, name, public, bind, inbound_port, hub_url=None):
    from .hub import Client
    from .runtime import inventory
    root_linux()
    check_tools()
    if (CONFIG / "node.json").exists():
        raise PronetError("This server is already registered; its identity was not overwritten.")
    info = inventory()
    if not info["systemd"] or info["arch"] not in ("amd64", "arm64"):
        raise PronetError("Linux with systemd on amd64 or arm64 is required.")
    if ipv4(bind) not in info["ips"]:
        raise PronetError("IP %s is not assigned to this server (for NAT, give the local IP as bind IP)." % bind)
    public = ipv4(public)
    allowed_port = port(inbound_port)
    if allowed_port in info["ssh_ports"]:
        raise PronetError("Port %d is used by SSH." % allowed_port)
    if set(bootstrap) != {"schema", "hub_url", "enrollment_key", "ca_pem"} or bootstrap["schema"] != 1:
        raise PronetError("Invalid bootstrap data.")
    name = re.sub(r"[^\w.\-]", "-", name or socket.gethostname())[:60] or role
    CONFIG.mkdir(parents=True, exist_ok=True, mode=0o700)
    ca_file = None
    if bootstrap["ca_pem"]:
        atomic_write(CONFIG / "hub-ca.pem", bootstrap["ca_pem"])
        ca_file = str(CONFIG / "hub-ca.pem")
    hub_url = hub_url or bootstrap["hub_url"]
    client = Client(hub_url, bootstrap["enrollment_key"], ca_file)
    identity = {"role": role, "public_ip": public, "bind_ip": bind, "name": name}
    credentials = client.call("/v1/enroll", identity)
    identity.update(credentials, hub_url=hub_url, ca_file=ca_file, allowed_inbound_ports=[allowed_port])
    write_json(CONFIG / "node.json", identity)
    start_service("pronetf-agent.service", "agent", ["/usr/bin/python3", str(APP / "main.py"), "agent"], ROOT)
    with contextlib.suppress(OSError, PronetError):
        enable_traffic(quiet=True)
    return identity


def authorize_port(inbound_port):
    """Allow an extra client port on an already registered node (local consent:
    the operator is running this command on this server)."""
    config = node_config()
    allowed = config.get("allowed_inbound_ports", [2053])
    if inbound_port in allowed:
        return config
    from .runtime import inventory
    if inbound_port in inventory()["ssh_ports"]:
        raise PronetError("Port %d is used by SSH." % inbound_port)
    config["allowed_inbound_ports"] = allowed + [inbound_port]
    write_json(CONFIG / "node.json", config)
    command(["systemctl", "restart", "pronetf-agent.service"], check=False)
    time.sleep(1)
    return config


def init_node(args):
    """Advanced/legacy: register with an explicit bootstrap file."""
    bootstrap = read_json(args.bootstrap)
    register_node(args.role, bootstrap, args.name, args.public_ip, args.bind_ip, args.port)
    say("Registered: %s (%s)" % (args.name, args.role))


def port_problem(info, bind_ip, number):
    from .runtime import endpoint_has_nat, endpoint_occupied
    if number in info["ssh_ports"]:
        return "port %d is used by SSH" % number
    if endpoint_occupied(info, bind_ip, number):
        return "port %d is already in use on this server" % number
    if endpoint_has_nat(info, bind_ip, number):
        return "an existing NAT rule already uses port %d" % number
    return ""


# ------------------------------------------------------------ flows

def setup_iran(args=None, interactive=True):
    """Iran: coordinator (if needed) + registration + new tunnel, in one flow."""
    from .runtime import inventory
    root_linux()
    check_tools()
    info = inventory()
    registered = (CONFIG / "node.json").exists()
    if registered:
        config = node_config()
        if config["role"] != "iran":
            raise PronetError("This server is registered as foreign.")
        public, bind = config["public_ip"], config["bind_ip"]
    else:
        detected = getattr(args, "public_ip", None) or guess_public_ip(info["ips"])
        public = ask("Public IPv4 of this Iran server", detected) if interactive else detected
        ipv4(public)
        if public in info["ips"]:
            bind = public
        else:
            local = getattr(args, "bind_ip", None) or route_source() or ""
            bind = ask("This server is behind NAT. Local IPv4 to bind", local) if interactive else local
    default_port = getattr(args, "port", None) or 2053
    while True:
        value = ask("Client port on Iran (the foreign panel inbound must use the same port)", default_port) if interactive else default_port
        try:
            number = port(int(value))
        except (ValueError, PronetError):
            say("  Enter a number from 1 to 65535.")
            continue
        problem = port_problem(info, bind, number)
        if not problem:
            break
        if not interactive:
            raise PronetError(problem.capitalize() + "; choose another port with --port.")
        say("  " + problem.capitalize() + ". Choose another port.")
    if not registered:
        bootstrap, created = ensure_local_hub(public)
        if created:
            say("Coordinator started on this server: " + bootstrap["hub_url"])
        register_node("iran", bootstrap, getattr(args, "name", None) or socket.gethostname(), public, bind, number,
                      hub_url=local_hub_url(bootstrap))
        say("This server is registered as IRAN.")
    else:
        authorize_port(number)
    new_tunnel(number, name=getattr(args, "tunnel_name", None), quality=getattr(args, "quality", None) or "balanced",
               sni=getattr(args, "sni", "") or "", wait=not getattr(args, "no_wait", False))


def new_tunnel(inbound_port=None, name=None, quality="balanced", sni="", profiles=None, standby=True, wait=True,
               direction="iran-dials"):
    config = node_config()
    if config["role"] != "iran":
        raise PronetError("Create tunnels on the Iran server.")
    inbound_port = inbound_port or config.get("allowed_inbound_ports", [2053])[0]
    if inbound_port not in config.get("allowed_inbound_ports", [2053]):
        config = authorize_port(inbound_port)
    name = name or "tunnel-" + time.strftime("%m%d-%H%M")
    request = {"name": name, "public_ip": config["public_ip"], "bind_ip": config["bind_ip"],
               "inbound_port": inbound_port, "profiles": profiles or list(DEFAULT_PROFILES),
               "standby": 1 if standby else 0, "direction": direction, "sni": sni, "quality": quality}
    created = node_client().call("/v1/pair", request)
    bootstrap = read_json(CONFIG / "pronet-bootstrap.json", {})
    say("")
    say("=" * 64)
    say("  IRAN IS READY. NEXT STEP ON YOUR FOREIGN SERVER:")
    say("  copy the whole line below, paste it on the foreign server, press Enter")
    say("=" * 64)
    if bootstrap:
        token = make_token(bootstrap, inbound_port, created["code"])
        say("")
        say("curl -fsSL %s | sudo bash -s -- join %s" % (INSTALL_URL, token))
        say("")
        say("(already installed there?  sudo pronet join %s )" % token)
        say("Valid for %d minutes. It contains a secret: paste it only on your own server." % (created["expires_in"] // 60))
    else:
        say("")
        say("sudo pronet join %s" % created["code"])
        say("")
        say("Valid for %d minutes." % (created["expires_in"] // 60))
    say("")
    if wait:
        follow(created["pair_id"])
    else:
        say("Progress: sudo pronet watch")


def join(text, public_ip=None, name=None):
    """Foreign: one command registers (if needed) and joins the tunnel."""
    root_linux()
    text = (text or "").strip()
    if not text:
        raise PronetError(START_ON_IRAN)
    if re.fullmatch(r"\d{4}", text):
        if not (CONFIG / "node.json").exists():
            raise PronetError(START_ON_IRAN)
        code, data = text, None
    else:
        data = parse_token(text)
        code = data["c"]
    if not (CONFIG / "node.json").exists():
        check_tools()
        from .runtime import inventory
        info = inventory()
        say("Checking the coordinator %s ..." % data["u"])
        pem = fetch_pinned_ca(data["u"], data["f"]) if data["f"] else ""
        bootstrap = {"schema": 1, "hub_url": data["u"], "enrollment_key": data["k"], "ca_pem": pem}
        hub_host = socket.gethostbyname(urllib.parse.urlsplit(data["u"]).hostname)
        bind = route_source(hub_host) or guess_public_ip(info["ips"])
        if public_ip:
            public = public_ip
        elif bind and is_global(bind):
            public = bind
        else:
            public = ask("This server is behind NAT. Its public IPv4", guess_public_ip(info["ips"]))
        problem = port_problem(info, bind, data["p"]) if data["p"] in info["ssh_ports"] else ""
        if problem:
            raise PronetError(problem.capitalize() + ".")
        register_node("foreign", bootstrap, name or socket.gethostname(), public, bind, data["p"])
        say("This server is registered as FOREIGN (%s, client port %d)." % (public, data["p"]))
    else:
        config = node_config()
        if config["role"] != "foreign":
            raise PronetError("This server is registered as Iran. Run join on the foreign server.")
        if data:
            if data["u"].rstrip("/") != config["hub_url"].rstrip("/"):
                raise PronetError("This server belongs to another coordinator (%s)." % config["hub_url"])
            authorize_port(data["p"])
    result = node_client().call("/v1/join", {"code": code})
    say("Paired (tunnel %s)." % result["pair_id"][:8])
    say("The Iran server now measures every carrier and installs the best one (usually 5-10 minutes).")
    say("Progress and the final report are shown on the Iran server (sudo pronet watch).")
    port_number = (data or {}).get("p") or node_config().get("allowed_inbound_ports", [2053])[0]
    if not _listening(port_number):
        say("")
        say("Reminder: nothing listens on port %d here yet. Create your panel inbound on 0.0.0.0:%d." % (port_number, port_number))


def _listening(number):
    with contextlib.suppress(OSError):
        with socket.create_connection(("127.0.0.1", number), timeout=1):
            return True
    return False


# ------------------------------------------------------------ monitoring

def find_pair(data, pair_id=None):
    pairs = data.get("pairs", [])
    if pair_id:
        return next((pair for pair in pairs if pair["id"] == pair_id or pair["id"].startswith(pair_id)), None)
    return pairs[0] if pairs else None


def follow(pair_id):
    from .report import final_report, progress_lines
    say("Live progress (Ctrl+C to leave; setup continues in the background)")
    interactive = sys.stdout.isatty()
    printed, last_stage = 0, ""
    try:
        while True:
            try:
                data = node_client().call("/v1/overview")
            except PronetError as error:
                say("  coordinator unreachable, retrying: " + clean(error))
                time.sleep(5)
                continue
            pair = find_pair(data, pair_id)
            if pair is None:
                raise PronetError("Tunnel not found.")
            if pair["state"] in ("ACTIVE", "FAILED", "STOPPED", "STOP_UNCONFIRMED"):
                if interactive:
                    print("\033[2J\033[H", end="")
                for line in final_report(pair, data.get("nodes")):
                    say(line)
                return pair
            lines = progress_lines(pair)
            if interactive:
                # Redraw in place, like `watch`, so the screen stays readable.
                print("\033[2J\033[H", end="")
                say("Pronet Fleet %s   (Ctrl+C leaves this view; setup continues)" % __version__)
                for line in lines:
                    say(line)
            else:
                stage = lines[1].split("   elapsed")[0] if len(lines) > 1 else lines[0]
                if stage != last_stage:
                    say(stage)
                    last_stage = stage
                for line in lines[2:][printed:]:
                    say(line)
                printed = max(printed, len(lines) - 2)
            time.sleep(3)
    except KeyboardInterrupt:
        say("")
        say("Left the live view. Setup continues; see it again with: sudo pronet watch")


def display(data):
    from .report import progress_lines
    say("")
    say("Pronet Fleet " + __version__)
    for node in data.get("nodes", []):
        resource = node["metrics"].get("resources", {})
        say("  %s | %s | %s | CPU=%s%% RAM=%s%% Disk=%s%% | age=%ss" % (
            clean(node["info"]["name"], 60), node["role"], node["telemetry"], resource.get("cpu_percent", "?"),
            resource.get("ram_percent", "?"), resource.get("disk_percent", "?"), node["age_seconds"]))
    for item in data.get("pairs", []):
        result, runtime = item["result"], item.get("runtime", {})
        endpoint = result.get("endpoint", "%s:%s" % (item["request"]["public_ip"], item["request"]["inbound_port"]))
        say("")
        say("  %s | %s | %s" % (clean(item["request"]["name"], 60), item["state"], endpoint))
        if item["state"] == "ACTIVE":
            rtt = runtime.get("rtt_ms")
            say("    link=%s  active=%s  rtt=%s ms  inbound=%s%s" % (
                runtime.get("link", "UNKNOWN"), runtime.get("active") or result.get("active", "-"),
                rtt if rtt is not None else "-", runtime.get("inbound", "UNKNOWN"),
                "  AUTO-RECOVERY PAUSED" if runtime.get("recovery_paused") else ""))
            for name, health in runtime.get("standby_health", {}).items():
                if name != runtime.get("active") and isinstance(health, dict):
                    say("    standby=%s  probe=%s  failures=%s  rtt=%s ms" % (
                        name, health.get("state", "UNKNOWN"), health.get("failures", 0), health.get("rtt_ms", "-")))
        elif item["state"] not in ("FAILED", "STOPPED"):
            for line in progress_lines(item)[1:]:
                say("  " + line)
        if result.get("error"):
            say("    ERROR: " + clean(result["error"]))
        say("    ID: " + item["id"])


def monitor(watch=False, json_output=False):
    while True:
        data = node_client().call("/v1/overview")
        if json_output:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        else:
            if watch and sys.stdout.isatty():
                print("\033[2J\033[H", end="")
            display(data)
        if not watch:
            return
        time.sleep(5)


def show_report(pair_id=None):
    from .report import final_report, progress_lines
    data = node_client().call("/v1/overview")
    pair = find_pair(data, pair_id)
    if pair is None:
        raise PronetError("No tunnel found.")
    lines = final_report(pair, data.get("nodes")) if pair["state"] in ("ACTIVE", "FAILED", "STOPPED") else progress_lines(pair)
    for line in lines:
        say(line)



def run_hub():
    from .controller import Controller
    from .hub import HubServer
    from .store import Store
    config = read_json(CONFIG / "hub" / "hub.json")
    store = Store(config["database"], config["enrollment_key"], config["admin_key"])
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(config["certificate"], config["private_key"])
    stop = threading.Event()
    server = HubServer((config["bind"], config["port"]), store, tls=context, public_url=config["url"])
    controller = Controller(store, stop)
    threading.Thread(target=controller.run, daemon=True, name="controller").start()
    def terminate(*_):
        stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    try:
        server.serve_forever(poll_interval=.5)
    finally:
        stop.set()
        server.server_close()


def managed_run(directory, kind):
    root_linux()
    from .runtime import owned_directory
    directory = owned_directory(directory)
    plan = read_json(directory / "plan.json")
    if kind == "engine":
        recipe = read_json(directory / "launch.json")
        args = recipe["command"]
        binary = pathlib.Path(args[0]).resolve()
        if not binary.is_relative_to((ROOT / "engines").resolve()):
            raise PronetError("Engine executable is outside managed storage")
        env = os.environ.copy()
        for key, value in recipe.get("environment", {}).items():
            if key not in ("AUTH", "SSL_CERT_FILE", "SSL_CERT_DIR", "WSTUNNEL_HTTP_UPGRADE_PATH_PREFIX", "RUST_LOG", "TOKIO_WORKER_THREADS") or not isinstance(value, str) or "\n" in value:
                raise PronetError("Invalid engine environment")
            env[key] = value
        os.execve(str(binary), args, env)
    elif kind == "echo":
        from .wire import ProbeServer, Gateway, bridge_server
        addresses = [("127.0.0.1", plan["echo_port"])]
        if PROFILES[plan["profile"]]["kind"] == "l3":
            addresses.append((tunnel_ips(plan)[0 if plan["role"] == "iran" else 1], plan["echo_port"]))
        servers = []
        for address in addresses:
            server = ProbeServer(address, plan["token"], freebind=address[0] != "127.0.0.1")
            servers.append(server)
            threading.Thread(target=server.serve_forever, daemon=True).start()
        async def auxiliary():
            stop = asyncio.Event()
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGTERM, signal.SIGINT): loop.add_signal_handler(sig, stop.set)
            bridges, frontend = [], None
            if PROFILES[plan["profile"]]["kind"] != "l3":
                if plan["role"] == "foreign":
                    for source, target in ((plan["bridge_health_port"], plan["echo_port"]), (plan["bridge_data_port"], plan["inbound_port"])):
                        async def handler(reader, writer, target=target):
                            await bridge_server(reader, writer, plan["token"], ("127.0.0.1", target))
                        bridges.append(await asyncio.start_server(handler, "127.0.0.1", source, backlog=4096))
                else:
                    path = directory / "probe-front.json"
                    write_json(path, {"bind_ip": "127.0.0.1", "port": plan["probe_front_port"], "mode": "framed",
                                      "frame_key": plan["token"], "active_backend": ["127.0.0.1", plan["health_port"]]})
                    frontend = Gateway(path, directory / "probe-stats.json")
                    await frontend.start()
            await stop.wait()
            for server in bridges:
                server.close()
                # Python 3.12+ waits for live sessions here; do not block stop.
                with contextlib.suppress(asyncio.TimeoutError):
                    await asyncio.wait_for(server.wait_closed(), 3)
            if frontend: await frontend.close()
        asyncio.run(auxiliary())
        for server in servers:
            server.shutdown()
            server.server_close()
    else:
        raise PronetError("Invalid managed resource")


def managed_gateway(pair_id):
    root_linux()
    identifier(pair_id)
    from .wire import Gateway
    async def run():
        directory = ROOT / "pairs" / pair_id
        gateway = Gateway(directory / "gateway.json", directory / "traffic.json")
        await gateway.start()
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)
        await stop.wait()
        await gateway.close()
    asyncio.run(run())


def repair(pair_id, restart=False):
    root_linux()
    identifier(pair_id)
    from .runtime import Runtime, is_active, service, unit_name
    runtime = Runtime(node_config())
    directory = ROOT / "pairs" / pair_id
    if (directory / "stopped.json").exists():
        raise PronetError("This tunnel was removed from this server; create a new one.")
    with lock(ROOT / "host-operation.lock"):
        selected = read_json(directory / "selection.json")
        for profile in selected["profiles"]:
            plan = runtime.validate(read_json(directory / profile / "plan.json"))
            for kind in ("engine", "echo"):
                name = unit_name(pair_id, profile, kind, plan["role"])
                if restart or not is_active(name):
                    service(name, "reset-failed")
                    service(name, "restart" if restart else "start")
        if runtime.identity["role"] == "iran" and (directory / "active.json").exists():
            gateway = "pronetf-" + pair_id + "-gateway.service"
            if restart or not is_active(gateway):
                service(gateway, "reset-failed")
                service(gateway, "restart" if restart else "start")
        selected.update(auto_paused=False, failures=0, switches=[])
        write_json(directory / "selection.json", selected)
    print("Done. Only this tunnel's services on this server were touched.")


def enable_traffic(quiet=False):
    root_linux()
    from .runtime import write_unit, unit_path, service
    name = "pronetf-counters.service"
    write_unit(name, "counters", ["/usr/bin/python3", str(APP / "main.py"), "managed-counters"], ROOT, temporary=False)
    path = unit_path(name)
    text = path.read_text().replace("Type=simple\n", "Type=oneshot\nRemainAfterExit=yes\n").replace("Restart=always\n", "Restart=no\n")
    if "Restart=no\n" not in text:
        raise PronetError("Counter unit template changed; refusing an invalid oneshot unit")
    atomic_write(path, text, 0o644)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "reset-failed")
    service(name, "restart")  # Adds missing counters without resetting existing ones.
    if not quiet:
        print("Per-IP traffic counters enabled; filter and NAT rules were not changed.")



def failover_delay(seconds=None):
    from .runtime import SETTINGS, failover_probes, failover_seconds
    if seconds is None:
        say("Failover after about %d s of total primary outage (%d failed probes in a row)."
            % (failover_seconds(), failover_probes()))
        return
    root_linux()
    if not 10 <= seconds <= 600:
        raise PronetError("Choose 10 to 600 seconds.")
    settings = read_json(SETTINGS, {})
    settings["failover_seconds"] = seconds
    write_json(SETTINGS, settings)
    say("Saved. Failover now needs about %d s of total primary outage (%d failed probes in a row)."
        % (seconds, failover_probes()))
    say("Applies immediately on this server; no restart needed. Run it on the Iran server.")


def wizard():
    say("Pronet Fleet %s - Iran <-> foreign tunnel" % __version__)
    if not (CONFIG / "node.json").exists():
        say("Where is THIS server?")
        say("  1) Iran      (always start here)")
        say("  2) Foreign   (needs the command printed by your Iran server)")
        say("  3) Advanced  (coordinator only / existing bootstrap file)")
        choice = ask("Select", "1")
        if choice == "1":
            setup_iran()
        elif choice == "2":
            text = input("Paste the command from your Iran server (Enter if you have not set up Iran yet): ").strip()
            if not text:
                raise PronetError(START_ON_IRAN)
            join(text)
        elif choice == "3":
            advanced_menu()
        else:
            raise PronetError("Choose 1, 2 or 3.")
        return
    config = node_config()
    if config["role"] == "iran":
        say("  1) New tunnel   2) Live status   3) Last setup report")
        choice = ask("Select", "1")
        if choice == "2":
            monitor(watch=True)
        elif choice == "3":
            show_report()
        else:
            setup_iran()
    else:
        say("  1) Join a tunnel (paste the command from Iran)   2) Live status")
        choice = ask("Select", "1")
        if choice == "2":
            monitor(watch=True)
        else:
            text = input("Paste the command from your Iran server: ").strip()
            if not text:
                raise PronetError(START_ON_IRAN)
            join(text)


def advanced_menu():
    say("  a) Coordinator only on this server")
    say("  b) Register with a bootstrap file (Iran or foreign)")
    choice = ask("Select", "a").lower()
    if choice == "a":
        url = ask("Coordinator HTTPS address", "https://%s:9443" % (guess_public_ip([]) or "SERVER_IP"))
        init_hub(argparse.Namespace(url=url, bind="0.0.0.0", cert=None, key=None, ca=None))
    elif choice == "b":
        role = {"1": "iran", "2": "foreign"}.get(ask("Role: 1) Iran  2) Foreign", "1"))
        if not role:
            raise PronetError("Choose 1 or 2.")
        path = ask("Bootstrap file", "/root/pronet-bootstrap.json")
        public = ask("Public IPv4", guess_public_ip([]))
        bind = ask("Local IPv4 to bind", public)
        number = int(ask("Client port", "2053"))
        register_node(role, read_json(path), socket.gethostname(), public, bind, number)
        say("Registered as %s." % role.upper())
        if role == "iran":
            new_tunnel(number)
        else:
            join(ask("4-digit code from Iran"))
    else:
        raise PronetError("Choose a or b.")


def main():
    parser = argparse.ArgumentParser(prog="pronet", description="Pronet Fleet: Iran <-> foreign tunnels with automatic carrier selection")
    parser.add_argument("--version", action="version", version=__version__)
    subs = parser.add_subparsers(dest="action")
    subs.add_parser("menu", help="interactive menu (default)")
    iran = subs.add_parser("setup-iran", help="non-interactive Iran setup (coordinator + registration + tunnel)")
    iran.add_argument("--public-ip"); iran.add_argument("--bind-ip"); iran.add_argument("--port", type=int, default=2053)
    iran.add_argument("--name"); iran.add_argument("--tunnel-name"); iran.add_argument("--sni", default="")
    iran.add_argument("--quality", choices=["quick", "balanced", "thorough"], default="balanced")
    iran.add_argument("--no-wait", action="store_true")
    joining = subs.add_parser("join", help="foreign: join with the command/token from Iran, or a 4-digit code")
    joining.add_argument("token"); joining.add_argument("--public-ip"); joining.add_argument("--name")
    setup = subs.add_parser("pair", help="Iran: create another tunnel")
    setup.add_argument("--name"); setup.add_argument("--port", type=int)
    setup.add_argument("--profiles"); setup.add_argument("--no-standby", action="store_true")
    setup.add_argument("--direction", choices=["iran-dials", "foreign-dials"], default="iran-dials")
    setup.add_argument("--sni", default="")
    setup.add_argument("--quality", choices=["quick", "balanced", "thorough"], default="balanced")
    setup.add_argument("--no-wait", action="store_true")
    report = subs.add_parser("report", help="final setup report"); report.add_argument("pair_id", nargs="?")
    delay = subs.add_parser("failover-delay", help="Iran: seconds of total primary outage before switching to standby")
    delay.add_argument("seconds", nargs="?", type=int)
    subs.add_parser("status"); subs.add_parser("watch"); subs.add_parser("json")
    subs.add_parser("doctor"); subs.add_parser("profiles")
    hub = subs.add_parser("hub-init", help="advanced: coordinator only")
    hub.add_argument("--url", required=True)
    hub.add_argument("--bind", default="0.0.0.0")
    hub.add_argument("--cert"); hub.add_argument("--key"); hub.add_argument("--ca")
    node = subs.add_parser("node-init", help="advanced: register with a bootstrap file")
    node.add_argument("--role", choices=["iran", "foreign"], required=True)
    node.add_argument("--bootstrap", required=True); node.add_argument("--name", required=True)
    node.add_argument("--public-ip", required=True); node.add_argument("--bind-ip", required=True)
    node.add_argument("--port", type=int, default=2053)
    subs.add_parser("hub-run"); subs.add_parser("agent")
    subs.add_parser("traffic-enable"); subs.add_parser("managed-counters")
    for name in ("repair", "restart", "remove", "remove-local", "logs"):
        item = subs.add_parser(name); item.add_argument("pair_id")
    managed = subs.add_parser("managed-run"); managed.add_argument("directory"); managed.add_argument("kind", choices=["engine", "echo"])
    gateway = subs.add_parser("managed-gateway"); gateway.add_argument("pair_id")
    firewall = subs.add_parser("managed-firewall"); firewall.add_argument("directory"); firewall.add_argument("kind", choices=["engine", "echo", "gateway"]); firewall.add_argument("operation", choices=["up", "down"])
    args = parser.parse_args()
    try:
        if args.action in (None, "menu"):
            wizard()
        elif args.action == "setup-iran": setup_iran(args, interactive=False)
        elif args.action == "join": join(args.token, args.public_ip, args.name)
        elif args.action == "pair":
            profiles = list(PROFILES) if args.profiles == "all" else args.profiles.split(",") if args.profiles else None
            new_tunnel(args.port, args.name, args.quality, args.sni, profiles, not args.no_standby, not args.no_wait, args.direction)
        elif args.action == "report": show_report(args.pair_id)
        elif args.action == "failover-delay": failover_delay(args.seconds)
        elif args.action == "hub-init": init_hub(args)
        elif args.action == "hub-run": run_hub()
        elif args.action == "node-init": init_node(args)
        elif args.action == "agent":
            root_linux()
            from .agent import Agent
            agent = Agent(node_config())
            signal.signal(signal.SIGTERM, lambda *_: agent.stop.set())
            signal.signal(signal.SIGINT, lambda *_: agent.stop.set())
            agent.run()
        elif args.action in ("status", "watch", "json"): monitor(args.action == "watch", args.action == "json")
        elif args.action == "profiles":
            from .report import describe
            for name, spec in PROFILES.items(): print("%-20s %s" % (name, describe(name)))
        elif args.action == "traffic-enable": enable_traffic()
        elif args.action == "managed-counters":
            root_linux()
            from .accounting import enable
            enable(node_config()["node_id"])
        elif args.action == "doctor":
            from .runtime import inventory
            root_linux()
            print(json.dumps(inventory(), ensure_ascii=False, indent=2))
        elif args.action in ("repair", "restart"): repair(args.pair_id, args.action == "restart")
        elif args.action == "remove-local":
            root_linux()
            from .runtime import Runtime
            with lock(ROOT / "host-operation.lock"):
                print(json.dumps(Runtime(node_config()).cleanup(args.pair_id)))
        elif args.action == "remove":
            identifier(args.pair_id)
            result = node_client().call("/v1/stop", {"pair_id": args.pair_id})
            print("Stop requested on both servers:", result["state"])
            print("Confirm with: sudo pronet status")
        elif args.action == "logs":
            identifier(args.pair_id)
            path = ROOT / "pairs" / args.pair_id / "events.jsonl"
            if path.exists():
                for line in path.read_text().splitlines()[-40:]: print(clean(line, 1000))
            command_result = command(["journalctl", "--no-pager", "-n", "50", "-o", "cat", "-u", "pronetf-" + args.pair_id + "-*.service"], check=False)
            for line in command_result.stdout.splitlines(): print(clean(line, 1000))
        elif args.action == "managed-run": managed_run(args.directory, args.kind)
        elif args.action == "managed-gateway": managed_gateway(args.pair_id)
        elif args.action == "managed-firewall":
            root_linux()
            from .runtime import managed_firewall
            managed_firewall(args.directory, args.kind, args.operation)
    except KeyboardInterrupt:
        print("\nStopped. Tunnel services keep running.")
    except (PronetError, OSError, ValueError, KeyError) as error:
        print("Pronet: " + clean(error), file=sys.stderr)
        raise SystemExit(1)
