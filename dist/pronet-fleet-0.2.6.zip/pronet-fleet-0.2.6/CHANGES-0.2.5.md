# Pronet Fleet 0.2.5 - faster, simpler setup

## Setup: two steps instead of eight
1. **Iran:** `curl -fsSL https://raw.githubusercontent.com/alirezaaabbasii/pronet-fleet/main/get.sh | sudo bash`, choose `1`, press Enter twice (public IP and client port are detected/defaulted).
   The coordinator is created on the Iran server automatically (first free port of 9443/8443/7443/10443/20443; an active ufw/firewalld gets the port opened).
2. **Foreign:** paste the single command the Iran server prints:
   `curl -fsSL .../get.sh | sudo bash -s -- join PNF1-...`
   It installs, registers and pairs in one go. No bootstrap file to copy, no paths to type, no separate 4-digit prompt.

The join token carries the coordinator URL, the enrollment secret, the client port, the pairing code and the
**SHA-256 pin of the coordinator certificate**. The foreign server accepts the coordinator only if the certificate
matches the pin (no trust-on-first-use). Pairing codes are valid for 10 minutes (was 5).

The Iran agent talks to a local coordinator over 127.0.0.1 when the certificate covers it (new coordinators),
so a host that cannot hairpin its own public IP still works.

## Carrier testing: roughly half the time or less
- Carriers are prepared and started in batches of 6 (2 round trips per batch instead of 2 per carrier, one host inventory per batch).
- Reachability of a whole batch is awaited **in parallel** for at most 20 s; a carrier whose engine exits is failed immediately.
- Unreachable carriers no longer run a full benchmark (previously ~60 s of timeouts each); throughput is still measured one carrier at a time.
- Agent job polling 2 s -> 0.5 s, coordinator result polling 0.5 s -> 0.2 s.
- Both servers must run the same version; a mismatch stops setup in preflight with a clear message.

## Output
- All terminal text is English (Persian did not render correctly in terminals). The web dashboard is unchanged.
- Live progress view (redraws in place) and a final report: primary and standby carriers with the reason each was chosen,
  failed carriers grouped by cause, total test time, route latency, and the exact next action (e.g. foreign inbound not listening).
- New: `sudo pronet report`.

## Upgrade
Run the same installer command on both servers. Running tunnels are kept; the coordinator and agents restart.

## 0.2.6
- The first menu asks where the server is (1 Iran, 2 Foreign). Choosing Foreign without the command from Iran stops with:
  "Start on your IRAN server first ... it prints one command; copy it and run it on this foreign server."
- The Iran server's final instruction is explicit: copy the whole line and run it on the foreign server.
