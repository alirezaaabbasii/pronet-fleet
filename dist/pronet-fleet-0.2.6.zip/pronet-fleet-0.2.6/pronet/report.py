"""Human-readable setup progress and final reports (plain English, terminal-safe)."""
from __future__ import annotations

import math
import time

from .model import PROFILES, ranking

DESCRIPTIONS = {
    "bp-l3-pck": "BackPack L3 over raw TCP (PCK)",
    "bp-l3-quic": "BackPack L3 over QUIC",
    "bp-l3-udp": "BackPack L3 over UDP",
    "bp-stealth": "BackPack reverse, stealth TCP",
    "bp-quic": "BackPack reverse over QUIC",
    "bp-kcp": "BackPack reverse over KCP/UDP",
    "bp-pck": "BackPack reverse over raw TCP (PCK)",
    "frp-tls": "FRP reverse tunnel over TLS/TCP",
    "frp-quic": "FRP reverse tunnel over QUIC",
    "chisel": "Chisel reverse over SSH/HTTP",
    "bp-direct-stealth": "BackPack direct, stealth TCP",
    "bp-l3-pck-reverse": "BackPack L3 raw TCP, foreign dials",
    "bp-l3-quic-reverse": "BackPack L3 QUIC, foreign dials",
    "bp-l3-udp-reverse": "BackPack L3 UDP, foreign dials",
    "bp-l3-pck-fec": "BackPack L3 raw TCP + FEC",
    "bp-l3-udp-fec": "BackPack L3 UDP + FEC",
    "bp-l3-sni": "BackPack L3, SNI-shaped TCP",
    "bp-l3-xdi": "BackPack L3 over ICMP (experimental)",
    "rathole-noise": "Rathole reverse, Noise-encrypted TCP",
    "wstunnel-wss": "wstunnel reverse over WebSocket/TLS",
    "wstunnel-h2": "wstunnel reverse over HTTP/2 TLS",
}
FAMILIES = {"tcp": "TCP", "udp": "UDP", "raw-tcp": "raw TCP", "icmp": "ICMP"}


def describe(profile):
    return DESCRIPTIONS.get(profile, profile)


def family(profile):
    return FAMILIES.get(PROFILES.get(profile, {}).get("family"), "?")


def duration(seconds):
    if seconds is None or not math.isfinite(seconds) or seconds < 0:
        return "?"
    seconds = int(round(seconds))
    return "%dm%02ds" % divmod(seconds, 60) if seconds >= 60 else "%ds" % seconds


def mbps(value):
    return "-" if not isinstance(value, (int, float)) else ("%.1f" % value)


def reason(row):
    """One short, user-facing reason for a failed carrier."""
    if row.get("passed"):
        return ""
    text = row.get("reason") or row.get("error") or ""
    if text:
        if "no end-to-end connectivity" in text or text == "unreachable":
            return "no connectivity (blocked or filtered on this route)"
        if "engine exited" in text:
            return "engine exited during start (see logs)"
        if "reverse direction" in text:
            return "works Iran->foreign only, reverse direction failed"
        return text[:110]
    if row.get("echo_ms") and row.get("success_ratio", 0) < 1:
        return "unstable (%d%% of probes answered)" % round(100 * row.get("success_ratio", 0))
    if not row.get("echo_ms"):
        return "no connectivity (blocked or filtered on this route)"
    if not row.get("half_close"):
        return "half-close not preserved"
    if not row.get("integrity"):
        return "data integrity check failed"
    if not row.get("after_idle"):
        return "connection dropped after idle"
    return "did not pass"


def _p95(samples):
    samples = [x for x in samples or [] if isinstance(x, (int, float))]
    if not samples:
        return None
    return sorted(samples)[max(0, math.ceil(len(samples) * .95) - 1)]


def progress_lines(pair, now=None):
    """Compact live view while a pair is being set up."""
    now = now or time.time()
    result = pair.get("result", {})
    state = pair.get("state", "?")
    request = pair.get("request", {})
    started = result.get("timing", {}).get("started")
    elapsed = duration(now - started) if started else "-"
    lines = ["Tunnel %s  (%s)" % (request.get("name", "?"), pair.get("id", "")[:8])]
    if state == "UNPAIRED":
        lines.append("Waiting for the foreign server to join...")
        return lines
    progress = result.get("progress", {})
    stage = {"PAIRED": "starting", "PREFLIGHT": "checking both servers", "TRIAL": "measuring carriers",
             "STAGED": "installing the winner", "VERIFYING": "verifying the winner",
             "ROLLING_BACK": "rolling back", "STOPPING": "stopping"}.get(state, state.lower())
    if result.get("phase") == "longer-test":
        stage = "qualifying the best carriers (longer test)"
    line = "Stage: %s" % stage
    if progress.get("total"):
        line += "   tested %d/%d, passed %d" % (progress.get("tested", 0), progress["total"], progress.get("passed", 0))
    lines.append(line + "   elapsed " + elapsed)
    for row in result.get("results", []):
        if row.get("passed"):
            soak = row.get("soak", {})
            mark = " qualified" if soak.get("passed") else (" not qualified" if soak else "")
            lines.append("  PASS  %-19s %5s / %-5s Mbps  p95 %s ms%s" % (
                row["profile"], mbps(row.get("upload_mbps")), mbps(row.get("download_mbps")),
                _fmt(_p95(row.get("echo_ms"))), mark))
        else:
            lines.append("  FAIL  %-19s %s" % (row.get("profile", "?"), reason(row)))
    return lines


def _fmt(value):
    return "-" if value is None else "%d" % round(value)


def final_report(pair, nodes=None):
    """Plain-English summary shown when setup finishes (success or failure)."""
    result = pair.get("result", {})
    request = pair.get("request", {})
    rows = result.get("results", [])
    timing = result.get("timing", {})
    took = duration(timing["finished"] - timing["started"]) if timing.get("finished") and timing.get("started") else "?"
    passed = [row for row in rows if row.get("passed")]
    failed = [row for row in rows if not row.get("passed")]
    port = request.get("inbound_port")
    endpoint = result.get("endpoint") or "%s:%s" % (request.get("public_ip"), port)
    out = []
    bar = "=" * 64
    if pair.get("state") != "ACTIVE":
        out += [bar, "  SETUP DID NOT COMPLETE  (state: %s)" % pair.get("state"), bar]
        if result.get("error"):
            out.append("Reason : " + result["error"])
        out.append("Tested : %d carriers in %s, %d passed, %d failed" % (len(rows), took, len(passed), len(failed)))
        out += _failure_groups(failed)
        out += ["", "Nothing was activated for clients. Both servers were cleaned up.",
                "Next   : fix the reason above, then on Iran run:  sudo pronet  ->  1) New tunnel"]
        return out
    selected = result.get("selected", [])
    qualified = [row["soak"] for row in rows if row.get("soak", {}).get("passed")]
    scored = {row["profile"]: row for row in ranking(qualified, all_results=True)}
    out += [bar, "  TUNNEL READY", bar,
            "Endpoint : %s   (clients connect here)" % endpoint]
    if selected:
        primary = selected[0]
        out.append("Primary  : %s - %s" % (primary, describe(primary)))
        out.append("           why: " + _why_primary(scored.get(primary)))
    if len(selected) > 1:
        standby = selected[1]
        out.append("Standby  : %s - %s" % (standby, describe(standby)))
        if family(standby) != family(selected[0]):
            why = ("best qualified carrier in a different transport family (%s vs %s), "
                   "so one blocked protocol cannot take down both paths" % (family(standby), family(selected[0])))
        else:
            why = "next best qualified carrier (no healthy carrier from another family qualified)"
        out.append("           why: " + why)
        out.append("           automatic failover in about 15-25 s if the primary stops answering")
    else:
        out.append("Standby  : none (only one carrier qualified; there is no automatic failover)")
    out.append("Tested   : %d carriers in %s: %d passed, %d failed" % (len(rows), took, len(passed), len(failed)))
    if passed:
        ranked = sorted(passed, key=lambda row: -(scored.get(row["profile"], {}).get("score") or 0))
        out.append("  Passed : " + ", ".join(
            "%s (%s/%s Mbps)" % (row["profile"], mbps(row.get("upload_mbps")), mbps(row.get("download_mbps")))
            for row in ranked))
    out += _failure_groups(failed)
    rtt = _route_rtt(scored, selected)
    if rtt:
        out.append("Route    : ~%d ms round trip Iran<->foreign%s" % (rtt, "  (long route: a closer foreign server will be faster)" if rtt > 250 else ""))
    inbound = result.get("inbound") or pair.get("runtime", {}).get("inbound")
    out.append("")
    if inbound == "open":
        out.append("Foreign inbound on port %s: listening. Clients can use %s now." % (port, endpoint))
    else:
        out.append("ACTION   : nothing listens on port %s on the foreign server yet." % port)
        out.append("           In your panel create the inbound on the foreign node: listen 0.0.0.0, port %s." % port)
        out.append("           Then give clients address %s, port %s (keep UUID/path/SNI of that inbound)." % (request.get("public_ip"), port))
    out.append("Manage   : sudo pronet watch | sudo pronet report | sudo pronet logs %s" % pair.get("id", ""))
    return out


def _why_primary(row):
    if not row:
        return "highest-ranked carrier that passed every test"
    jitter = None
    samples = row.get("echo_ms") or []
    if samples:
        jitter = (row.get("p95_ms") or 0) - sorted(samples)[len(samples) // 2]
    parts = ["highest stability-weighted score (%s)" % row.get("score"),
             "%s up / %s down Mbps sustained" % (mbps(row.get("upload_mbps")), mbps(row.get("download_mbps"))),
             "p95 latency %s ms" % _fmt(row.get("p95_ms"))]
    if jitter is not None:
        parts.append("jitter %s ms" % _fmt(max(0, jitter)))
    return "; ".join(parts) + "; passed integrity, half-close and idle tests"


def _route_rtt(scored, selected):
    for name in selected:
        row = scored.get(name)
        if row and row.get("echo_ms"):
            ordered = sorted(row["echo_ms"])
            return ordered[len(ordered) // 2]
    return None


def _failure_groups(failed):
    if not failed:
        return []
    groups = {}
    for row in failed:
        groups.setdefault(reason(row), []).append(row.get("profile", "?"))
    lines = ["  Failed :"]
    for text, names in sorted(groups.items(), key=lambda item: -len(item[1])):
        lines.append("    - %s: %s" % (text, ", ".join(names)))
    return lines
