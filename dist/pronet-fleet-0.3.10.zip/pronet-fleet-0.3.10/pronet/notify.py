"""Optional Telegram alerts (0.3.10).

Telegram is filtered in Iran, so messages leave from the FOREIGN server:
the coordinator (on Iran) queues short notices, the foreign agent picks them
up with its normal heartbeat and sends them. Nothing extra runs while there
is nothing to say: no polling, one HTTPS request per message batch.

If the Iran server itself is unreachable, the foreign agent notices this on
its own (no heartbeat answers) and says so after five minutes.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse
import urllib.request

from .common import CONFIG, PronetError, clean, read_json, write_json

NOTIFY_FILE = CONFIG / "notify.json"
NOTIFY_KINDS = {"ALL_PATHS_DOWN", "PATH_RESTORED", "FAILOVER", "RECOVERY_BUDGET_EXHAUSTED", "STANDBY_UNSTABLE",
                "ACTIVE_UNSTABLE", "STANDBY_REPLACED", "RETEST_STARTED", "RETEST_FINISHED", "NODE_STALE", "NODE_BACK"}
HUB_ALERT_AFTER = 300        # coordinator unreachable this long -> one alert
MAX_AGE = 86400              # undelivered alerts older than a day are dropped
RETRY = (30, 60, 120, 300, 600)
BATCH = 10

TEXT = {
    "en": {
        "ALL_PATHS_DOWN": "🔴 {pair}: tunnel DOWN, no carrier answers",
        "PATH_RESTORED": "🟢 {pair}: tunnel restored ({detail})",
        "FAILOVER": "🟠 {pair}: switched carrier, {detail}",
        "RECOVERY_BUDGET_EXHAUSTED": "⚠️ {pair}: automatic switching paused for this 30-minute window",
        "STANDBY_UNSTABLE": "🟡 {pair}: standby unstable, {detail}",
        "ACTIVE_UNSTABLE": "🟡 {pair}: primary unstable, {detail}",
        "STANDBY_REPLACED": "🔧 {pair}: standby replaced, {detail}",
        "RETEST_STARTED": "🔄 {pair}: re-testing carriers ({detail})",
        "RETEST_FINISHED": "🔄 {pair}: re-test finished, {detail}",
        "NODE_STALE": "🔴 {pair}: {role} server stopped reporting for 2+ minutes",
        "NODE_BACK": "🟢 {pair}: {role} server reporting again after {minutes} min",
        "HUB_DOWN": "🔴 Iran server unreachable from the foreign server for {detail} min; tunnels through it are likely down",
        "HUB_BACK": "🟢 Iran server reachable again (unreachable for {detail} min)",
        "TEST": "✅ Pronet Fleet: test message from {detail}",
    },
    "fa": {
        "ALL_PATHS_DOWN": "🔴 {pair}: تونل قطع است، هیچ حاملی جواب نمی‌دهد",
        "PATH_RESTORED": "🟢 {pair}: تونل دوباره وصل شد ({detail})",
        "FAILOVER": "🟠 {pair}: حامل عوض شد، {detail}",
        "RECOVERY_BUDGET_EXHAUSTED": "⚠️ {pair}: تعویض خودکار تا پایان این بازهٔ ۳۰ دقیقه‌ای متوقف شد",
        "STANDBY_UNSTABLE": "🟡 {pair}: پشتیبان ناپایدار است، {detail}",
        "ACTIVE_UNSTABLE": "🟡 {pair}: حامل اصلی ناپایدار است، {detail}",
        "STANDBY_REPLACED": "🔧 {pair}: پشتیبان عوض شد، {detail}",
        "RETEST_STARTED": "🔄 {pair}: تست دوباره حامل‌ها شروع شد ({detail})",
        "RETEST_FINISHED": "🔄 {pair}: تست دوباره تمام شد، {detail}",
        "NODE_STALE": "🔴 {pair}: سرور {role} بیش از ۲ دقیقه است گزارش نمی‌دهد",
        "NODE_BACK": "🟢 {pair}: سرور {role} بعد از {minutes} دقیقه دوباره گزارش می‌دهد",
        "HUB_DOWN": "🔴 سرور ایران از سرور خارج {detail} دقیقه است در دسترس نیست؛ تونل‌ها احتمالاً قطع‌اند",
        "HUB_BACK": "🟢 سرور ایران دوباره در دسترس است ({detail} دقیقه قطع بود)",
        "TEST": "✅ Pronet Fleet: پیام آزمایشی از {detail}",
    },
}


def render(notice, lang="en"):
    table = TEXT.get(lang, TEXT["en"])
    template = table.get(notice.get("kind"), "{pair}: {kind} {detail}")
    detail = clean(notice.get("detail", ""), 160)
    role, _, minutes = detail.partition(":")
    names = {"en": {"iran": "Iran", "foreign": "Foreign"}, "fa": {"iran": "ایران", "foreign": "خارج"}}
    text = template.format(pair=clean(notice.get("pair") or "Pronet", 40), kind=notice.get("kind", ""), detail=detail,
                           role=names.get(lang, names["en"]).get(role, role), minutes=minutes or "?")
    at = notice.get("utc")
    return text + ("\n" + at.replace("T", " ").replace("Z", " UTC") if isinstance(at, str) and at else "")


def load_config(path=None):
    path = path or NOTIFY_FILE
    config = read_json(path, {}) if os.path.exists(path) else {}
    telegram = config.get("telegram") if isinstance(config, dict) else None
    if not isinstance(telegram, dict) or not telegram.get("token") or not telegram.get("chat_id"):
        return None
    return {"token": str(telegram["token"]), "chat_id": str(telegram["chat_id"]),
            "lang": config.get("lang") if config.get("lang") in TEXT else "en",
            "enabled": config.get("enabled", True) is not False}


def save_config(token, chat_id, lang="en", path=None):
    token, chat_id = token.strip(), str(chat_id).strip()
    if not token or ":" not in token or any(c.isspace() for c in token) or len(token) > 100:
        raise PronetError("That does not look like a Telegram bot token (from @BotFather)")
    if not chat_id or len(chat_id) > 40 or not chat_id.lstrip("-@").replace("_", "").isalnum():
        raise PronetError("Invalid chat id")
    write_json(path or NOTIFY_FILE, {"telegram": {"token": token, "chat_id": chat_id},
                                     "lang": lang if lang in TEXT else "en", "enabled": True})
    os.chmod(path or NOTIFY_FILE, 0o600)


def send_telegram(config, text, timeout=10, opener=None):
    data = urllib.parse.urlencode({"chat_id": config["chat_id"], "text": text[:4000],
                                   "disable_web_page_preview": "true"}).encode()
    request = urllib.request.Request("https://api.telegram.org/bot%s/sendMessage" % config["token"], data=data)
    try:
        with (opener or urllib.request.urlopen)(request, timeout=timeout) as reply:
            answer = json.loads(reply.read(65536).decode() or "{}")
    except Exception as error:
        # Never echo the URL: it contains the bot token.
        raise PronetError("Telegram request failed: " + clean(str(error).replace(config["token"], "***"), 160))
    if not answer.get("ok"):
        raise PronetError("Telegram refused the message: " + clean(answer.get("description", ""), 160))


class Notifier:
    """Foreign-side sender. Idle costs nothing: the thread sleeps on a
    condition until a notice arrives (or a failed send is due again)."""

    def __init__(self, path=None, sender=send_telegram, clock=time.time):
        self.path, self.sender, self.clock = path or NOTIFY_FILE, sender, clock
        self.lock = threading.Condition()
        self.queue, self.acks, self.known = [], [], set()
        self.retry_at, self.failures = 0.0, 0
        self.hub_alerted, self.hub_down_since, self.stamp, self.cached = False, 0.0, None, None
        self.stop = threading.Event()
        self.thread = None

    def config(self):
        try:
            info = os.stat(self.path)
            stamp = (info.st_mtime_ns, info.st_size)
        except OSError:
            self.stamp, self.cached = None, None
            return None
        if stamp != self.stamp:
            self.stamp, self.cached = stamp, load_config(self.path)
        return self.cached

    def enabled(self):
        config = self.config()
        return bool(config and config["enabled"])

    def add(self, notices):
        """Notices from the coordinator: [{"id", "kind", "pair", "detail", "utc"}]."""
        with self.lock:
            for notice in notices or []:
                if not isinstance(notice, dict) or notice.get("id") in self.known:
                    continue
                self.known.add(notice.get("id"))
                self.queue.append(dict(notice, received=self.clock()))
            if len(self.known) > 2000:
                self.known = {n.get("id") for n in self.queue}
            pending = bool(self.queue)
            self.lock.notify_all()
        if pending:
            self.start()

    def local(self, kind, detail):
        self.add([{"id": "local-%s-%d" % (kind, self.clock() * 1000), "kind": kind, "detail": detail,
                   "local": True, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.clock()))}])

    def hub_state(self, down_seconds):
        """Called from the heartbeat loop with how long the coordinator has been unreachable."""
        now = self.clock()
        if down_seconds >= HUB_ALERT_AFTER and not self.hub_alerted:
            self.hub_alerted, self.hub_down_since = True, now - down_seconds
            self.local("HUB_DOWN", str(int(down_seconds // 60)))
        elif down_seconds == 0 and self.hub_alerted:
            self.hub_alerted = False
            self.local("HUB_BACK", str(max(1, int((now - self.hub_down_since) // 60))))

    def take_acks(self):
        with self.lock:
            acks, self.acks = self.acks[:50], self.acks[50:]
            return acks

    def requeue_acks(self, acks):
        with self.lock:
            self.acks = list(acks) + self.acks

    def flush(self):
        """Send what is due. Returns seconds until the next attempt (None: idle)."""
        config = self.config()
        with self.lock:
            now = self.clock()
            for notice in [n for n in self.queue if now - n["received"] > MAX_AGE]:
                self.queue.remove(notice)
                if not notice.get("local"):
                    self.acks.append(notice["id"])
            if not self.queue:
                return None
            if not config or not config["enabled"]:
                # Turned off meanwhile: drop quietly (still acknowledged).
                self.acks += [n["id"] for n in self.queue if not n.get("local")]
                self.queue = []
                return None
            if now < self.retry_at:
                return self.retry_at - now
            batch = self.queue[:BATCH]
        text = "\n\n".join(render(notice, config["lang"]) for notice in batch)
        try:
            self.sender(config, text)
        except PronetError:
            with self.lock:
                self.failures += 1
                self.retry_at = self.clock() + RETRY[min(self.failures, len(RETRY)) - 1]
                return self.retry_at - self.clock()
        with self.lock:
            self.failures, self.retry_at = 0, 0.0
            for notice in batch:
                if notice in self.queue:
                    self.queue.remove(notice)
                if not notice.get("local"):
                    self.acks.append(notice["id"])
            return 1.0 if self.queue else None   # Telegram allows ~1 message/s per chat

    def run(self):
        while not self.stop.is_set():
            wait = self.flush()
            with self.lock:
                if self.stop.is_set():
                    return
                if wait is None and not self.queue:
                    self.lock.wait()        # nothing to send: sleep until add()
                elif wait is not None:
                    self.lock.wait(min(wait, 600))

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self.run, daemon=True, name="notify")
            self.thread.start()

    def close(self):
        self.stop.set()
        with self.lock:
            self.lock.notify_all()
