"""Transactional pairing and leased, idempotent node operations."""
from __future__ import annotations

import contextlib
import hmac
import json
import pathlib
import secrets
import sqlite3
import time

from .common import PronetError, canonical, digest, identifier, secret
from .model import validate_request

OPERATIONS = {"inventory", "prepare", "start", "benchmark", "commit", "activate", "cleanup", "retire", "resume", "remeasure", "status",
              "prepare_batch", "start_batch", "probe_batch", "retire_batch"}
PAIR_CODE_SECONDS = 600
TERMINAL = {"ACTIVE", "FAILED", "STOPPED"}


class Connection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()


class Store:
    def __init__(self, path, enrollment_key, admin_key, clock=time.time):
        self.path = str(path)
        self.enrollment_hash, self.admin_hash = digest(enrollment_key), digest(admin_key)
        self.clock = clock
        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with self.connect() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS nodes (
              id TEXT PRIMARY KEY, credential TEXT NOT NULL, role TEXT NOT NULL,
              info TEXT NOT NULL, last REAL NOT NULL, metrics TEXT NOT NULL DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS pairs (
              id TEXT PRIMARY KEY, code TEXT NOT NULL, iran TEXT NOT NULL, foreign_node TEXT,
              expires REAL NOT NULL, state TEXT NOT NULL, request TEXT NOT NULL,
              result TEXT NOT NULL DEFAULT '{}', updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS failures (
              node TEXT PRIMARY KEY, window REAL NOT NULL, count INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS jobs (
              id TEXT PRIMARY KEY, pair_id TEXT NOT NULL, node TEXT NOT NULL,
              op TEXT NOT NULL, payload TEXT NOT NULL, state TEXT NOT NULL,
              lease REAL NOT NULL DEFAULT 0, tries INTEGER NOT NULL DEFAULT 0,
              result TEXT, created REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS jobs_node ON jobs(node,state);
            CREATE TABLE IF NOT EXISTS events (
              id INTEGER PRIMARY KEY AUTOINCREMENT, pair_id TEXT, at REAL, kind TEXT, detail TEXT);
            """)
            columns = {row[1] for row in db.execute("PRAGMA table_info(pairs)")}
            if "desired" not in columns:
                db.execute("ALTER TABLE pairs ADD COLUMN desired TEXT NOT NULL DEFAULT 'run'")
        pathlib.Path(path).chmod(0o600)

    def connect(self):
        db = sqlite3.connect(self.path, timeout=15, factory=Connection)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=15000")
        return db

    @contextlib.contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def admin(self, token):
        return isinstance(token, str) and hmac.compare_digest(digest(token), self.admin_hash)

    def enroll(self, enrollment_key, info):
        if not isinstance(enrollment_key, str) or not hmac.compare_digest(digest(enrollment_key), self.enrollment_hash):
            raise PronetError("Enrollment refused")
        if not isinstance(info, dict) or set(info) != {"role", "public_ip", "bind_ip", "name"}:
            raise PronetError("Invalid node identity")
        from .common import ipv4
        if info["role"] not in ("iran", "foreign"):
            raise PronetError("Choose Iran or Foreign")
        info["public_ip"], info["bind_ip"] = ipv4(info["public_ip"]), ipv4(info["bind_ip"])
        if not isinstance(info["name"], str) or not 1 <= len(info["name"]) <= 60 or any(ord(c) < 32 for c in info["name"]):
            raise PronetError("Invalid node name")
        node_id, credential = secrets.token_hex(12), secret()
        with self.transaction() as db:
            if db.execute("SELECT count(*) FROM nodes").fetchone()[0] >= 2000:
                raise PronetError("Node limit reached")
            db.execute("INSERT INTO nodes(id,credential,role,info,last) VALUES(?,?,?,?,?)",
                       (node_id, digest(credential), info["role"], canonical(info).decode(), self.clock()))
        return {"node_id": node_id, "node_secret": credential}

    def authenticate(self, token):
        try:
            node_id, credential = token.split(":", 1)
            identifier(node_id)
        except (ValueError, AttributeError, PronetError):
            raise PronetError("Authentication refused")
        with self.connect() as db:
            node = db.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()
        if node is None or not hmac.compare_digest(digest(credential), node["credential"]):
            raise PronetError("Authentication refused")
        return dict(node)

    def heartbeat(self, node, metrics):
        if not isinstance(metrics, dict) or len(canonical(metrics)) > 131072:
            raise PronetError("Invalid metrics")
        if not isinstance(metrics.get("resources", {}), dict):
            raise PronetError("Invalid resource metrics")
        pairs = metrics.get("pairs", [])
        if not isinstance(pairs, list) or len(pairs) > 100:
            raise PronetError("Invalid pair metrics")
        for pair in pairs:
            if not isinstance(pair, dict): raise PronetError("Invalid pair metrics")
            identifier(pair.get("id"))
            for key in ("selection", "profiles", "active", "traffic"):
                if not isinstance(pair.get(key, {}), dict): raise PronetError("Invalid pair metrics")
        traffic = metrics.get("ip_traffic", {})
        if not isinstance(traffic, dict) or not isinstance(traffic.get("ips", []), list) or len(traffic.get("ips", [])) > 512:
            raise PronetError("Invalid IP metrics")
        for row in traffic.get("ips", []):
            if not isinstance(row, dict) or not all(key in row for key in ("ip", "assignment", "activity")):
                raise PronetError("Invalid IP metrics")
        with self.connect() as db:
            db.execute("UPDATE nodes SET last=?,metrics=? WHERE id=?",
                       (self.clock(), canonical(metrics).decode(), node["id"]))
        return {"ok": True}

    def create_pair(self, node, request):
        if node["role"] != "iran":
            raise PronetError("Only Iran can create a pair")
        request = validate_request(request)
        # The carrier identity remains fixed at enrollment. A separate gateway
        # address is allowed for a multi-IP Iran; the local agent must verify
        # its assignment before any listener is created.
        current = self.clock()
        with self.transaction() as db:
            db.execute("UPDATE pairs SET state='FAILED',result=? WHERE state='UNPAIRED' AND expires<?",
                       ('{"error":"Pairing code expired"}', current))
            pending = db.execute("SELECT count(*) FROM pairs WHERE state='UNPAIRED'").fetchone()[0]
            if pending >= 100:
                raise PronetError("Too many pending pairs")
            existing = db.execute("SELECT request FROM pairs WHERE iran=? AND state NOT IN ('FAILED','STOPPED')", (node["id"],)).fetchall()
            for row in existing:
                other = json.loads(row[0])
                if (other["bind_ip"], other["inbound_port"]) == (request["bind_ip"], request["inbound_port"]):
                    raise PronetError("This endpoint is already reserved by a pair")
            occupied = {row[0] for row in db.execute("SELECT code FROM pairs WHERE state='UNPAIRED'")}
            for _ in range(100):
                code = f"{secrets.randbelow(10000):04d}"
                if code not in occupied:
                    break
            else:
                raise PronetError("Could not allocate pairing code")
            pair_id = secrets.token_hex(12)
            db.execute("INSERT INTO pairs(id,code,iran,expires,state,request,updated) VALUES(?,?,?,?,?,?,?)",
                       (pair_id, code, node["id"], current + PAIR_CODE_SECONDS, "UNPAIRED", canonical(request).decode(), current))
        return {"pair_id": pair_id, "code": code, "expires_in": PAIR_CODE_SECONDS}

    def join_pair(self, node, code):
        if node["role"] != "foreign":
            raise PronetError("Only Foreign can join")
        if not isinstance(code, str) or len(code) != 4 or not code.isascii() or not code.isdigit():
            raise PronetError("Enter the four digits exactly")
        current = self.clock()
        failed = False
        pair_id = None
        with self.transaction() as db:
            record = db.execute("SELECT * FROM failures WHERE node=?", (node["id"],)).fetchone()
            count = record["count"] if record and current - record["window"] < 300 else 0
            if count >= 5:
                raise PronetError("Too many pairing attempts; wait five minutes")
            row = db.execute("SELECT * FROM pairs WHERE code=? AND state='UNPAIRED' AND expires>=?", (code, current)).fetchone()
            if row is None:
                window = record["window"] if count else current
                db.execute("INSERT OR REPLACE INTO failures VALUES(?,?,?)", (node["id"], window, count + 1))
                failed = True  # Commit attempts even though the response is an error.
            else:
                if row["iran"] == node["id"]:
                    raise PronetError("A node cannot pair with itself")
                active = db.execute("SELECT count(*) FROM pairs WHERE foreign_node=? AND state NOT IN ('FAILED','STOPPED')", (node["id"],)).fetchone()[0]
                if active:
                    raise PronetError("This foreign node already belongs to a pair; use a separate node configuration")
                db.execute("UPDATE pairs SET foreign_node=?,state='PAIRED',updated=? WHERE id=? AND state='UNPAIRED'",
                           (node["id"], current, row["id"]))
                pair_id = row["id"]
        if failed:
            raise PronetError("Code not available or expired")
        return {"pair_id": pair_id, "state": "PAIRED"}

    def pair(self, pair_id):
        identifier(pair_id)
        with self.connect() as db:
            row = db.execute("SELECT * FROM pairs WHERE id=?", (pair_id,)).fetchone()
            if row is None:
                raise PronetError("Unknown pair")
            result = dict(row)
            for name in ("request", "result"):
                result[name] = json.loads(result[name])
            for role, column in (("iran_info", "iran"), ("foreign_info", "foreign_node")):
                node = db.execute("SELECT info FROM nodes WHERE id=?", (result[column],)).fetchone()
                result[role] = json.loads(node[0]) if node else None
            return result

    def update_pair(self, pair_id, state, result):
        with self.transaction() as db:
            current = db.execute("SELECT desired,result FROM pairs WHERE id=?", (identifier(pair_id),)).fetchone()
            if current and current["desired"] == "stop" and state not in ("STOPPED", "STOP_UNCONFIRMED"):
                result = dict(result, phase="operator-stop")
                previous = json.loads(current["result"])
                if "stop_request" in previous:
                    result["stop_request"] = previous["stop_request"]
                state = "STOPPING"
            db.execute("UPDATE pairs SET state=?,result=?,updated=? WHERE id=?",
                       (state, canonical(result).decode(), self.clock(), identifier(pair_id)))
            db.execute("INSERT INTO events(pair_id,at,kind,detail) VALUES(?,?,?,?)",
                       (pair_id, self.clock(), state, canonical({k: v for k, v in result.items() if k in ('error','phase','active','warnings')}).decode()))
            db.execute("DELETE FROM events WHERE id < (SELECT coalesce(max(id),0)-10000 FROM events)")

    def pending(self):
        with self.connect() as db:
            return [row[0] for row in db.execute("SELECT id FROM pairs WHERE desired='run' AND state IN ('PAIRED','PREFLIGHT','TRIAL','STAGED','VERIFYING','ROLLING_BACK')")]

    def stopping(self):
        with self.connect() as db:
            return [row[0] for row in db.execute("SELECT id FROM pairs WHERE desired='stop' AND state NOT IN ('STOPPED','STOP_UNCONFIRMED')")]

    def request_stop(self, node, pair_id):
        pair = self.pair(pair_id)
        if node["id"] not in (pair["iran"], pair["foreign_node"]):
            raise PronetError("This node does not own the pair")
        if pair["state"] == "STOPPED": return {"state": "STOPPED", "pair_id": pair_id}
        result = pair["result"]
        result["stop_request"] = secrets.token_hex(12)
        result["phase"] = "operator-stop"
        with self.transaction() as db:
            db.execute("UPDATE pairs SET desired='stop',state='STOPPING',result=?,updated=? WHERE id=?",
                       (canonical(result).decode(), self.clock(), pair_id))
        self.cancel_pending(pair_id)
        return {"state": "STOPPING", "pair_id": pair_id}

    def enqueue(self, pair_id, node_id, op, payload, step):
        if op not in OPERATIONS:
            raise PronetError("Operation not allowed")
        pair = self.pair(pair_id)
        if node_id not in (pair["iran"], pair["foreign_node"]):
            raise PronetError("Node is not a member of the pair")
        job_id = digest(pair_id + ":" + step)[:24]
        encoded = canonical(payload).decode()
        with self.transaction() as db:
            desired = db.execute("SELECT desired FROM pairs WHERE id=?", (pair_id,)).fetchone()[0]
            if desired == "stop" and op != "cleanup":
                raise PronetError("Operator requested a stop")
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row:
                if (row["op"], row["payload"], row["node"]) != (op, encoded, node_id):
                    raise PronetError("Idempotency key was reused for a different operation")
            else:
                db.execute("INSERT INTO jobs(id,pair_id,node,op,payload,state,created) VALUES(?,?,?,?,?,'queued',?)",
                           (job_id, pair_id, node_id, op, encoded, self.clock()))
        return job_id

    def claim(self, node):
        current = self.clock()
        with self.transaction() as db:
            rows = db.execute("SELECT jobs.* FROM jobs JOIN pairs ON pairs.id=jobs.pair_id WHERE node=? AND (jobs.state='queued' OR (jobs.state='leased' AND lease<?)) AND (pairs.state NOT IN ('FAILED','STOPPED') OR jobs.op='cleanup') AND (pairs.desired='run' OR jobs.op='cleanup') ORDER BY created LIMIT 1",
                              (node["id"], current)).fetchall()
            if not rows:
                return None
            row = rows[0]
            if row["tries"] >= 3:
                db.execute("UPDATE jobs SET state='done',result=? WHERE id=?", ('{"ok":false,"error":"Job lease retry budget exhausted"}', row["id"]))
                return None
            # Nodes execute at most one job; a random lease proof rejects a
            # delayed result from a superseded worker.
            proof = secret()
            lease = current + 180
            db.execute("UPDATE jobs SET state='leased',lease=?,tries=tries+1,result=? WHERE id=?",
                       (lease, canonical({"lease_proof": proof}).decode(), row["id"]))
            return {"id": row["id"], "pair_id": row["pair_id"], "op": row["op"],
                    "payload": json.loads(row["payload"]), "lease_proof": proof, "lease_until": lease}

    def finish(self, node, job_id, proof, result):
        identifier(job_id)
        if not isinstance(result, dict) or type(result.get("ok")) is not bool or len(canonical(result)) > 131072:
            raise PronetError("Invalid job result")
        with self.transaction() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=? AND node=?", (job_id, node["id"])).fetchone()
            if row is None:
                raise PronetError("Job not assigned to this node")
            previous = json.loads(row["result"] or "{}")
            if row["state"] == "done":
                if previous == result:
                    return {"ok": True}
                raise PronetError("Completed job cannot be overwritten")
            if not isinstance(proof, str) or not hmac.compare_digest(previous.get("lease_proof", ""), proof):
                raise PronetError("Job lease was superseded")
            db.execute("UPDATE jobs SET state='done',result=? WHERE id=?", (canonical(result).decode(), job_id))
        return {"ok": True}

    def job_result(self, job_id):
        with self.connect() as db:
            row = db.execute("SELECT state,result FROM jobs WHERE id=?", (job_id,)).fetchone()
        return json.loads(row["result"]) if row and row["state"] == "done" else None

    def cancel_pending(self, pair_id):
        with self.connect() as db:
            db.execute("UPDATE jobs SET state='done',result=? WHERE pair_id=? AND state='queued' AND op!='cleanup'",
                       ('{"ok":false,"error":"Setup canceled"}', identifier(pair_id)))

    def overview(self, node=None):
        current = self.clock()
        with self.connect() as db:
            allowed_nodes = None
            if node:
                allowed_nodes = {node["id"]}
                for row in db.execute("SELECT iran,foreign_node FROM pairs WHERE iran=? OR foreign_node=?", (node["id"], node["id"])):
                    allowed_nodes.update(x for x in row if x)
            nodes = []
            for row in db.execute("SELECT id,role,info,last,metrics FROM nodes"):
                if allowed_nodes is not None and row["id"] not in allowed_nodes:
                    continue
                nodes.append({"id": row["id"], "role": row["role"], "info": json.loads(row["info"]),
                              "age_seconds": max(0, round(current - row["last"])),
                              "telemetry": "CURRENT" if current - row["last"] < 45 else "STALE",
                              "metrics": json.loads(row["metrics"])})
            pairs = []
            for row in db.execute("SELECT * FROM pairs ORDER BY updated DESC"):
                if node and node["id"] not in (row["iran"], row["foreign_node"]):
                    continue
                result = json.loads(row["result"])
                safe = {k: v for k, v in result.items() if k in ("phase", "error", "warnings", "results", "selected", "active", "endpoint", "recovery", "progress", "timing", "inbound")}
                pairs.append({"id": row["id"], "iran": row["iran"], "foreign": row["foreign_node"],
                              "state": row["state"], "request": json.loads(row["request"]), "result": safe,
                              "updated": row["updated"]})
            by_id = {item["id"]: item for item in nodes}
            for pair in pairs:
                own = by_id.get(pair["iran"], {})
                remote = by_id.get(pair["foreign"], {})
                observed = next((item for item in own.get("metrics", {}).get("pairs", []) if item.get("id") == pair["id"]), {})
                other = next((item for item in remote.get("metrics", {}).get("pairs", []) if item.get("id") == pair["id"]), {})
                selected = observed.get("selection", {})
                state = "UNKNOWN"
                if own.get("telemetry") == "CURRENT":
                    if observed.get("state") == "STOPPED": state = "STOPPED"
                    elif selected.get("last_probe") == "OK": state = "UP"
                    elif selected.get("last_probe"): state = "UNCONFIRMED"
                pair["runtime"] = {"link": state, "active": selected.get("active"),
                                   "recovery_paused": selected.get("auto_paused", False),
                                   "pause_id": selected.get("pause_id"), "remote_stopped": other.get("state") == "STOPPED",
                                   "rtt_ms": selected.get("rtt_ms") if state == "UP" else None,
                                   "inbound": other.get("inbound", "UNKNOWN") if remote.get("telemetry") == "CURRENT" else "UNKNOWN",
                                   "standby_health": selected.get("standby_health", {}) if own.get("telemetry") == "CURRENT" and isinstance(selected.get("standby_health", {}), dict) else {},
                                   "traffic": observed.get("traffic", {})}
        return {"nodes": nodes, "pairs": pairs, "server_time": current}
