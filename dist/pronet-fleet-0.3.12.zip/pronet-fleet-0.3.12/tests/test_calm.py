"""Fewer, better-founded carrier switches (0.3.12)."""
import asyncio
import json
import pathlib
import random
import tempfile
import time
import unittest
from unittest import mock

from pronet import runtime as rt
from pronet.common import read_json, write_json

from test_resilience import Base


class CalmBase(Base):
    def run_cycles(self, attempt, count):
        """attempt(name, cycle) -> True when ONE echo attempt to that carrier fails."""
        calls = {"n": 0}
        for cycle in range(count):
            def probe(address, *_):
                calls["n"] += 1
                if attempt(address, cycle):
                    raise TimeoutError("lost")
                return 120.0
            with mock.patch("pronet.runtime.echo", side_effect=probe):
                self.runtime.watchdog()
            self.clock[0] += 60
        return calls["n"]

    def traffic(self, name, age):
        write_json(self.dir / "traffic.json", {"backend_rx_at": {"%s:1" % name: self.clock[0] - age}})


class ChecksTests(CalmBase):
    def test_a_lost_probe_that_succeeds_on_retry_is_not_an_outage(self):
        tries = {}
        def attempt(name, cycle):
            tries[(name, cycle)] = tries.get((name, cycle), 0) + 1
            return tries[(name, cycle)] == 1          # first attempt of every check is lost
        self.run_cycles(attempt, 10)
        history = self.selection()["history"]
        self.assertTrue(all(ok for rows in history.values() for _, ok in rows))
        self.assertEqual(self.selection()["active"], "frp-tls")

    def test_busy_tunnel_with_slow_echo_is_not_switched_away(self):
        with mock.patch("pronet.runtime.time.time", side_effect=lambda: self.clock[0]):
            for _ in range(10):
                self.traffic("frp-tls", 5)            # users' data keeps arriving
                self.run_cycles(lambda name, c: name == "frp-tls", 1)
        selected = self.selection()
        self.assertEqual(selected["active"], "frp-tls")
        self.assertEqual(selected["last_probe"], "OK")
        self.assertTrue(selected["by_traffic"])
        self.assertNotIn("FAILOVER", self.events())

    def test_old_traffic_is_no_proof(self):
        with mock.patch("pronet.runtime.time.time", side_effect=lambda: self.clock[0]):
            for _ in range(3):
                self.traffic("frp-tls", rt.TRAFFIC_ALIVE + 30)
                self.run_cycles(lambda name, c: name == "frp-tls", 1)
        self.assertNotEqual(self.selection()["active"], "frp-tls")

    def test_failover_needs_three_failed_checks(self):
        self.run_cycles(lambda name, c: name == "frp-tls", 2)
        self.assertEqual(self.selection()["active"], "frp-tls")
        self.run_cycles(lambda name, c: name == "frp-tls", 1)
        self.assertNotEqual(self.selection()["active"], "frp-tls")

    def test_failover_target_is_the_best_record_not_the_lowest_rtt(self):
        selected = self.selection()
        selected["history"] = {"bp-l3-pck-reverse": [[self.clock[0] - 600, 0], [self.clock[0] - 500, 1]]}
        write_json(self.dir / "selection.json", selected)
        def rtt(address, *_):
            if address == "frp-tls":
                raise TimeoutError("down")
            return 20.0 if address == "bp-l3-pck-reverse" else 90.0
        for _ in range(3):
            with mock.patch("pronet.runtime.echo", side_effect=rtt):
                self.runtime.watchdog()
            self.clock[0] += 60
        self.assertEqual(self.selection()["active"], "bp-stealth", "no failure in the last hour beats a lower rtt")


class SoftSwitchTests(CalmBase):
    flap = staticmethod(lambda name, c: name == "frp-tls" and c % 3 == 2)

    def test_no_unstable_switch_within_two_hours_of_a_switch(self):
        selected = self.selection()
        selected["last_switch_at"] = self.clock[0] - 600
        write_json(self.dir / "selection.json", selected)
        self.run_cycles(self.flap, 12)
        self.assertEqual(self.selection()["active"], "frp-tls")
        self.assertIn("ACTIVE_UNSTABLE", self.events(), "still reported, just not acted on")

    def test_operator_choice_is_kept_for_a_day_except_for_a_real_outage(self):
        selected = self.selection()
        selected["manual_switch_at"] = selected["last_switch_at"] = self.clock[0] - 3 * 3600
        write_json(self.dir / "selection.json", selected)
        self.run_cycles(self.flap, 12)
        self.assertEqual(self.selection()["active"], "frp-tls")
        self.run_cycles(lambda name, c: name == "frp-tls", 3)
        self.assertNotEqual(self.selection()["active"], "frp-tls", "a real outage still fails over")


class LossyRouteTests(CalmBase):
    def test_a_day_on_a_lossy_route_causes_no_switch(self):
        """10% of single echo attempts lost, plus a 15-minute bad patch with
        35% loss: the old single-attempt check switched within the hour."""
        rng = random.Random(7)
        def attempt(name, cycle):
            loss = .35 if 600 <= cycle < 615 else .10
            return rng.random() < loss
        self.run_cycles(attempt, 24 * 60)
        events = self.events()
        self.assertNotIn("FAILOVER", events)
        self.assertEqual(self.selection()["active"], "frp-tls")
        self.assertEqual(self.selection()["switches"], [])

    def test_idle_cost_is_one_echo_per_carrier_per_minute(self):
        calls = self.run_cycles(lambda name, c: False, 60)
        self.assertEqual(calls, 60 * len(self.profiles))


class GatewayProofTests(unittest.TestCase):
    def test_gateway_records_when_each_carrier_last_delivered_data(self):
        from pronet.wire import Gateway
        async def scenario(directory):
            async def backend(reader, writer):
                data = await reader.read(100)
                writer.write(data.upper()); await writer.drain(); writer.close()
            server = await asyncio.start_server(backend, "127.0.0.1", 0)
            port = server.sockets[0].getsockname()[1]
            write_json(directory / "gateway.json", {"bind_ip": "127.0.0.1", "port": 0, "mode": "plain",
                                                    "active_backend": ["127.0.0.1", port]})
            gateway = Gateway(directory / "gateway.json", directory / "traffic.json")
            address = await gateway.start()
            reader, writer = await asyncio.open_connection(*address[:2])
            writer.write(b"hello"); await writer.drain(); writer.write_eof()
            self.assertEqual(await reader.read(100), b"HELLO")
            writer.close()
            await asyncio.sleep(.2)
            seen = dict(gateway.backend_rx)
            await gateway.close()
            server.close()
            return port, seen
        with tempfile.TemporaryDirectory() as temporary:
            port, seen = asyncio.run(scenario(pathlib.Path(temporary)))
        self.assertIn("127.0.0.1:%d" % port, seen)
        self.assertLess(time.time() - seen["127.0.0.1:%d" % port], 5)


_PAUSE = None


def setUpModule():
    global _PAUSE
    _PAUSE = mock.patch("pronet.runtime.retry_pause", lambda seconds: None)
    _PAUSE.start()


def tearDownModule():
    _PAUSE.stop()


if __name__ == "__main__":
    unittest.main()
