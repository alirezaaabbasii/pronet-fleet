"""Manual return to the main carrier: CLI and dashboard button (0.3.11)."""
import http.client
import pathlib
import tempfile
import threading
import time
import unittest
import urllib.parse
from unittest import mock

from pronet import runtime as rt
from pronet.common import PronetError, read_json, secret, write_json

from test_resilience import Base


class ManualSwitchTests(Base):
    def fail_over(self):
        self.cycles(lambda name, c: name == "frp-tls", 2)       # primary dies -> standby
        self.assertNotEqual(self.selection()["active"], "frp-tls")
        self.cycles(lambda name, c: False, 1)                     # primary healthy again
        self.assertNotEqual(self.selection()["active"], "frp-tls", "no automatic return")

    def switch(self, profile=None, down=()):
        def probe(address, *_):
            if address in down:
                raise TimeoutError("down")
            return 42.0
        with mock.patch("pronet.runtime.echo", side_effect=probe):
            return self.runtime.manual_switch("a" * 24, profile)

    def test_back_to_main_moves_only_new_connections_and_keeps_the_budget(self):
        self.fail_over()
        standby = self.selection()["active"]
        switches = list(self.selection()["switches"])
        result = self.switch()
        self.assertEqual(result, {"switched": True, "active": "frp-tls", "rtt_ms": 42.0})
        selected = self.selection()
        self.assertEqual(selected["active"], "frp-tls")
        self.assertEqual(selected["switches"], switches, "an operator switch uses no automatic budget")
        gateway = read_json(self.dir / "gateway.json")
        self.assertEqual(gateway["active_backend"], ["frp-tls", 1])
        self.assertEqual(gateway["failed_backends"], [], "sessions on the healthy standby are not cut")
        self.assertIn("MANUAL_SWITCH", self.events())
        self.cycles(lambda name, c: False, 2)
        self.assertEqual(self.selection()["active"], "frp-tls", "the watchdog keeps the operator's choice")
        self.assertNotEqual(standby, "frp-tls")

    def test_refused_when_main_does_not_answer_and_nothing_changes(self):
        self.fail_over()
        before = self.selection()["active"]
        with self.assertRaises(PronetError) as raised:
            self.switch(down=("frp-tls",))
        self.assertIn("not answering", str(raised.exception))
        self.assertEqual(self.selection()["active"], before)

    def test_already_on_main_unknown_target_and_quick_repeat(self):
        self.assertEqual(self.switch()["switched"], False)
        with self.assertRaises(PronetError):
            self.switch("chisel")
        self.switch("bp-stealth")
        with self.assertRaises(PronetError) as raised:
            self.switch()
        self.assertIn("wait", str(raised.exception))
        self.clock[0] += rt.MANUAL_SWITCH_GAP + 1
        self.assertTrue(self.switch()["switched"])

    def test_old_drain_list_never_cuts_a_healthy_carrier_later(self):
        self.fail_over()                       # failover drained frp-tls
        self.switch()                          # back to main
        self.clock[0] += rt.MANUAL_SWITCH_GAP + 1
        self.switch("bp-stealth")              # and away again
        self.assertEqual(read_json(self.dir / "gateway.json")["failed_backends"], [])

    def test_only_on_iran(self):
        self.runtime.identity = {"role": "foreign"}
        with self.assertRaises(PronetError):
            self.switch()


class DashboardButtonTests(unittest.TestCase):
    def overview(self, active="bp-stealth", main_state="OK"):
        return {"server_time": time.time(),
                "nodes": [{"id": "i", "telemetry": "CURRENT", "role": "iran", "info": {"name": "ir"}},
                          {"id": "f", "telemetry": "CURRENT", "role": "foreign", "info": {"name": "fo"}}],
                "pairs": [{"id": "a" * 24, "iran": "i", "foreign": "f", "state": "ACTIVE",
                           "request": {"name": "office", "public_ip": "192.0.2.1", "inbound_port": 2053},
                           "result": {},
                           "runtime": {"link": "UP", "active": active, "profiles": ["frp-tls", "bp-stealth"],
                                       "standby_health": {"frp-tls": {"state": main_state, "rtt_ms": 40},
                                                          "bp-stealth": {"state": "OK", "rtt_ms": 50}}}}]}

    def test_button_only_when_off_main_and_main_answers(self):
        from pronet.dashboard import render
        page = render(self.overview(), "/tok/")
        self.assertIn('<form class="action" method="post" action="/tok/">', page)
        self.assertIn("بازگشت به تونل اصلی (frp-tls)", page)
        self.assertNotIn("<form", render(self.overview(main_state="UNCONFIRMED"), "/tok/"))
        self.assertIn("هنوز جواب نمی‌دهد", render(self.overview(main_state="UNCONFIRMED"), "/tok/"))
        self.assertNotIn("<form", render(self.overview(active="frp-tls"), "/tok/"))
        self.assertIn("انجام شد", render(self.overview(active="frp-tls"), "/tok/", "ok"))
        self.assertIn('content="15;url=/tok/"', render(self.overview(), "/tok/", "ok"))

    def test_terminal_status_shows_the_command(self):
        import contextlib, io
        from pronet import cli
        out = io.StringIO()
        with contextlib.redirect_stdout(out), mock.patch.object(cli, "hub_config", return_value=None):
            cli.display(self.overview())
        self.assertIn("sudo pronet switch " + "a" * 24, out.getvalue())


class DashboardPostTests(unittest.TestCase):
    def setUp(self):
        from pronet.hub import HubServer
        from pronet.store import Store
        self.tmp = tempfile.TemporaryDirectory()
        enroll = secret()
        self.store = Store(pathlib.Path(self.tmp.name) / "h.db", enroll, secret())
        nodes = {}
        for number, role in ((1, "iran"), (2, "foreign")):
            cred = self.store.enroll(enroll, {"role": role, "name": role, "public_ip": "192.0.2.%d" % number,
                                              "bind_ip": "192.0.2.%d" % number})
            nodes[role] = self.store.authenticate(cred["node_id"] + ":" + cred["node_secret"])
        self.iran = nodes["iran"]
        pair = self.store.create_pair(self.iran, {"name": "office", "public_ip": "192.0.2.1", "inbound_port": 2053})
        self.store.join_pair(nodes["foreign"], pair["code"])
        self.pair_id = pair["pair_id"]
        self.store.update_pair(self.pair_id, "ACTIVE", {})
        self.token = secret()[:32]
        self.server = HubServer(("127.0.0.1", 0), self.store, public_url="https://192.0.2.1:8443",
                                dashboard_token=self.token)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close()
        self.tmp.cleanup()

    def agent(self, result):
        """Plays the Iran agent: claims the switch job and answers it."""
        def run():
            for _ in range(40):
                job = self.store.claim(self.iran, "main")
                if job:
                    self.assertEqual(job["op"], "switch")
                    self.store.finish(self.iran, job["id"], job["lease_proof"], result)
                    return
                time.sleep(.1)
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return thread

    def post(self, body, origin=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=20)
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        if origin:
            headers["Origin"] = origin
        connection.request("POST", "/" + self.token + "/", urllib.parse.urlencode(body), headers)
        reply = connection.getresponse()
        reply.read()
        connection.close()
        return reply.status, reply.getheader("Location")

    def test_button_runs_the_switch_on_iran_and_reports_the_outcome(self):
        self.agent({"ok": True, "data": {"switched": True, "active": "frp-tls"}})
        self.assertEqual(self.post({"pair": self.pair_id}, "https://192.0.2.1:8443"), (303, "/" + self.token + "/?r=ok"))
        self.agent({"ok": False, "error": "frp-tls is not answering right now; nothing was changed"})
        self.assertEqual(self.post({"pair": self.pair_id}), (303, "/" + self.token + "/?r=down"))

    def test_other_sites_and_bad_requests_are_refused(self):
        self.assertEqual(self.post({"pair": self.pair_id}, "https://evil.example")[0], 403)
        self.assertEqual(self.post({"pair": "nope"})[1], "/" + self.token + "/?r=fail")
        self.assertIsNone(self.store.claim(self.iran, "main"), "no job queued for a refused request")


if __name__ == "__main__":
    unittest.main()
