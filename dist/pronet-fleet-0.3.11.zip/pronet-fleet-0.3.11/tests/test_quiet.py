"""Long outages stay quiet; Telegram alerts (0.3.10)."""
import json
import pathlib
import tempfile
import threading
import time
import unittest
from unittest import mock

from pronet import agent, notify
from pronet.common import PronetError, secret
from pronet.controller import Controller, RETEST_AFTER

from test_resilience import Base


class Clock:
    def __init__(self, start=1000.0):
        self.now = start

    def __call__(self):
        return self.now


class HubLinkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = mock.patch.object(agent, "ROOT", pathlib.Path(self.tmp.name))
        self.root.start()

    def tearDown(self):
        self.root.stop()
        self.tmp.cleanup()

    def events(self):
        path = pathlib.Path(self.tmp.name) / "agent-events.jsonl"
        return [json.loads(line)["event"] for line in path.read_text().splitlines()] if path.exists() else []

    def test_backoff_grows_to_one_attempt_a_minute_and_logs_once(self):
        clock = Clock()
        link = agent.HubLink(clock)
        with mock.patch.object(agent.random, "uniform", return_value=1.0):
            delays = []
            for _ in range(7):
                delays.append(link.failed(OSError("unreachable")))
                clock.now += delays[-1]
        self.assertEqual([round(d) for d in delays], [5, 10, 20, 40, 60, 60, 60])
        self.assertEqual(self.events(), ["HUB_UNAVAILABLE"])
        clock.now += agent.HUB_REMINDER
        link.failed(OSError("unreachable"))
        self.assertEqual(self.events()[-1], "HUB_STILL_UNAVAILABLE")
        link.ok()
        self.assertEqual(self.events()[-1], "HUB_RESTORED")
        self.assertEqual(link.wait_time(), 0)

    def test_three_hour_outage_costs_about_one_request_a_minute(self):
        clock = Clock()
        instance = object.__new__(agent.Agent)
        instance.config = {"role": "iran"}
        instance.stop = threading.Event()
        instance.__dict__["_hub"] = agent.HubLink(clock)
        calls, collected = [], []
        def call(path, data=None, timeout=15):
            calls.append(path)
            raise PronetError("timed out")
        instance.client = mock.Mock(call=call)
        instance.metrics = lambda: collected.append(1) or {}
        def wait(seconds):
            clock.now += seconds
            if clock.now > 1000 + 3 * 3600:
                instance.stop.set()
            return instance.stop.is_set()
        with mock.patch.object(instance.stop, "wait", side_effect=wait), \
                mock.patch.object(agent.time, "monotonic", clock):
            instance.heartbeat()
        self.assertLess(len(calls), 3 * 60 + 10, "at most about one heartbeat attempt a minute")
        self.assertEqual(len(collected), len(calls), "metrics are only collected for a real attempt")
        self.assertEqual(self.events().count("HUB_UNAVAILABLE"), 1)
        self.assertLessEqual(self.events().count("HUB_STILL_UNAVAILABLE"), 12)


class IdleHoldTests(unittest.TestCase):
    def test_route_that_cuts_long_requests_falls_back_to_the_short_hold(self):
        instance = object.__new__(agent.Agent)
        clock = Clock()
        def call(path, timeout=15):
            clock.now += 15
            raise PronetError("connection reset")
        instance.client = mock.Mock(call=call)
        with mock.patch.object(agent.time, "monotonic", clock), self.assertRaises(PronetError):
            instance.claim("main", agent.IDLE_WAIT)
        self.assertEqual(instance.idle_wait, agent.JOB_WAIT)


class RestartDelayTests(unittest.TestCase):
    def test_quick_exits_back_off_and_a_normal_run_resets(self):
        from pronet.cli import restart_delay
        with tempfile.TemporaryDirectory() as temporary:
            now, delays = 1000.0, []
            for _ in range(9):
                delay = restart_delay(temporary, now)
                delays.append(delay)
                now += delay + 10          # exits 10 s after it really started
            self.assertEqual(delays, [0, 0, 0, 5, 10, 20, 40, 60, 60])
            self.assertEqual(restart_delay(temporary, now + 3600), 0, "a long healthy run resets the backoff")

    def test_permanent_units_rate_limit_logs_and_restarts_on_new_systemd(self):
        from pronet import runtime
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "unit.service"
            for version, expect_steps in ((255, True), (249, False), (0, False)):
                with mock.patch("pronet.runtime.unit_path", return_value=path), \
                        mock.patch.object(runtime, "systemd_version", return_value=version):
                    runtime.write_unit("pronetf-test.service", "test", ["/usr/bin/true"], pathlib.Path(temporary), temporary=False)
                text = path.read_text()
                self.assertEqual("RestartMaxDelaySec=60" in text, expect_steps)
                self.assertEqual("LogRateLimitBurst=" in text, version >= 240)
                self.assertIn("Restart=always", text)

    def test_chisel_client_retries_forever_inside_one_process(self):
        from pronet import engines
        plan = {"profile": "chisel", "role": "foreign", "iran_ip": "192.0.2.1", "bind_ip": "198.51.100.1",
                "control_port": 4000, "health_port": 1, "bridge_health_port": 2, "data_port": 3, "bridge_data_port": 4,
                "token": "t" * 32, "server_fingerprint": "A" * 43 + "=", "pair_id": "a" * 24}
        with tempfile.TemporaryDirectory() as temporary, mock.patch.object(engines, "validate_profile"), \
                mock.patch.object(engines, "tunnel_ips", return_value=("10.0.0.1", "10.0.0.2")):
            recipe = engines.render(plan, temporary, {"chisel": "/bin/chisel"})
        self.assertNotIn("--max-retry-count", recipe["command"])
        self.assertIn("--max-retry-interval", recipe["command"])


class ActiveStatesTests(unittest.TestCase):
    def test_one_systemctl_call_for_every_unit(self):
        from pronet import runtime
        import subprocess
        calls = []
        def fake(args, **_):
            calls.append(args)
            return subprocess.CompletedProcess(args, 3, "active\ninactive\nactive\n", "")
        with mock.patch.object(runtime, "command", side_effect=fake):
            states = runtime.active_states(["a.service", "b.service", "c.service"])
        self.assertEqual(states, {"a.service": True, "b.service": False, "c.service": True})
        self.assertEqual(len(calls), 1)


class LongOutageWatchdogTests(Base):
    def test_three_hours_with_the_other_server_off(self):
        self.cycles(lambda name, c: True, 180)            # 3 hours, every path down
        events = self.events()
        self.assertEqual(events.count("ALL_PATHS_DOWN"), 1)
        self.assertNotIn("FAILOVER", events)
        self.assertLess(len(events), 8, events)
        self.assertEqual(self.selection()["active"], "frp-tls")
        self.cycles(lambda name, c: False, 3)             # the server is back
        self.assertEqual(self.events().count("PATH_RESTORED"), 1)
        self.assertIsNone(self.selection().get("all_down_since"))
        self.assertLessEqual(len(json.dumps(self.selection())), 40000, "local state stays small")


class ReconnectGraceTests(unittest.TestCase):
    def test_no_retest_right_after_a_server_returns_from_a_long_outage(self):
        now = 1000000
        store = mock.Mock()
        store.pair.return_value = {"result": {"results": [], "maintenance": {}}}
        c = Controller(store)
        runtime = {"all_down_since": now - 3 * 3600}
        self.assertIsNone(c.maintenance_task({"id": "p"}, runtime, now, reporting_since=now - 30))
        self.assertEqual(c.maintenance_task({"id": "p"}, runtime, now + RETEST_AFTER, reporting_since=now - 30), "retest")

    def test_reporting_since_resets_while_a_server_is_silent(self):
        c = Controller(mock.Mock())
        pair = {"id": "p", "iran": "i", "foreign": "f"}
        self.assertEqual(c.reporting_since(pair, {"i", "f"}, 100), 100)
        self.assertEqual(c.reporting_since(pair, {"i", "f"}, 200), 100)
        self.assertIsNone(c.reporting_since(pair, {"i"}, 300))
        self.assertEqual(c.reporting_since(pair, {"i", "f"}, 400), 400)

    def test_silent_server_is_reported_after_two_minutes_and_its_return(self):
        store = mock.Mock()
        c = Controller(store)
        overview = {"pairs": [{"id": "p", "iran": "i", "foreign": "f", "state": "ACTIVE"}]}
        c.track_nodes(overview, {"i", "f"}, 0)
        c.track_nodes(overview, {"i"}, 10)
        c.track_nodes(overview, {"i"}, 60)
        store.notice.assert_not_called()
        c.track_nodes(overview, {"i"}, 140)
        store.notice.assert_called_once_with("p", "NODE_STALE", "foreign")
        c.track_nodes(overview, {"i", "f"}, 10 + 3600)
        self.assertEqual(store.notice.call_args.args, ("p", "NODE_BACK", "foreign:60"))
        store.notice.reset_mock()
        c.track_nodes(overview, {"i"}, 4000)
        c.track_nodes(overview, {"i", "f"}, 4030)     # a 30 s blip says nothing
        store.notice.assert_not_called()


class HubWaitTests(unittest.TestCase):
    def test_held_poll_does_not_query_the_database_in_a_loop(self):
        from pronet.hub import Client, HubServer
        from pronet.store import Store
        with tempfile.TemporaryDirectory() as temporary:
            enroll, admin = secret(), secret()
            store = Store(pathlib.Path(temporary) / "h.db", enroll, admin)
            server = HubServer(("127.0.0.1", 0), store)
            threading.Thread(target=server.serve_forever, daemon=True).start()
            try:
                cred = store.enroll(enroll, {"role": "iran", "name": "i", "public_ip": "192.0.2.1", "bind_ip": "192.0.2.1"})
                client = Client("http://127.0.0.1:%d" % server.server_port, cred["node_id"] + ":" + cred["node_secret"], test_http=True)
                claims = []
                original = store.claim
                store.claim = lambda *a, **k: claims.append(1) or original(*a, **k)
                started = time.monotonic()
                self.assertIsNone(client.call("/v1/jobs?wait=5&lane=main", timeout=20)["job"])
                self.assertGreater(time.monotonic() - started, 4.5)
                self.assertLessEqual(len(claims), 4, "a held poll re-checks every 2 s, not 4 times a second")
            finally:
                server.shutdown(); server.server_close()


class NoticeStoreTests(unittest.TestCase):
    def setUp(self):
        from pronet.store import Store
        self.tmp = tempfile.TemporaryDirectory()
        enroll, admin = secret(), secret()
        self.store = Store(pathlib.Path(self.tmp.name) / "h.db", enroll, admin)
        nodes = {}
        for number, role in ((1, "iran"), (2, "foreign")):
            cred = self.store.enroll(enroll, {"role": role, "name": role, "public_ip": "192.0.2.%d" % number,
                                              "bind_ip": "192.0.2.%d" % number})
            nodes[role] = self.store.authenticate(cred["node_id"] + ":" + cred["node_secret"])
        self.iran, self.foreign = nodes["iran"], nodes["foreign"]
        pair = self.store.create_pair(self.iran, {"name": "office", "public_ip": "192.0.2.1", "inbound_port": 2053})
        self.store.join_pair(self.foreign, pair["code"])
        self.pair_id = pair["pair_id"]

    def tearDown(self):
        self.tmp.cleanup()

    def beat_iran(self, events):
        self.store.heartbeat(self.iran, {"resources": {}, "pairs": [{"id": self.pair_id, "events": events}]})

    def test_new_events_reach_the_foreign_server_once(self):
        old = {"utc": "2026-10-27T07:00:00Z", "event": "FAILOVER", "detail": "a -> b (primary down)"}
        self.beat_iran([old])                                     # history: not re-sent
        self.assertNotIn("notices", self.store.heartbeat(self.foreign, {"resources": {}, "notify": False}))
        self.assertEqual(self.store.heartbeat(self.foreign, {"resources": {}, "notify": True})["notices"], [])
        down = {"utc": "2026-10-27T08:00:00Z", "event": "ALL_PATHS_DOWN", "detail": "no committed carrier answers"}
        noise = {"utc": "2026-10-27T08:00:01Z", "event": "STANDBY_UNCONFIRMED", "detail": "x"}
        self.beat_iran([old, down, noise])
        self.beat_iran([old, down, noise])                        # same events again
        notices = self.store.heartbeat(self.foreign, {"resources": {}, "notify": True})["notices"]
        self.assertEqual([(n["kind"], n["pair"]) for n in notices], [("ALL_PATHS_DOWN", "office")])
        reply = self.store.heartbeat(self.foreign, {"resources": {}, "notify": True, "notices_ack": [notices[0]["id"]]})
        self.assertEqual(reply["notices"], [])
        self.store.add_event(self.pair_id, "RETEST_STARTED", "every committed path down for 5+ minutes")
        self.assertEqual(self.store.heartbeat(self.foreign, {"resources": {}, "notify": True})["notices"][0]["kind"],
                         "RETEST_STARTED")

    def test_iran_never_receives_notices(self):
        self.store.notice(self.pair_id, "NODE_STALE", "foreign")
        self.assertNotIn("notices", self.store.heartbeat(self.iran, {"resources": {}, "notify": True}))


class NotifierTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = pathlib.Path(self.tmp.name) / "notify.json"
        notify.save_config("123456:ABC-def_ghi", "-100123", "fa", path=self.path)
        self.sent, self.fail = [], [False]
        self.clock = Clock(5000)
        def sender(config, text):
            if self.fail[0]:
                raise PronetError("Telegram request failed")
            self.sent.append(text)
        self.notifier = notify.Notifier(self.path, sender, self.clock)

    def tearDown(self):
        self.tmp.cleanup()

    def test_batches_and_retries_with_backoff(self):
        self.notifier.start = lambda: None
        self.notifier.add([{"id": i, "kind": "FAILOVER", "pair": "office", "detail": "a -> b"} for i in range(12)])
        self.fail[0] = True
        self.assertEqual(self.notifier.flush(), 30)
        self.assertEqual(self.notifier.flush(), 30, "nothing is retried before the backoff")
        self.clock.now += 31
        self.assertEqual(self.notifier.flush(), 60)
        self.fail[0] = False
        self.clock.now += 61
        self.assertEqual(self.notifier.flush(), 1.0)
        self.assertIsNone(self.notifier.flush())
        self.assertEqual(len(self.sent), 2)
        self.assertIn("حامل عوض شد", self.sent[0])
        self.assertEqual(sorted(self.notifier.take_acks()), list(range(12)))
        self.notifier.add([{"id": 3, "kind": "FAILOVER"}])
        self.assertIsNone(self.notifier.flush(), "a notice is sent once")

    def test_iran_unreachable_alert_after_five_minutes_and_back(self):
        self.notifier.start = lambda: None
        self.notifier.hub_state(120)
        self.assertIsNone(self.notifier.flush())
        self.notifier.hub_state(301)
        self.notifier.hub_state(400)
        self.notifier.flush()
        self.clock.now += 3600
        self.notifier.hub_state(0)
        self.clock.now += 2
        self.notifier.flush()
        self.assertEqual(len(self.sent), 2)
        self.assertIn("سرور ایران", self.sent[0])
        self.assertIn("دوباره در دسترس", self.sent[1])
        self.assertEqual(self.notifier.take_acks(), [], "local alerts need no acknowledgement")

    def test_disabled_alerts_are_dropped_and_token_never_leaks(self):
        self.notifier.start = lambda: None
        data = json.loads(self.path.read_text()); data["enabled"] = False
        self.path.write_text(json.dumps(data))
        self.notifier.add([{"id": 1, "kind": "ALL_PATHS_DOWN", "pair": "x"}])
        self.assertIsNone(self.notifier.flush())
        self.assertEqual(self.sent, [])
        config = notify.load_config(self.path)
        def opener(request, timeout):
            raise OSError("cannot reach " + request.full_url)
        with self.assertRaises(PronetError) as raised:
            notify.send_telegram(config, "hi", opener=opener)
        self.assertNotIn(config["token"], str(raised.exception))
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_bad_token_is_refused(self):
        with self.assertRaises(PronetError):
            notify.save_config("not a token", "123", path=self.path)

    def test_messages_render_in_both_languages(self):
        notice = {"kind": "NODE_BACK", "pair": "office", "detail": "foreign:12", "utc": "2026-10-27T08:00:00Z"}
        self.assertIn("Foreign server reporting again after 12 min", notify.render(notice, "en"))
        self.assertIn("سرور خارج", notify.render(notice, "fa"))
        self.assertIn("08:00:00 UTC", notify.render(notice, "en"))
        for kind in notify.NOTIFY_KINDS | {"HUB_DOWN", "HUB_BACK", "TEST"}:
            for lang in ("en", "fa"):
                self.assertTrue(notify.render({"kind": kind, "detail": "x"}, lang))


if __name__ == "__main__":
    unittest.main()
