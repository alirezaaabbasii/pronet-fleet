"""Coordinates two outbound agents; never shells into servers or runs engines."""
from __future__ import annotations

import concurrent.futures
import ipaddress
import secrets
import threading
import time

from .common import PronetError, clean, secret
from .model import PROFILES, ranking


SCREEN_BATCH = 6
REACH_SECONDS = 20


class Controller:
    def __init__(self, store, stop_event=None):
        self.store = store
        self.stop = stop_event or threading.Event()
        self.running = set()
        self.busy_nodes = set()
        self.mutex = threading.Lock()

    def rpc(self, pair, node, op, payload, step, timeout=125):
        if self.store.pair(pair["id"]).get("desired", "run") == "stop" and op != "cleanup":
            raise PronetError("Operator requested a stop; further setup operations were canceled")
        job = self.store.enqueue(pair["id"], node, op, payload, step)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and not self.stop.is_set():
            result = self.store.job_result(job)
            if result is not None:
                if not result["ok"]:
                    raise PronetError(result.get("error", "Node operation failed"))
                return result.get("data", {})
            self.stop.wait(.2)
        raise PronetError("Node did not complete " + op + " within the bounded timeout")

    def both(self, pair, op, payloads, step, timeout=125):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = {role: pool.submit(self.rpc, pair, pair["iran" if role == "iran" else "foreign_node"],
                                        op, payloads[role], step + ":" + role, timeout)
                       for role in ("iran", "foreign")}
            results, errors = {}, []
            for role, future in futures.items():
                try:
                    results[role] = future.result()
                except Exception as error:
                    errors.append(role + ": " + clean(error))
            if errors:
                raise PronetError("; ".join(errors))
            return results

    def allocate(self, pair, inventories):
        request = pair["request"]
        used_ports = set(inventories["iran"]["ports"]) | set(inventories["foreign"]["ports"])
        used_ports.update(inventories["iran"]["ssh_ports"])
        used_ports.update(inventories["foreign"]["ssh_ports"])
        used_ports.add(request["inbound_port"])
        networks = []
        for info in inventories.values():
            for text in info["routes"] + info["reserved_subnets"]:
                try:
                    network = ipaddress.ip_network(text)
                    if network.prefixlen:
                        networks.append(network)
                except ValueError:
                    pass
        # Never allocate a fixed service port inside a node's ephemeral range:
        # outgoing connections (thousands of user sessions through the
        # gateway/bridge) borrow those ports, and a carrier or helper that
        # restarts later fails with EADDRINUSE on exactly the busiest servers.
        ephemeral = []
        for info in inventories.values():
            try:
                low, high = (int(x) for x in info.get("ephemeral_range", (32768, 60999)))
                if 1 <= low <= high <= 65535:
                    ephemeral.append((low, high))
            except (TypeError, ValueError):
                ephemeral.append((32768, 60999))
        def outside_ephemeral(value):
            return not any(low <= value <= high for low, high in ephemeral)
        def choose_port(control=False):
            common = [443, 8443, 9443, 22443] if control else []
            for value in common:
                if value not in used_ports:
                    used_ports.add(value)
                    return value
            for strict in (True, False):
                for _ in range(400):
                    value = 20000 + secrets.randbelow(45000)
                    if value not in used_ports and (not strict or outside_ephemeral(value)):
                        used_ports.add(value)
                        return value
            raise PronetError("Could not reserve a free port")
        def choose_subnet():
            for pool in ("10.244.0.0/16", "172.29.0.0/16", "192.168.240.0/20"):
                pool = ipaddress.ip_network(pool)
                for _ in range(128):
                    offset = secrets.randbelow(pool.num_addresses // 4) * 4
                    candidate = ipaddress.ip_network((int(pool.network_address) + offset, 30))
                    if not any(candidate.overlaps(existing) for existing in networks):
                        networks.append(candidate)
                        return str(candidate)
            raise PronetError("No collision-free tunnel subnet was found")
        plans = []
        for profile in request["profiles"]:
            if PROFILES[profile]["kind"] == "l3" and not all(info["tun"] for info in inventories.values()):
                continue
            token, subnet = secret(), choose_subnet()
            plan = {"pair_id": pair["id"], "profile": profile, "token": token, "subnet": subnet,
                    "iran_ip": pair["iran_info"]["public_ip"], "foreign_ip": pair["foreign_info"]["public_ip"],
                    "control_port": choose_port(True), "echo_port": choose_port(), "health_port": choose_port(),
                    "data_port": choose_port(), "inbound_port": request["inbound_port"],
                    "gateway_bind_ip": request["bind_ip"], "gateway_public_ip": request["public_ip"],
                    "bridge_data_port": choose_port(), "bridge_health_port": choose_port(), "probe_front_port": choose_port(),
                    "direction": PROFILES[profile].get("direction", request["direction"]), "sni": request.get("sni", ""),
                    "test_quality": request.get("quality", "balanced")}
            plans.append(plan)
        if not plans:
            raise PronetError("No selected profile can run with these capabilities")
        return plans

    def payloads(self, pair, plan):
        return {role: dict(plan, role=role, bind_ip=pair[role + "_info"]["bind_ip"]) for role in ("iran", "foreign")}

    def process(self, pair_id):
        pair = self.store.pair(pair_id)
        result = {"phase": "preflight", "results": [], "warnings": [], "timing": {"started": time.time()}}
        try:
            if pair["state"] != "PAIRED":
                raise PronetError("Hub restarted during setup; safely retire the interrupted setup and create a fresh pairing")
            self.store.update_pair(pair_id, "PREFLIGHT", result)
            info = self.both(pair, "inventory", {"iran": {}, "foreign": {}}, "inventory")
            from . import __version__
            versions = {role: inventory.get("version", "older than 0.2.5") for role, inventory in info.items()}
            if any(version != __version__ for version in versions.values()):
                raise PronetError("Version mismatch (coordinator %s, iran %s, foreign %s). Run the installer on both servers, then create a new pairing."
                                  % (__version__, versions["iran"], versions["foreign"]))
            for role, inventory in info.items():
                if not inventory["systemd"] or not inventory["iptables"] or inventory["arch"] not in ("amd64", "arm64"):
                    raise PronetError(role + ": requires Linux amd64/arm64, systemd, and iptables tools")
                if inventory.get("unresolved_raw_engines"):
                    raise PronetError(role + ": an unmanaged raw tunnel has unknown ports; import or inspect it before installing new carriers")
                if inventory.get("firewall_readable") is False:
                    raise PronetError(role + ": firewall could not be inspected; setup stopped before changes")
            from .runtime import endpoint_occupied, endpoint_has_nat
            if endpoint_occupied(info["iran"], pair["request"]["bind_ip"], pair["request"]["inbound_port"]):
                raise PronetError("Iran public port is already occupied; no existing listener was stopped")
            if pair["request"]["bind_ip"] not in info["iran"]["ips"]:
                raise PronetError("Iran gateway IP is not assigned to the host")
            if endpoint_has_nat(info["iran"], pair["request"]["bind_ip"], pair["request"]["inbound_port"]):
                raise PronetError("An existing DNAT/REDIRECT rule already owns this public endpoint; it was left unchanged")
            if pair["request"]["inbound_port"] in info["iran"]["ssh_ports"] + info["foreign"]["ssh_ports"]:
                raise PronetError("The requested inbound port is used for SSH")
            plans = self.allocate(pair, info)
            running = set()
            total = len(plans)
            result["progress"] = {"tested": 0, "total": total, "passed": 0}
            self.store.update_pair(pair_id, "TRIAL", dict(result, phase="measuring"))
            for batch_index in range(0, total, SCREEN_BATCH):
                if self.stop.is_set():
                    return
                self.screen_batch(pair, plans[batch_index:batch_index + SCREEN_BATCH], batch_index // SCREEN_BATCH,
                                  result, running)
                keep = {row["profile"] for row in ranking(result["results"], 1)}
                retire = sorted(running - keep)
                if retire:
                    self.both(pair, "retire_batch", {"iran": {"profiles": retire}, "foreign": {"profiles": retire}},
                              "retire-screen:" + str(batch_index))
                    running.difference_update(retire)
                result["progress"] = {"tested": len(result["results"]), "total": total,
                                      "passed": sum(1 for row in result["results"] if row.get("passed"))}
                self.store.update_pair(pair_id, "TRIAL", dict(result, phase="measuring"))
            screened = ranking(result["results"], all_results=True)
            # Qualify a sufficiently good different carrier family before a
            # second near-identical path; otherwise stopping after two passes
            # silently defeats ranking()'s standby diversity policy.
            preferred = ranking(result["results"], pair["request"]["standby"])
            preferred_names = {row["profile"] for row in preferred}
            screened = preferred + [row for row in screened if row["profile"] not in preferred_names]
            qualified = []
            for index, candidate in enumerate(screened[:5]):
                profile = candidate["profile"]
                plan = next(plan for plan in plans if plan["profile"] == profile)
                self.both(pair, "start", self.payloads(pair, plan), "start-soak:" + profile)
                running.add(profile)
                observations = []
                repetitions = 3 if pair["request"].get("quality") == "thorough" else 1
                for repetition in range(repetitions):
                    measured = self.rpc(pair, pair["iran"], "benchmark", self.payloads(pair, dict(plan, long_test=True))["iran"], "soak:" + profile + ":" + str(repetition))
                    observations.append(measured)
                    if not measured.get("passed"): break
                soaked = dict(observations[-1])
                soaked["passed"] = len(observations) == repetitions and all(row.get("passed") for row in observations)
                soaked["qualification_runs"] = len(observations)
                if soaked["passed"]:
                    soaked["echo_ms"] = [sample for row in observations for sample in row["echo_ms"]]
                    soaked["upload_mbps"] = min(row["upload_mbps"] for row in observations)
                    soaked["download_mbps"] = min(row["download_mbps"] for row in observations)
                soaked["observations"] = observations
                candidate["soak"] = soaked
                for row in result["results"]:
                    if row["profile"] == profile: row["soak"] = soaked
                if soaked.get("passed"):
                    qualified.append(soaked)
                keep = {row["profile"] for row in ranking(qualified, 1)}
                for retired in list(running - keep):
                    self.both(pair, "retire", {"iran": {"profile": retired}, "foreign": {"profile": retired}}, "retire-soak:" + str(index) + ":" + retired)
                    running.remove(retired)
                self.store.update_pair(pair_id, "TRIAL", dict(result, phase="longer-test"))
                if len(qualified) >= 1 + pair["request"]["standby"]:
                    break
            winners = ranking(qualified, pair["request"]["standby"])
            if not winners:
                raise PronetError("No profile passed all integrity, idle, half-close and reachability tests. This is not proof that every possible network path is blocked.")
            selected = [row["profile"] for row in winners]
            result.update(phase="committing", selected=selected, active=selected[0])
            self.store.update_pair(pair_id, "STAGED", result)
            self.both(pair, "commit", {"iran": {"profiles": selected}, "foreign": {"profiles": selected}}, "commit")
            self.store.update_pair(pair_id, "VERIFYING", dict(result, phase="verifying"))
            winner = next(plan for plan in plans if plan["profile"] == selected[0])
            proof = self.rpc(pair, pair["iran"], "benchmark", self.payloads(pair, winner)["iran"], "post-commit")
            if not proof.get("passed"):
                raise PronetError("Winner did not pass after permanent service activation")
            active = self.both(pair, "activate", {"iran": {}, "foreign": {}}, "activate")
            if active["foreign"].get("inbound") != "open":
                result["warnings"].append("Tunnel is active, but the foreign inbound port is not open. Install/configure the node before client use.")
            if active["iran"].get("tls") not in ("verified", "not-configured"):
                result["warnings"].append("TLS could not be verified with the configured SNI; inspect the foreign inbound and certificate.")
            result["warnings"].append("An authenticated WS/XHTTP client session through the public Iran address has not been tested automatically.")
            result["timing"]["finished"] = time.time()
            result["inbound"] = active["foreign"].get("inbound", "unknown")
            result.update(phase="complete", endpoint=f"{pair['request']['public_ip']}:{pair['request']['inbound_port']}")
            self.store.update_pair(pair_id, "ACTIVE", result)
        except Exception as error:
            result["timing"]["finished"] = time.time()
            result.update(phase="rollback", error=clean(error))
            self.store.update_pair(pair_id, "ROLLING_BACK", result)
            self.store.cancel_pending(pair_id)
            try:
                self.both(pair, "cleanup", {"iran": {}, "foreign": {}}, "rollback", timeout=70)
            except Exception as cleanup_error:
                result["warnings"].append("Cleanup unconfirmed: " + clean(cleanup_error) + ". Temporary services expire; inspect committed services locally.")
            result["phase"] = "failed"
            self.store.update_pair(pair_id, "FAILED", result)

    def screen_batch(self, pair, batch, number, result, running):
        """Screen several carriers together.

        Preparing and starting a batch costs two round trips instead of two per
        carrier, and reachability is awaited IN PARALLEL on the Iran agent, so
        filtered carriers (often most of them) fail together within one short
        window instead of one after another. Throughput is still measured one
        carrier at a time so the numbers are not shared between carriers.
        """
        label = "batch-" + str(number)
        names = [plan["profile"] for plan in batch]
        def failed(profile, reason, stage):
            result["results"].append({"profile": profile, "passed": False, "error": clean(reason), "stage": stage})
        try:
            prepared = self.both(pair, "prepare_batch", {role: {"plans": [self.payloads(pair, plan)[role] for plan in batch]}
                                                         for role in ("iran", "foreign")}, label + ":prepare")
        except Exception as error:
            for name in names:
                failed(name, error, "prepare")
            running.update(names)
            return
        startable = []
        for plan in batch:
            replies = [prepared[role].get("profiles", {}).get(plan["profile"], {}) for role in ("iran", "foreign")]
            errors = [r.get("error") for r in replies if not isinstance(r, dict) or r.get("error") or not r.get("prepared")]
            if errors:
                failed(plan["profile"], errors[0] or "prepare failed", "prepare")
                running.add(plan["profile"])
                continue
            for field in ("server_cert", "server_fingerprint", "server_noise_public_key"):
                if field in replies[0]:
                    plan[field] = replies[0][field]
            startable.append(plan)
        if not startable:
            return
        try:
            started = self.both(pair, "start_batch", {role: {"plans": [self.payloads(pair, plan)[role] for plan in startable]}
                                                      for role in ("iran", "foreign")}, label + ":start")
        except Exception as error:
            for plan in startable:
                failed(plan["profile"], error, "start")
            running.update(plan["profile"] for plan in startable)
            return
        live = []
        for plan in startable:
            running.add(plan["profile"])
            replies = [started[role].get("profiles", {}).get(plan["profile"], {}) for role in ("iran", "foreign")]
            errors = [r.get("error") for r in replies if not isinstance(r, dict) or r.get("error") or not r.get("started")]
            if errors:
                failed(plan["profile"], errors[0] or "start failed", "start")
            else:
                live.append(plan)
        if not live:
            return
        try:
            probe = self.rpc(pair, pair["iran"], "probe_batch", {"profiles": [plan["profile"] for plan in live],
                                                                  "seconds": REACH_SECONDS}, label + ":reach",
                             timeout=REACH_SECONDS + 60)
        except Exception as error:
            for plan in live:
                failed(plan["profile"], error, "reach")
            return
        for plan in live:
            reach = probe.get("profiles", {}).get(plan["profile"], {})
            if not reach.get("reachable"):
                failed(plan["profile"], reach.get("reason", "unreachable"), "reach")
                continue
            step = label + ":" + plan["profile"]
            try:
                measured = self.rpc(pair, pair["iran"], "benchmark", self.payloads(pair, plan)["iran"], step + ":measure")
                if PROFILES[plan["profile"]]["kind"] == "l3" and measured.get("passed"):
                    reverse = self.rpc(pair, pair["foreign_node"], "benchmark", self.payloads(pair, plan)["foreign"], step + ":reverse")
                    measured["reverse_passed"] = reverse.get("passed", False)
                    measured["passed"] = measured["passed"] and measured["reverse_passed"]
                    if not measured["passed"]:
                        measured["reason"] = "reverse direction (foreign to Iran) failed"
                measured["reach_ms"] = reach.get("rtt_ms")
                result["results"].append(measured)
            except Exception as error:
                failed(plan["profile"], error, "benchmark")

    def recover(self, pair_id, pause_id):
        pair = self.store.pair(pair_id)
        result = pair["result"]
        old = result.get("selected", [])
        recovery = {"handled_pause_id": pause_id, "state": "trying", "attempted": []}
        result["recovery"] = recovery
        # Persist the episode before starting anything. A hub restart does not
        # turn one bounded recovery budget into an unlimited retry loop.
        self.store.update_pair(pair_id, "ACTIVE", result)

        prefix = "recovery:" + pause_id + ":"
        passed = ranking(result.get("results", []), all_results=True)
        profiles = [row["profile"] for row in passed if row["profile"] not in old]
        profiles += [profile for profile in old if profile not in profiles]
        for index, profile in enumerate(profiles[:3]):
            if self.stop.is_set(): return
            recovery["attempted"].append(profile)
            commit_attempted = False
            try:
                self.both(pair, "resume", {"iran": {"profile": profile}, "foreign": {"profile": profile}}, prefix + profile + ":resume")
                proof = self.rpc(pair, pair["iran"], "remeasure", {"profile": profile}, prefix + profile + ":measure")
                if not proof.get("passed"): raise PronetError("Recovery candidate did not pass a real transfer")
                selection = [profile] + [item for item in old if item != profile][:1]
                commit_attempted = True
                self.both(pair, "commit", {"iran": {"profiles": selection}, "foreign": {"profiles": selection}}, prefix + profile + ":commit")
                self.both(pair, "activate", {"iran": {}, "foreign": {}}, prefix + profile + ":activate")
                recovery.update(state="recovered", active=profile)
                result.update(selected=selection, active=profile)
                self.store.update_pair(pair_id, "ACTIVE", result)
                return
            except Exception as error:
                recovery.setdefault("errors", []).append(profile + ": " + clean(error))
                if commit_attempted and old:
                    try:
                        for restore in old:
                            self.both(pair, "resume", {"iran": {"profile": restore}, "foreign": {"profile": restore}}, prefix + profile + ":restore:" + restore)
                        self.both(pair, "commit", {"iran": {"profiles": old}, "foreign": {"profiles": old}}, prefix + profile + ":restore-commit")
                        self.both(pair, "activate", {"iran": {}, "foreign": {}}, prefix + profile + ":restore-activate")
                    except Exception as restore_error:
                        recovery.setdefault("errors", []).append("Restore unconfirmed: " + clean(restore_error))
                        recovery["state"] = "restore-unconfirmed"
                        self.store.update_pair(pair_id, "ACTIVE", result)
                        return
                if profile not in old:
                    try:
                        self.both(pair, "retire", {"iran": {"profile": profile}, "foreign": {"profile": profile}}, prefix + profile + ":retire", timeout=70)
                    except Exception as retire_error:
                        recovery.setdefault("errors", []).append(clean(retire_error))
            self.store.update_pair(pair_id, "ACTIVE", result)
        recovery["state"] = "exhausted"
        self.store.update_pair(pair_id, "ACTIVE", result)

    def stop_pair(self, pair_id):
        pair = self.store.pair(pair_id)
        result = pair["result"]
        request_id = result.get("stop_request", "initial")
        try:
            if pair["foreign_node"] is None:
                result["phase"] = "stopped-before-pairing"
            else:
                self.both(pair, "cleanup", {"iran": {}, "foreign": {}}, "operator-stop:" + request_id, timeout=125)
                result["phase"] = "stopped-both-ends"
            self.store.update_pair(pair_id, "STOPPED", result)
        except Exception as error:
            result.update(phase="stop-unconfirmed", error=clean(error))
            self.store.update_pair(pair_id, "STOP_UNCONFIRMED", result)

    def launch(self, pair_id, recovery_pause=None):
        pair = self.store.pair(pair_id)
        members = {pair["iran"], pair["foreign_node"]}
        with self.mutex:
            if pair_id in self.running or len(self.running) >= 4 or self.busy_nodes & members:
                return
            self.running.add(pair_id)
            self.busy_nodes.update(members)
        def work():
            try:
                if self.store.pair(pair_id).get("desired") == "stop":
                    self.stop_pair(pair_id)
                elif recovery_pause:
                    self.recover(pair_id, recovery_pause)
                else:
                    self.process(pair_id)
            finally:
                with self.mutex:
                    self.running.discard(pair_id)
                    self.busy_nodes.difference_update(members)
        threading.Thread(target=work, daemon=True, name="pair-" + pair_id[:8]).start()

    def run(self):
        # One unexpected error (a locked database, a malformed row) used to end
        # this thread silently: the HTTPS hub kept answering while no setup,
        # stop or recovery was ever processed again until a manual restart.
        while not self.stop.is_set():
            try:
                self.cycle()
            except Exception as error:
                import sys
                print("Pronet controller: cycle failed: " + clean(error), file=sys.stderr, flush=True)
                self.stop.wait(5)
                continue
            self.stop.wait(2)

    def cycle(self):
        for pair_id in self.store.stopping():
            self.launch(pair_id)
        for pair_id in self.store.pending():
            self.launch(pair_id)
        overview = self.store.overview()
        current = {node["id"] for node in overview["nodes"] if node["telemetry"] == "CURRENT"}
        for pair in overview["pairs"]:
            runtime = pair.get("runtime", {})
            pause = runtime.get("pause_id")
            handled = pair["result"].get("recovery", {}).get("handled_pause_id")
            if (pair["state"] == "ACTIVE" and pair["iran"] in current and pair["foreign"] in current
                    and runtime.get("recovery_paused") and runtime.get("link") == "UNCONFIRMED"
                    and not runtime.get("remote_stopped") and pause and pause != handled):
                self.launch(pair["id"], pause)
