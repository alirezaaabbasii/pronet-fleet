from __future__ import annotations

import argparse
import asyncio
import contextlib
import getpass
import json
import os
import pathlib
import platform
import signal
import socket
import ssl
import sys
import threading
import time
import urllib.parse

from . import __version__, engines
from .common import (APP, CONFIG, ROOT, PronetError, atomic_write, clean, command,
                     identifier, ipv4, lock, port, read_json, secret, write_json)
from .model import DEFAULT_PROFILES, PROFILES, tunnel_ips


def root_linux():
    if platform.system() != "Linux" or os.geteuid() != 0:
        raise PronetError("این عملیات به Linux و دسترسی root نیاز دارد؛ با sudo اجرا کن.")


def node_config():
    return read_json(CONFIG / "node.json")


def node_client():
    from .hub import Client
    config = node_config()
    return Client(config["hub_url"], config["node_id"] + ":" + config["node_secret"], config.get("ca_file"))


def start_service(name, owner, args, directory):
    from .runtime import write_unit, service
    write_unit(name, owner, args, directory, temporary=False)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "start")


def init_hub(args):
    root_linux()
    from .hub import Client
    Client(args.url, "validation-only")  # Validate URL before creating anything.
    parsed = urllib.parse.urlsplit(args.url)
    try:
        address = socket.gethostbyname(parsed.hostname)
    except OSError:
        raise PronetError("نام مرکز فعلاً resolve نمی‌شود؛ IP یا DNS آن را بررسی کن.")
    listen_port = parsed.port or 443
    directory = CONFIG / "hub"
    path = directory / "hub.json"
    if path.exists():
        raise PronetError("مرکز قبلاً تنظیم شده؛ فایل موجود بازنویسی نشد.")
    with socket.socket() as sock:
        sock.bind((args.bind, listen_port))
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    (ROOT / "hub").mkdir(parents=True, exist_ok=True, mode=0o700)
    if bool(args.cert) != bool(args.key):
        raise PronetError("گواهی و کلید باید با هم مشخص شوند.")
    if args.cert:
        cert = pathlib.Path(args.cert).read_text()
        key = pathlib.Path(args.key).read_text()
        atomic_write(directory / "server.crt", cert)
        atomic_write(directory / "server.key", key)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(directory / "server.crt"), str(directory / "server.key"))
        ca_pem = pathlib.Path(args.ca).read_text() if args.ca else ""
    else:
        cert = engines.certificate(directory, parsed.hostname, address)
        ca_pem = cert
    config = {"url": args.url.rstrip("/"), "bind": args.bind, "port": listen_port,
              "enrollment_key": secret(), "admin_key": secret(), "certificate": str(directory / "server.crt"),
              "private_key": str(directory / "server.key"), "database": str(ROOT / "hub" / "hub.sqlite3")}
    write_json(path, config)
    bootstrap = {"schema": 1, "hub_url": config["url"], "enrollment_key": config["enrollment_key"], "ca_pem": ca_pem}
    write_json(CONFIG / "pronet-bootstrap.json", bootstrap)
    atomic_write(CONFIG / "hub-admin-password", config["admin_key"] + "\n")
    # The hub has no need for root or access to node configuration/engines.
    import pwd
    try:
        account = pwd.getpwnam("pronet-fleet-hub")
    except KeyError:
        command(["useradd", "--system", "--home-dir", str(ROOT / "hub"), "--shell", "/usr/sbin/nologin", "pronet-fleet-hub"])
        account = pwd.getpwnam("pronet-fleet-hub")
    CONFIG.chmod(0o711)
    ROOT.chmod(0o711)
    for base in (directory, ROOT / "hub"):
        os.chown(base, account.pw_uid, account.pw_gid)
        for child in base.iterdir():
            os.chown(child, account.pw_uid, account.pw_gid)
    from .runtime import write_unit, unit_path, service
    name = "pronetf-hub.service"
    write_unit(name, "hub", ["/usr/bin/python3", str(APP / "main.py"), "hub-run"], ROOT / "hub", temporary=False)
    content = unit_path(name).read_text().replace("Type=simple\n", "Type=simple\nUser=pronet-fleet-hub\nGroup=pronet-fleet-hub\nNoNewPrivileges=true\nPrivateTmp=true\nProtectHome=true\nProtectSystem=strict\nReadWritePaths=" + str(ROOT / "hub") + "\n")
    if listen_port < 1024:
        content = content.replace("NoNewPrivileges=true\n", "NoNewPrivileges=true\nAmbientCapabilities=CAP_NET_BIND_SERVICE\nCapabilityBoundingSet=CAP_NET_BIND_SERVICE\n")
    atomic_write(unit_path(name), content, 0o644)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "start")
    print("مرکز ساخته شد:", config["url"])
    print("فایل ثبت اولیهٔ سرورها:", CONFIG / "pronet-bootstrap.json")
    print("رمز داشبورد (نام کاربری admin):", CONFIG / "hub-admin-password")
    print("فایل bootstrap محرمانه است؛ با SFTP/SSH روی سرورهای خودت کپی کن. رمز آن را در لینک عمومی قرار نده.")
    print("پورت مرکز باید در فایروال سیستم و دیتاسنتر قابل دسترسی باشد؛ ابزار فایروال موجود را بازنویسی نکرده است.")


def run_hub():
    from .controller import Controller
    from .hub import HubServer
    from .store import Store
    config = read_json(CONFIG / "hub" / "hub.json")
    store = Store(config["database"], config["enrollment_key"], config["admin_key"])
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(config["certificate"], config["private_key"])
    stop = threading.Event()
    server = HubServer((config["bind"], config["port"]), store, tls=context, public_url=config["url"])
    controller = Controller(store, stop)
    threading.Thread(target=controller.run, daemon=True, name="controller").start()
    def terminate(*_):
        stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    try:
        server.serve_forever(poll_interval=.5)
    finally:
        stop.set()
        server.server_close()


def init_node(args):
    root_linux()
    from .hub import Client
    from .runtime import inventory
    if (CONFIG / "node.json").exists():
        raise PronetError("این سرور قبلاً ثبت شده؛ هویتش بازنویسی نشد.")
    required = ("ip", "ss", "iptables", "iptables-save", "systemctl", "openssl", "ssh-keygen")
    import shutil
    missing = [name for name in required if not shutil.which(name)]
    if missing:
        raise PronetError("ابزارهای سیستم موجود نیستند: " + ", ".join(missing) + ". روی Debian/Ubuntu بسته‌های python3 iproute2 iptables openssl openssh-client لازم‌اند.")
    info = inventory()
    if not info["systemd"] or info["arch"] not in ("amd64", "arm64"):
        raise PronetError("Linux systemd روی amd64 یا arm64 لازم است.")
    if ipv4(args.bind_ip) not in info["ips"]:
        raise PronetError("IP انتخاب‌شده برای bind روی این سرور وجود ندارد.")
    public = ipv4(args.public_ip)
    allowed_port = port(args.port)
    if allowed_port in info["ssh_ports"]:
        raise PronetError("پورت انتخاب‌شده متعلق به SSH است.")
    bootstrap = read_json(args.bootstrap)
    if set(bootstrap) != {"schema", "hub_url", "enrollment_key", "ca_pem"} or bootstrap["schema"] != 1:
        raise PronetError("فایل bootstrap معتبر نیست.")
    CONFIG.mkdir(parents=True, exist_ok=True, mode=0o700)
    ca_file = None
    if bootstrap["ca_pem"]:
        atomic_write(CONFIG / "hub-ca.pem", bootstrap["ca_pem"])
        ca_file = str(CONFIG / "hub-ca.pem")
    client = Client(bootstrap["hub_url"], bootstrap["enrollment_key"], ca_file)
    identity = {"role": args.role, "public_ip": public, "bind_ip": args.bind_ip, "name": args.name}
    credentials = client.call("/v1/enroll", identity)
    identity.update(credentials, hub_url=bootstrap["hub_url"], ca_file=ca_file, allowed_inbound_ports=[allowed_port])
    write_json(CONFIG / "node.json", identity)
    start_service("pronetf-agent.service", "agent", ["/usr/bin/python3", str(APP / "main.py"), "agent"], ROOT)
    try:
        enable_traffic()
    except (OSError, PronetError) as error:
        print("پایش سیمی IP فعلاً UNKNOWN است:", clean(error), "· بعداً sudo pronet traffic-enable اجرا کن.")
    print("سرور ثبت شد:", args.role, "·", args.name)
    print("عامل فعال است. از این پس برای اتصال جدید، روی ایران pair و روی خارج join اجرا کن.")


def pair(args):
    config = node_config()
    if config["role"] != "iran":
        raise PronetError("ساخت کد از سمت ایران انجام می‌شود.")
    profiles = list(PROFILES) if args.profiles == "all" else args.profiles.split(",") if args.profiles else list(DEFAULT_PROFILES)
    request = {"name": args.name, "public_ip": getattr(args, "public_ip", None) or config["public_ip"], "bind_ip": getattr(args, "bind_ip", None) or config["bind_ip"],
               "inbound_port": args.port, "profiles": profiles, "standby": 0 if args.no_standby else 1,
               "direction": args.direction, "sni": args.sni, "quality": getattr(args, "quality", "balanced")}
    result = node_client().call("/v1/pair", request)
    print("کد جفت‌سازی:", result["code"], "· معتبر تا ۵ دقیقه")
    print("روی سرور خارج: sudo pronet join " + result["code"])
    print("شناسهٔ اتصال:", result["pair_id"])
    print("مشاهدهٔ پیشرفت: sudo pronet watch")


def join(code):
    result = node_client().call("/v1/join", {"code": code})
    print("جفت‌سازی انجام شد. سنجش و راه‌اندازی از طریق مرکز شروع می‌شود.")
    print("شناسهٔ اتصال:", result["pair_id"])


def display(data):
    print("\nPronet Fleet " + __version__)
    for node in data.get("nodes", []):
        resource = node["metrics"].get("resources", {})
        print("  %s | %s | %s | CPU=%s RAM=%s Disk=%s | age=%ss" % (
            clean(node["info"]["name"], 60), node["role"], node["telemetry"], resource.get("cpu_percent", "?"),
            resource.get("ram_percent", "?"), resource.get("disk_percent", "?"), node["age_seconds"]))
        for pair in node["metrics"].get("pairs", []):
            selected = pair.get("selection", {})
            print("    %s | active=%s | probe=%s | recovery_paused=%s | inbound=%s" % (
                pair.get("id", "?"), selected.get("active", "?"), selected.get("last_probe", "UNKNOWN"),
                selected.get("auto_paused", False), pair.get("inbound", "—")))
            for name, health in selected.get("standby_health", {}).items():
                if name != selected.get("active"):
                    print("      standby=%s | probe=%s | failures=%s | RTT=%s ms" % (
                        name, health.get("state", "UNKNOWN"), health.get("failures", 0), health.get("rtt_ms", "—")))
        for row in node["metrics"].get("ip_traffic", {}).get("ips", []):
            print("    IP=%s | %s | %s | RX=%s B/s TX=%s B/s" % (
                row["ip"], clean(row["assignment"], 80), row["activity"], row.get("rx_Bps"), row.get("tx_Bps")))
        if node["metrics"].get("pairs_truncated"):
            print("    NOTE: pair telemetry was limited to the first 100 local records")
    for item in data.get("pairs", []):
        result = item["result"]
        print("\n  " + clean(item["request"]["name"], 60) + " | " + item["state"] + " | " + result.get("phase", "waiting"))
        print("  ID:", item["id"], " Host:", result.get("endpoint", item["request"]["public_ip"] + ":" + str(item["request"]["inbound_port"])))
        for row in result.get("results", []):
            print("    %-20s %-6s up=%s down=%s qualify=%s %s" % (row["profile"], "PASS" if row.get("passed") else "FAIL",
                  row.get("upload_mbps", "—"), row.get("download_mbps", "—"), row.get("soak", {}).get("passed", "pending"), clean(row.get("error", ""))))
        if result.get("error"):
            print("  ERROR:", clean(result["error"]))
        for warning in result.get("warnings", []):
            print("  NOTE:", clean(warning))


def monitor(watch=False, json_output=False):
    while True:
        data = node_client().call("/v1/overview")
        if json_output:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        else:
            if watch and sys.stdout.isatty():
                print("\033[2J\033[H", end="")
            display(data)
        if not watch:
            return
        time.sleep(10)


def managed_run(directory, kind):
    root_linux()
    from .runtime import owned_directory
    directory = owned_directory(directory)
    plan = read_json(directory / "plan.json")
    if kind == "engine":
        recipe = read_json(directory / "launch.json")
        args = recipe["command"]
        binary = pathlib.Path(args[0]).resolve()
        if not binary.is_relative_to((ROOT / "engines").resolve()):
            raise PronetError("Engine executable is outside managed storage")
        env = os.environ.copy()
        for key, value in recipe.get("environment", {}).items():
            if key not in ("AUTH", "SSL_CERT_FILE", "SSL_CERT_DIR", "WSTUNNEL_HTTP_UPGRADE_PATH_PREFIX", "RUST_LOG", "TOKIO_WORKER_THREADS") or not isinstance(value, str) or "\n" in value:
                raise PronetError("Invalid engine environment")
            env[key] = value
        os.execve(str(binary), args, env)
    elif kind == "echo":
        from .wire import ProbeServer, Gateway, bridge_server
        addresses = [("127.0.0.1", plan["echo_port"])]
        if PROFILES[plan["profile"]]["kind"] == "l3":
            addresses.append((tunnel_ips(plan)[0 if plan["role"] == "iran" else 1], plan["echo_port"]))
        servers = []
        for address in addresses:
            server = ProbeServer(address, plan["token"], freebind=address[0] != "127.0.0.1")
            servers.append(server)
            threading.Thread(target=server.serve_forever, daemon=True).start()
        async def auxiliary():
            stop = asyncio.Event()
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGTERM, signal.SIGINT): loop.add_signal_handler(sig, stop.set)
            bridges, frontend = [], None
            if PROFILES[plan["profile"]]["kind"] != "l3":
                if plan["role"] == "foreign":
                    for source, target in ((plan["bridge_health_port"], plan["echo_port"]), (plan["bridge_data_port"], plan["inbound_port"])):
                        async def handler(reader, writer, target=target):
                            await bridge_server(reader, writer, plan["token"], ("127.0.0.1", target))
                        bridges.append(await asyncio.start_server(handler, "127.0.0.1", source, backlog=4096))
                else:
                    path = directory / "probe-front.json"
                    write_json(path, {"bind_ip": "127.0.0.1", "port": plan["probe_front_port"], "mode": "framed",
                                      "frame_key": plan["token"], "active_backend": ["127.0.0.1", plan["health_port"]]})
                    frontend = Gateway(path, directory / "probe-stats.json")
                    await frontend.start()
            await stop.wait()
            for server in bridges: server.close(); await server.wait_closed()
            if frontend: await frontend.close()
        asyncio.run(auxiliary())
        for server in servers:
            server.shutdown()
            server.server_close()
    else:
        raise PronetError("Invalid managed resource")


def managed_gateway(pair_id):
    root_linux()
    identifier(pair_id)
    from .wire import Gateway
    async def run():
        directory = ROOT / "pairs" / pair_id
        gateway = Gateway(directory / "gateway.json", directory / "traffic.json")
        await gateway.start()
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)
        await stop.wait()
        await gateway.close()
    asyncio.run(run())


def repair(pair_id, restart=False):
    root_linux()
    identifier(pair_id)
    from .runtime import Runtime, is_active, service, unit_name
    runtime = Runtime(node_config())
    directory = ROOT / "pairs" / pair_id
    if (directory / "stopped.json").exists():
        raise PronetError("این اتصال از این سرور حذف شده؛ یک جفت‌سازی تازه بساز.")
    with lock(ROOT / "host-operation.lock"):
        selected = read_json(directory / "selection.json")
        for profile in selected["profiles"]:
            plan = runtime.validate(read_json(directory / profile / "plan.json"))
            for kind in ("engine", "echo"):
                name = unit_name(pair_id, profile, kind, plan["role"])
                if restart or not is_active(name):
                    service(name, "reset-failed")
                    service(name, "restart" if restart else "start")
        if runtime.identity["role"] == "iran" and (directory / "active.json").exists():
            gateway = "pronetf-" + pair_id + "-gateway.service"
            if restart or not is_active(gateway):
                service(gateway, "reset-failed")
                service(gateway, "restart" if restart else "start")
        selected.update(auto_paused=False, failures=0, switches=[])
        write_json(directory / "selection.json", selected)
    print("عملیات فقط روی منابع همین اتصال در این سرور انجام شد.")


def enable_traffic():
    root_linux()
    from .runtime import write_unit, unit_path, service
    name = "pronetf-counters.service"
    write_unit(name, "counters", ["/usr/bin/python3", str(APP / "main.py"), "managed-counters"], ROOT, temporary=False)
    path = unit_path(name)
    text = path.read_text().replace("Type=simple\n", "Type=oneshot\nRemainAfterExit=yes\n").replace("Restart=always\n", "Restart=no\n")
    if "Restart=no\n" not in text:
        raise PronetError("Counter unit template changed; refusing an invalid oneshot unit")
    atomic_write(path, text, 0o644)
    command(["systemctl", "daemon-reload"])
    service(name, "enable")
    service(name, "reset-failed")
    service(name, "restart")  # Adds missing counters without resetting existing ones.
    print("شمارنده‌های مستقل IP فعال شدند؛ قواعد فیلتر یا NAT تغییر نکردند.")


def wizard():
    print("Pronet Fleet — راه‌اندازی و پایش تونل")
    if not (CONFIG / "node.json").exists():
        role = input("این سرور کدام است؟ 1) ایران  2) خارج  3) مرکز هماهنگی: ").strip()
        if role == "3":
            url = input("آدرس HTTPS مرکز، مثال https://IRAN_IP:9443: ").strip()
            init_hub(argparse.Namespace(url=url, bind="0.0.0.0", cert=None, key=None, ca=None))
            return
        if role not in ("1", "2"):
            raise PronetError("گزینهٔ معتبر انتخاب نشده است.")
        role = "iran" if role == "1" else "foreign"
        bootstrap = input("مسیر فایل pronet-bootstrap.json: ").strip()
        name = input("نام این سرور: ").strip()
        public = input("IP عمومی این سرور: ").strip()
        bind = input("IP موجود روی سیستم برای bind [همان IP عمومی]: ").strip() or public
        inbound = int(input("پورت اینباند کاربران [2053]: ").strip() or "2053")
        init_node(argparse.Namespace(role=role, bootstrap=bootstrap, name=name, public_ip=public, bind_ip=bind, port=inbound))
    config = node_config()
    if config["role"] == "iran":
        print("1) ساخت اتصال جدید  2) مانیتور زنده")
        if input("انتخاب [1]: ").strip() == "2":
            monitor(watch=True)
            return
        name = input("نام اتصال جدید: ").strip()
        public = input("IP عمومی ایران برای Host [" + config["public_ip"] + "]: ").strip() or config["public_ip"]
        bind = input("IP موجود روی سیستم برای همین Host [" + public + "]: ").strip() or public
        sni = input("SNI اینباند برای تست TLS [اختیاری]: ").strip()
        print("شدت سنجش: 1) سریع  2) متعادل  3) دقیق‌تر با سه تأیید برندگان")
        quality = {"1": "quick", "2": "balanced", "3": "thorough"}.get(input("انتخاب [2]: ").strip() or "2")
        if quality is None: raise PronetError("شدت سنجش معتبر انتخاب نشده است.")
        pair(argparse.Namespace(name=name, port=config["allowed_inbound_ports"][0], profiles=None,
                               no_standby=False, direction="iran-dials", sni=sni, public_ip=public, bind_ip=bind, quality=quality))
    else:
        join(input("کد چهاررقمی روی ایران: ").strip())


def main():
    parser = argparse.ArgumentParser(prog="pronet", description="Pronet Fleet: pair, measure, deploy, monitor")
    parser.add_argument("--version", action="version", version=__version__)
    subs = parser.add_subparsers(dest="action")
    subs.add_parser("menu")
    hub = subs.add_parser("hub-init")
    hub.add_argument("--url", required=True)
    hub.add_argument("--bind", default="0.0.0.0")
    hub.add_argument("--cert"); hub.add_argument("--key"); hub.add_argument("--ca")
    subs.add_parser("hub-run")
    node = subs.add_parser("node-init")
    node.add_argument("--role", choices=["iran", "foreign"], required=True)
    node.add_argument("--bootstrap", required=True); node.add_argument("--name", required=True)
    node.add_argument("--public-ip", required=True); node.add_argument("--bind-ip", required=True)
    node.add_argument("--port", type=int, default=2053)
    subs.add_parser("agent")
    setup = subs.add_parser("pair")
    setup.add_argument("--name", required=True); setup.add_argument("--port", type=int, default=2053)
    setup.add_argument("--profiles"); setup.add_argument("--no-standby", action="store_true")
    setup.add_argument("--public-ip"); setup.add_argument("--bind-ip")
    setup.add_argument("--direction", choices=["iran-dials", "foreign-dials"], default="iran-dials")
    setup.add_argument("--sni", default="")
    setup.add_argument("--quality", choices=["quick", "balanced", "thorough"], default="balanced")
    joining = subs.add_parser("join"); joining.add_argument("code")
    subs.add_parser("status"); subs.add_parser("watch"); subs.add_parser("json")
    subs.add_parser("doctor"); subs.add_parser("profiles")
    subs.add_parser("traffic-enable"); subs.add_parser("managed-counters")
    for name in ("repair", "restart", "remove", "remove-local", "logs"):
        item = subs.add_parser(name); item.add_argument("pair_id")
    managed = subs.add_parser("managed-run"); managed.add_argument("directory"); managed.add_argument("kind", choices=["engine", "echo"])
    gateway = subs.add_parser("managed-gateway"); gateway.add_argument("pair_id")
    firewall = subs.add_parser("managed-firewall"); firewall.add_argument("directory"); firewall.add_argument("kind", choices=["engine", "echo", "gateway"]); firewall.add_argument("operation", choices=["up", "down"])
    args = parser.parse_args()
    try:
        if args.action in (None, "menu"):
            wizard()
        elif args.action == "hub-init": init_hub(args)
        elif args.action == "hub-run": run_hub()
        elif args.action == "node-init": init_node(args)
        elif args.action == "agent":
            root_linux()
            from .agent import Agent
            agent = Agent(node_config())
            signal.signal(signal.SIGTERM, lambda *_: agent.stop.set())
            signal.signal(signal.SIGINT, lambda *_: agent.stop.set())
            agent.run()
        elif args.action == "pair": pair(args)
        elif args.action == "join": join(args.code)
        elif args.action in ("status", "watch", "json"): monitor(args.action == "watch", args.action == "json")
        elif args.action == "profiles":
            for name, spec in PROFILES.items(): print(name, "·", spec["engine"], spec["kind"], spec["carrier"])
        elif args.action == "traffic-enable": enable_traffic()
        elif args.action == "managed-counters":
            root_linux()
            from .accounting import enable
            enable(node_config()["node_id"])
        elif args.action == "doctor":
            from .runtime import inventory
            root_linux()
            print(json.dumps(inventory(), ensure_ascii=False, indent=2))
        elif args.action in ("repair", "restart"): repair(args.pair_id, args.action == "restart")
        elif args.action == "remove-local":
            root_linux()
            from .runtime import Runtime
            with lock(ROOT / "host-operation.lock"):
                print(json.dumps(Runtime(node_config()).cleanup(args.pair_id)))
        elif args.action == "remove":
            identifier(args.pair_id)
            result = node_client().call("/v1/stop", {"pair_id": args.pair_id})
            print("درخواست توقف و حذف منابع همین اتصال در دو طرف ثبت شد:", result["state"])
            print("تأیید پایان عملیات: sudo pronet status")
        elif args.action == "logs":
            identifier(args.pair_id)
            path = ROOT / "pairs" / args.pair_id / "events.jsonl"
            if path.exists():
                for line in path.read_text().splitlines()[-40:]: print(clean(line, 1000))
            command_result = command(["journalctl", "--no-pager", "-n", "50", "-o", "cat", "-u", "pronetf-" + args.pair_id + "-*.service"], check=False)
            for line in command_result.stdout.splitlines(): print(clean(line, 1000))
        elif args.action == "managed-run": managed_run(args.directory, args.kind)
        elif args.action == "managed-gateway": managed_gateway(args.pair_id)
        elif args.action == "managed-firewall":
            root_linux()
            from .runtime import managed_firewall
            managed_firewall(args.directory, args.kind, args.operation)
    except KeyboardInterrupt:
        print("\nنمایش متوقف شد؛ سرویس‌های تونل ادامه می‌دهند.")
    except (PronetError, OSError, ValueError, KeyError) as error:
        print("Pronet: " + clean(error), file=sys.stderr)
        raise SystemExit(1)
