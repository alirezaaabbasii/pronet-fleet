from __future__ import annotations

import base64
import collections
import contextlib
import html
import http.server
import json
import socket
import sqlite3
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .common import MAX_BODY, PronetError, canonical, clean


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward a bearer token to another origin.


class Client:
    def __init__(self, url, token, ca_file=None, test_http=False):
        parsed = urllib.parse.urlsplit(url)
        if (parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/")
                or not parsed.hostname):
            raise PronetError("Hub URL must contain only scheme, host and optional port")
        if parsed.scheme != "https":
            if not test_http or parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "::1"):
                raise PronetError("HTTPS is required for the hub")
        self.url, self.token = url.rstrip("/"), token
        context = ssl.create_default_context(cafile=ca_file) if ca_file else ssl.create_default_context()
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                                                  urllib.request.HTTPSHandler(context=context))

    def call(self, path, data=None, timeout=15):
        if not path.startswith("/v1/") or "\n" in path:
            raise PronetError("Invalid API path")
        request = urllib.request.Request(self.url + path, data=canonical(data) if data is not None else None,
                                         headers={"Authorization": "Bearer " + self.token,
                                                  "Content-Type": "application/json", "Accept": "application/json"})
        try:
            with self.opener.open(request, timeout=timeout) as reply:
                raw = reply.read(MAX_BODY + 1)
        except urllib.error.HTTPError as error:
            try:
                detail = json.loads(error.read(4096)).get("error", str(error.code))
            except (ValueError, AttributeError):
                detail = "HTTP " + str(error.code)
            raise PronetError(clean(detail))
        except (OSError, urllib.error.URLError) as error:
            raise PronetError("Hub connection failed: " + clean(error))
        if len(raw) > MAX_BODY:
            raise PronetError("Hub response too large")
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise PronetError("Invalid hub response")
        return result


class HubServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64

    def __init__(self, address, store, tls=None, public_url=None):
        self.store, self.tls, self.public_url = store, tls, public_url
        self.slots = threading.BoundedSemaphore(64)
        self.rate_lock = threading.Lock()
        self.rates = {}
        super().__init__(address, Handler)

    def process_request(self, request, address):
        if not self.slots.acquire(False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            request.settimeout(8)
            if self.tls:
                request = self.tls.wrap_socket(request, server_side=True)
            super().process_request_thread(request, address)
        except (ssl.SSLError, OSError):
            self.shutdown_request(request)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        pass

    def rate(self, key, maximum, seconds):
        with self.rate_lock:
            current = time.monotonic()
            values = self.rates.setdefault(key, collections.deque())
            while values and current - values[0] > seconds:
                values.popleft()
            if len(self.rates) > 4096:
                self.rates = {k: v for k, v in self.rates.items() if v and current - v[-1] < 3600}
            if len(values) >= maximum:
                return False
            values.append(current)
            return True


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "Pronet"
    sys_version = ""

    def log_message(self, *args):
        pass  # Authorization and enrollment material must not enter access logs.

    def response(self, status, value, content_type="application/json; charset=utf-8", auth=False):
        raw = canonical(value) if content_type.startswith("application/json") else value.encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store, private")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.send_header("Connection", "close")
        if auth:
            self.send_header("WWW-Authenticate", 'Basic realm="Pronet Monitor"')
        self.end_headers()
        self.wfile.write(raw)

    def token(self):
        value = self.headers.get("Authorization", "")
        return value[7:] if value.startswith("Bearer ") else ""

    def admin(self):
        token = self.token()
        value = self.headers.get("Authorization", "")
        if value.startswith("Basic "):
            try:
                user, token = base64.b64decode(value[6:], validate=True).decode().split(":", 1)
                if user != "admin":
                    return False
            except (ValueError, UnicodeError):
                return False
        return self.server.store.admin(token)

    def body(self):
        if self.headers.get_content_type() != "application/json" or self.headers.get("Transfer-Encoding"):
            raise PronetError("JSON with an explicit content length is required")
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            raise PronetError("Invalid content length")
        if not 0 <= length <= MAX_BODY:
            raise PronetError("Request too large or missing content length")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise PronetError("Incomplete request")
        def no_constants(value):
            raise PronetError("Non-finite JSON number refused")
        value = json.loads(raw, parse_constant=no_constants)
        if not isinstance(value, dict):
            raise PronetError("JSON object required")
        return value

    def do_GET(self):
        try:
            if not self.server.rate("ip:" + self.client_address[0], 1200, 60):
                return self.response(429, {"error": "Request rate exceeded"})
            if self.path in ("/", "/monitor"):
                if not self.admin():
                    return self.response(401, "Authentication required", "text/plain; charset=utf-8", auth=True)
                return self.response(200, dashboard(self.server.store.overview()), "text/html; charset=utf-8")
            if self.path == "/v1/overview" and self.admin():
                return self.response(200, self.server.store.overview())
            node = self.server.store.authenticate(self.token())
            if not self.server.rate("node:" + node["id"], 240, 60):
                return self.response(429, {"error": "Node request rate exceeded"})
            if self.path == "/v1/overview":
                return self.response(200, self.server.store.overview(node))
            if self.path == "/v1/jobs":
                return self.response(200, {"job": self.server.store.claim(node)})
            return self.response(404, {"error": "Unknown API endpoint"})
        except PronetError as error:
            self.response(401, {"error": clean(error)})
        except sqlite3.Error:
            self.response(503, {"error": "Hub storage busy; retry"})
        except (ValueError, TypeError, KeyError, RecursionError, OSError):
            self.response(400, {"error": "Invalid request"})

    def do_POST(self):
        try:
            if not self.server.rate("ip:" + self.client_address[0], 1200, 60):
                return self.response(429, {"error": "Request rate exceeded"})
            origin = self.headers.get("Origin")
            if origin and origin != self.server.public_url:
                return self.response(403, {"error": "Cross-origin request refused"})
            body = self.body()
            if self.path == "/v1/enroll":
                if not self.server.rate("enroll:" + self.client_address[0], 20, 3600):
                    return self.response(429, {"error": "Enrollment rate exceeded"})
                return self.response(200, self.server.store.enroll(self.token(), body))
            node = self.server.store.authenticate(self.token())
            if not self.server.rate("node:" + node["id"], 240, 60):
                return self.response(429, {"error": "Node request rate exceeded"})
            if self.path == "/v1/heartbeat":
                result = self.server.store.heartbeat(node, body)
            elif self.path == "/v1/pair":
                result = self.server.store.create_pair(node, body)
            elif self.path == "/v1/join":
                result = self.server.store.join_pair(node, body.get("code"))
            elif self.path == "/v1/stop":
                result = self.server.store.request_stop(node, body.get("pair_id"))
            elif self.path == "/v1/result":
                if set(body) != {"job_id", "lease_proof", "result"}:
                    raise PronetError("Invalid result fields")
                result = self.server.store.finish(node, body["job_id"], body["lease_proof"], body["result"])
            else:
                return self.response(404, {"error": "Unknown API endpoint"})
            self.response(200, result)
        except PronetError as error:
            self.response(400, {"error": clean(error)})
        except sqlite3.Error:
            self.response(503, {"error": "Hub storage busy; retry"})
        except (ValueError, TypeError, KeyError, RecursionError, OSError):
            self.response(400, {"error": "Invalid request"})


def dashboard(data):
    def e(value):
        return html.escape(str(value), quote=True)
    cards = []
    for node in data["nodes"]:
        resource = node["metrics"].get("resources", {})
        stale = node["telemetry"] != "CURRENT"
        facts = " · ".join(label + ": " + e(resource.get(key, "—")) + suffix
                           for label, key, suffix in (("CPU", "cpu_percent", "%"), ("RAM", "ram_percent", "%"), ("Disk", "disk_percent", "%")))
        cards.append('<article><b>' + e(node["info"]["name"]) + '</b><span class="badge ' + ('warn' if stale else 'good') + '">' + e(node["telemetry"]) + '</span><p dir="ltr">' + e(node["info"]["public_ip"]) + '</p><p>' + facts + '</p><small>سن اطلاعات: ' + str(node["age_seconds"]) + ' ثانیه</small></article>')
    rows = []
    for pair in data["pairs"]:
        result = pair["result"]
        runtime = pair.get("runtime", {})
        state = runtime.get("link", "UNKNOWN")
        state_badge = '<span class="badge ' + ('good' if state == 'UP' else 'warn') + '">' + e(state) + '</span>'
        note = str(runtime.get("inbound", "UNKNOWN"))
        if runtime.get("recovery_paused"): note += ' · بازیابی خودکار متوقف است'
        for name, health in runtime.get("standby_health", {}).items():
            if isinstance(health, dict) and name != runtime.get("active"):
                note += ' · پشتیبان ' + str(name) + ': ' + str(health.get("state", "UNKNOWN"))
        row = '<tr><td>' + e(pair["request"]["name"]) + '</td><td dir="ltr">' + e(result.get("endpoint", pair["request"]["public_ip"] + ':' + str(pair["request"]["inbound_port"]))) + '</td><td>' + e(pair["state"]) + '</td><td>' + state_badge + '</td><td>' + e(runtime.get("active") or result.get("active", "—")) + '</td><td>' + e(note) + '</td></tr>'
        rows.append(row)
        details = ([result["error"]] if result.get("error") else []) + result.get("warnings", [])
        if details:
            rows.append('<tr><td colspan="6" class="notes">' + '<br>'.join(e(x) for x in details) + '</td></tr>')
    ip_rows = []
    for node in data["nodes"]:
        for ip in node["metrics"].get("ip_traffic", {}).get("ips", []):
            ip_rows.append('<tr><td>' + e(node["info"]["name"]) + '</td><td dir="ltr">' + e(ip["ip"]) + '</td><td>' + e(ip["assignment"]) + '</td><td>' + e(ip["activity"] if node["telemetry"] == "CURRENT" else "UNKNOWN") + '</td><td>' + e(ip.get("rx_Bps") if ip.get("rx_Bps") is not None else "—") + '</td><td>' + e(ip.get("tx_Bps") if ip.get("tx_Bps") is not None else "—") + '</td></tr>')
    return '''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="15"><title>Pronet Fleet</title><style>
    :root{color-scheme:dark;font-family:Tahoma,Arial;background:#0c1322;color:#e6edf7}body{max-width:1300px;margin:auto;padding:28px 18px}h1{font-size:26px}p,small,.notes{color:#adbbd0;line-height:1.9}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}article,section{padding:20px;background:#142033;border:1px solid #2c3c54;border-radius:14px}section{margin-top:24px;overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px;white-space:nowrap}td,th{padding:12px;text-align:right;border-bottom:1px solid #2c3c54}.notes{white-space:normal;font-size:12px}.badge{float:left;font-size:11px;padding:4px 8px;border-radius:12px}.good{background:#164b3a;color:#9af1cf}.warn{background:#573b1d;color:#ffda91}footer{margin-top:24px;font-size:12px;color:#adbbd0}
    </style></head><body><h1>Pronet Fleet</h1><p>پایش جفت‌سرورها · بازخوانی هر ۱۵ ثانیه · STALE یعنی اطلاعات تازه دریافت نشده؛ خاموشی سرور را ثابت نمی‌کند.</p><div class="cards">''' + ''.join(cards) + '''</div><section><h2>اتصال‌ها</h2><table><tr><th>نام</th><th>Host</th><th>نصب</th><th>لینک جاری</th><th>روش جاری</th><th>اینباند / بازیابی</th></tr>''' + ''.join(rows) + '''</table></section><section><h2>IPهای سرورها</h2><p>IDLE خرابی نیست. UNASSIGNED یعنی تونل ثبت‌شده یا NAT اختصاصی پیدا نشده؛ سرویس دیگری ممکن است از IP استفاده کند. نرخ‌ها بایت بر ثانیه‌اند و شامل SSH، اسکن و حامل تونل می‌شوند.</p><table><tr><th>سرور</th><th>IP</th><th>تخصیص</th><th>فعالیت</th><th>RX/s</th><th>TX/s</th></tr>''' + ''.join(ip_rows) + '''</table></section><footer>این صفحه فقط خواندنی است. ACTIVE نتیجهٔ راه‌اندازی است؛ وضعیت لینک جاری جدا نمایش داده می‌شود. اتصال احرازشدهٔ WS/XHTTP باید با کلاینت بررسی شود.</footer></body></html>'''
