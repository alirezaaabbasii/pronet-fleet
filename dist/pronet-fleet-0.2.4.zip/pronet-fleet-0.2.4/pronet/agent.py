from __future__ import annotations

import threading
import time

from .common import ROOT, PronetError, canonical, clean, digest, event, identifier, lock, read_json, write_json
from .hub import Client
from .runtime import Runtime, resources


WATCH_INTERVAL = 5
JOB_RETENTION = 14 * 86400


class Agent:
    def __init__(self, config, runtime=None, client=None):
        self.config = config
        self.runtime = runtime or Runtime(config)
        self.client = client or Client(config["hub_url"], config["node_id"] + ":" + config["node_secret"], config.get("ca_file"))
        self.stop = threading.Event()

    def execute_job(self, job):
        identifier(job["id"])
        identifier(job["pair_id"])
        fingerprint = digest(canonical({key: job[key] for key in ("op", "payload", "pair_id")}).decode())
        path = ROOT / "jobs" / (job["id"] + ".json")
        with lock(ROOT / "host-operation.lock"):
            cached = read_json(path, {})
            if cached:
                if cached.get("fingerprint") != fingerprint:
                    raise PronetError("Job ID reused with different content")
                if "result" in cached:
                    return cached["result"]
            write_json(path, {"fingerprint": fingerprint, "started": time.time()})
            try:
                result = {"ok": True, "data": self.runtime.execute(job)}
            except Exception as error:
                result = {"ok": False, "error": clean(error)}
                event(ROOT / "agent-events.jsonl", "JOB_FAILED", job["op"] + ": " + clean(error))
            write_json(path, {"fingerprint": fingerprint, "result": result, "completed": time.time()})
            return result

    def heartbeat(self):
        while not self.stop.is_set():
            try:
                metrics = {"resources": resources(), "pairs": []}
                try:
                    from .accounting import snapshot
                    metrics["ip_traffic"] = snapshot(self.config)
                except Exception as error:
                    metrics["ip_traffic"] = {"error": clean(error)}
                paths = sorted((ROOT / "pairs").glob("*/selection.json"),
                               key=lambda path: ((path.parent / "stopped.json").exists(), path.parent.name))
                metrics["pairs_truncated"] = len(paths) > 100
                metrics["pairs_total"] = len(paths)
                for path in paths[:100]:
                    try:
                        metrics["pairs"].append(self.runtime.status(path.parent.name))
                    except Exception as error:
                        metrics["pairs"].append({"id": path.parent.name, "error": clean(error)})
                self.client.call("/v1/heartbeat", metrics)
            except Exception as error:
                event(ROOT / "agent-events.jsonl", "HUB_UNAVAILABLE", error)
            self.stop.wait(10)

    def watch(self):
        while not self.stop.is_set():
            try:
                with lock(ROOT / "host-operation.lock", blocking=False):
                    self.runtime.watchdog()
            except BlockingIOError:
                pass
            except Exception as error:
                event(ROOT / "agent-events.jsonl", "WATCHDOG_ERROR", error)
            # Three failed probes trigger failover; a 5 s cycle turns a dead
            # carrier into a switch in roughly 15-25 s instead of about a minute.
            self.stop.wait(WATCH_INTERVAL)

    def prune_jobs(self, now=None):
        """Bound the local idempotency cache; completed records are only needed
        while the hub can still replay the same lease (minutes, not weeks)."""
        now = now or time.time()
        removed = 0
        for path in (ROOT / "jobs").glob("*.json"):
            try:
                record = read_json(path, {})
                if "result" in record and now - record.get("completed", now) > JOB_RETENTION:
                    path.unlink()
                    removed += 1
            except (OSError, ValueError):
                continue
        return removed

    def run(self):
        workers = [threading.Thread(target=self.heartbeat, daemon=True, name="heartbeat"),
                   threading.Thread(target=self.watch, daemon=True, name="watchdog")]
        for worker in workers: worker.start()
        try:
            self.job_loop()
        finally:
            self.stop.set()
            for worker in workers: worker.join(5)

    def job_loop(self):
        # A result not acknowledged before a network interruption is persisted
        # and retried before claiming another job. A completed operation is not
        # re-executed just because its HTTP response was lost.
        pending_path = ROOT / "pending-result.json"
        next_prune = 0
        while not self.stop.is_set():
            try:
                if time.monotonic() >= next_prune:
                    next_prune = time.monotonic() + 3600
                    with lock(ROOT / "host-operation.lock", blocking=False):
                        self.prune_jobs()
            except (BlockingIOError, OSError):
                pass
            try:
                pending = read_json(pending_path, {})
                if not pending:
                    job = self.client.call("/v1/jobs").get("job")
                    if not job:
                        self.stop.wait(2)
                        continue
                    result = self.execute_job(job)
                    pending = {"job_id": job["id"], "lease_proof": job["lease_proof"], "result": result}
                    write_json(pending_path, pending)
                try:
                    self.client.call("/v1/result", pending)
                except PronetError as error:
                    if "superseded" not in str(error) and "cannot be overwritten" not in str(error):
                        raise
                    # A new lease will replay the local cached result with its
                    # fresh proof. Keep the completed local job record.
                pending_path.unlink(missing_ok=True)
            except Exception as error:
                event(ROOT / "agent-events.jsonl", "CONTROL_RETRY", error)
                self.stop.wait(5)
