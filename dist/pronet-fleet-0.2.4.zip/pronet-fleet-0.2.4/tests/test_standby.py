import json
import pathlib
import tempfile
import unittest
from unittest import mock

from pronet.common import read_json, write_json
from pronet.runtime import Runtime


class StandbyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.runtime = object.__new__(Runtime)
        self.runtime.identity = {"role": "iran"}
        self.runtime.root = pathlib.Path(self.tmp.name)
        self.directory = self.runtime.root / ('a' * 24)
        self.directory.mkdir()
        self.primary, self.backup = 'bp-l3-pck', 'bp-l3-udp-reverse'
        write_json(self.directory / 'active.json', {})
        write_json(self.directory / 'selection.json', {
            'profiles': [self.primary, self.backup], 'active': self.primary,
            'failures': 0, 'switches': [], 'auto_paused': False})
        write_json(self.directory / 'gateway.json', {'active_backend': ['primary', 2053]})
        for profile, address in [(self.primary, 'primary'), (self.backup, 'backup')]:
            write_json(self.directory / profile / 'plan.json', {'probe': address, 'token': 'test-secret'})
        self.stack = []
        for name, value in [('pronet.runtime.engines.probe_address', lambda p: p['probe']),
                            ('pronet.runtime.engines.data_address', lambda p: (p['probe'], 2053))]:
            patcher = mock.patch(name, side_effect=value)
            self.stack.append(patcher); patcher.start()
        self.runtime.validate = lambda p: p

    def tearDown(self):
        for patcher in reversed(self.stack): patcher.stop()
        self.tmp.cleanup()

    def test_healthy_primary_still_probes_warm_standby(self):
        with mock.patch('pronet.runtime.echo', return_value=220) as probe:
            self.runtime.watchdog()
        self.assertEqual([x.args[0] for x in probe.call_args_list], ['primary', 'backup'])
        selected = read_json(self.directory / 'selection.json')
        self.assertEqual(selected['standby_health'][self.backup]['state'], 'OK')
        self.assertEqual(selected['active'], self.primary)
        self.assertEqual(read_json(self.directory / 'gateway.json')['active_backend'], ['primary', 2053])

    def test_backup_loss_and_recovery_are_reported_without_switching_primary(self):
        def probe(address, *_):
            if address == 'backup': raise TimeoutError('idle path')
            return 220
        with mock.patch('pronet.runtime.echo', side_effect=probe):
            for _ in range(4): self.runtime.watchdog()
        selected = read_json(self.directory / 'selection.json')
        self.assertEqual(selected['active'], self.primary)
        self.assertEqual(selected['failures'], 0)
        self.assertFalse(selected['auto_paused'])
        self.assertEqual(selected['standby_health'][self.backup]['failures'], 4)
        with mock.patch('pronet.runtime.echo', return_value=221): self.runtime.watchdog()
        health = read_json(self.directory / 'selection.json')['standby_health'][self.backup]
        self.assertEqual((health['state'], health['failures']), ('OK', 0))
        events = [json.loads(line)['event'] for line in (self.directory / 'events.jsonl').read_text().splitlines()]
        self.assertEqual(events.count('STANDBY_UNCONFIRMED'), 1)
        self.assertEqual(events.count('STANDBY_RECOVERED'), 1)

    def test_primary_loss_still_switches_to_verified_backup(self):
        def probe(address, *_):
            if address == 'primary': raise TimeoutError('primary stopped')
            return 220
        with mock.patch('pronet.runtime.echo', side_effect=probe):
            for _ in range(3): self.runtime.watchdog()
        selected = read_json(self.directory / 'selection.json')
        self.assertEqual(selected['active'], self.backup)
        self.assertEqual(read_json(self.directory / 'gateway.json')['active_backend'], ['backup', 2053])
        self.assertEqual(len(selected['switches']), 1)


if __name__ == '__main__': unittest.main()
