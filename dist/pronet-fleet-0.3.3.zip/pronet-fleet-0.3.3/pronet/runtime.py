"""Linux operations confined to resources owned by this installation."""
from __future__ import annotations

import contextlib
import ipaddress
import json
import os
import pathlib
import platform
import re
import secrets
import shutil
import shlex
import socket
import time

from . import engines
from .common import (APP, CONFIG, ROOT, PronetError, atomic_write, clean, command, inbound_ports,
                     event, identifier, lock, read_json, utc, write_json)
from .model import PROFILES, iface, tunnel_ips, validate_profile
from .wire import DEFAULT_CONNECTION_LIMIT, benchmark, echo, tcp_state, tls_state


MAX_BATCH = 8
REACH_WAIT = 20
DEFAULT_PROBE_SECONDS = 60       # one health probe of each path per minute
DEFAULT_FAILOVER_SECONDS = 120   # primary fully down this long before switching
REARM_SECONDS = 120              # primary healthy this long before failover re-arms
SETTINGS = CONFIG / "settings.json"


def _setting(key, default, low, high):
    try:
        value = read_json(SETTINGS, {}).get(key, default)
    except (OSError, ValueError, PronetError):
        return default
    return value if type(value) is int and low <= value <= high else default


def recent_events(path, limit=6):
    """Last few tunnel events (failover, standby lost/recovered) for the status views."""
    try:
        with open(path, "rb") as file:
            file.seek(0, 2)
            file.seek(max(0, file.tell() - 16384))
            lines = file.read().decode(errors="replace").splitlines()[-limit:]
    except OSError:
        return []
    rows = []
    for line in lines:
        try:
            row = json.loads(line)
            rows.append({"utc": str(row.get("utc", ""))[:20], "event": str(row.get("event", ""))[:40],
                         "detail": clean(row.get("detail", ""), 120)})
        except ValueError:
            continue
    return rows


def probe_seconds():
    return _setting("probe_seconds", DEFAULT_PROBE_SECONDS, 5, 300)


def failover_seconds():
    return _setting("failover_seconds", DEFAULT_FAILOVER_SECONDS, 10, 1800)


def failover_probes():
    """Consecutive failed primary probes (one per watchdog cycle) before failover."""
    return max(2, -(-failover_seconds() // probe_seconds()))


def rearm_probes():
    return max(2, -(-REARM_SECONDS // probe_seconds()))


def existing_raw_ports():
    """Read only address fields of running, same-namespace legacy raw engines.

    Never export command lines, credentials or configuration contents.
    Unknown raw installations fail preflight rather than silently sharing a port.
    """
    known, unresolved = set(), []
    namespace = os.readlink("/proc/self/ns/net")
    for directory in pathlib.Path("/proc").iterdir():
        if not directory.name.isdigit(): continue
        try:
            if os.readlink(directory / "ns/net") != namespace: continue
            name = (directory / "comm").read_text().strip().lower()
            if not any(value in name for value in ("backpack", "paqet", "udp2raw", "pingtunnel")): continue
            executable = pathlib.Path(os.readlink(directory / "exe"))
            if executable.is_relative_to((ROOT / "engines").resolve()): continue
            arguments = (directory / "cmdline").read_bytes().decode(errors="replace").split("\x00")
            candidates = []
            for flag in ("-c", "--config"):
                if flag in arguments and arguments.index(flag) + 1 < len(arguments):
                    candidates.append(pathlib.Path(arguments[arguments.index(flag) + 1]))
            found = set()
            for candidate in candidates:
                if (candidate.suffix.lower() not in (".toml", ".yaml", ".yml", ".json") or not candidate.is_absolute()
                        or not any(candidate.is_relative_to(pathlib.Path(base)) for base in ("/etc/pronet-backpack", "/etc/backpack", "/etc/paqet", "/root/BackPack"))):
                    continue
                if candidate.stat().st_size > 131072: continue
                content = candidate.read_text()
                for match in re.finditer(r'(?:addr|bind_addr|remote_addr|local_addr|address)["\s]*[:=]\s*["\']?[^\s"\']*:(\d{1,5})', content):
                    value = int(match.group(1))
                    if 1 <= value <= 65535: found.add(value)
            if found:
                known.update(found)
            else:
                unresolved.append(name)
        except (OSError, ValueError, IndexError):
            continue
    return sorted(known), sorted(set(unresolved))


def endpoint_occupied(info, address, target_port):
    if "listeners" not in info:
        return target_port in info["ports"]
    return any(row["port"] == target_port and row["address"] in ("*", "0.0.0.0", "::", address, "::ffff:" + address)
               for row in info["listeners"])


def endpoint_has_nat(info, address, target_port):
    return any(ipaddress.ip_address(address) in ipaddress.ip_network(row["destination"])
               and row["first"] <= target_port <= row["last"] for row in info.get("nat_reserved", []))


def native_nat_reservations(document):
    """Reserve native nft DNAT/redirect targets, including complex named maps.

    Unknown expressions reserve all IPv4 endpoints instead of assuming a port
    is free. This reads rules only; it never adopts or rewrites existing rules.
    """
    result = []
    for entry in document.get("nftables", []):
        rule = entry.get("rule", {})
        expressions = rule.get("expr", [])
        if rule.get("family") == "ip6" or not any(isinstance(x, dict) and ("dnat" in x or "redirect" in x) for x in expressions):
            continue
        destination, first, last = "0.0.0.0/0", 1, 65535
        for expression in expressions:
            match = expression.get("match", {}) if isinstance(expression, dict) else {}
            if match.get("op") != "==": continue
            left, right = match.get("left", {}), match.get("right")
            if not isinstance(left, dict): continue
            payload = left.get("payload", {})
            try:
                if payload.get("protocol") == "ip" and payload.get("field") == "daddr":
                    if isinstance(right, str): destination = str(ipaddress.IPv4Network(right, strict=False))
                    elif isinstance(right, dict) and "prefix" in right:
                        value = right["prefix"]
                        destination = str(ipaddress.IPv4Network(str(value["addr"]) + "/" + str(value["len"]), strict=False))
                if payload.get("protocol") == "tcp" and payload.get("field") == "dport":
                    if isinstance(right, int) and not isinstance(right, bool): first = last = right
                    elif isinstance(right, dict) and "range" in right: first, last = map(int, right["range"])
            except (ValueError, KeyError, TypeError):
                destination, first, last = "0.0.0.0/0", 1, 65535
        result.append({"destination": destination, "first": first, "last": last})
    return result


def resources():
    result = {"hostname": socket.gethostname(), "cores": os.cpu_count(), "utc": utc()}
    if platform.system() != "Linux":
        return result
    try:
        memory = {}
        for line in pathlib.Path("/proc/meminfo").read_text().splitlines():
            key, value = line.split(":", 1)
            memory[key] = int(value.strip().split()[0]) * 1024
        result.update(ram_percent=round(100 * (1 - memory["MemAvailable"] / memory["MemTotal"]), 1),
                      ram_total_mb=memory["MemTotal"] // 1048576,
                      ram_used_mb=(memory["MemTotal"] - memory["MemAvailable"]) // 1048576,
                      swap_used_mb=(memory["SwapTotal"] - memory["SwapFree"]) // 1048576,
                      uptime_seconds=int(float(pathlib.Path("/proc/uptime").read_text().split()[0])))
        disk = shutil.disk_usage(ROOT)
        result["disk_percent"] = round(100 * disk.used / disk.total, 1)
        fields = [int(x) for x in pathlib.Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
        previous = read_json(ROOT / "cpu-sample.json", {})
        total, idle = sum(fields), fields[3] + fields[4]
        if previous and total > previous["total"]:
            result["cpu_percent"] = round(max(0, min(100, 100 * (1 - (idle - previous["idle"]) / (total - previous["total"])))), 1)
        write_json(ROOT / "cpu-sample.json", {"total": total, "idle": idle})
    except (OSError, ValueError, KeyError) as error:
        result["resource_error"] = clean(error)
    return result


def inventory():
    addresses = json.loads(command(["ip", "-j", "-4", "address", "show"]).stdout)
    ips = [x["local"] for link in addresses for x in link.get("addr_info", [])]
    routes = json.loads(command(["ip", "-j", "-4", "route", "show", "table", "all"]).stdout)
    ports, ssh_ports, listeners = set(), set(), []
    output = command(["ss", "-H", "-lntup"]).stdout
    for line in output.splitlines():
        columns = line.split()
        if len(columns) < 5:
            continue
        with contextlib.suppress(ValueError):
            value = int(columns[4].rsplit(":", 1)[1])
            ports.add(value)
            if columns[0] == "tcp":
                listeners.append({"address": columns[4].rsplit(":", 1)[0].strip("[]"), "port": value})
            if "sshd" in line:
                ssh_ports.add(value)
    reservations = []
    for path in (ROOT / "pairs").glob("*/*/plan.json"):
        try:
            if (path.parent.parent / "stopped.json").exists(): continue
            plan = read_json(path)
            ports.update(plan[key] for key in ("control_port", "echo_port", "health_port", "data_port", "bridge_data_port", "bridge_health_port", "probe_front_port"))
            reservations.append(plan["subnet"])
        except (OSError, ValueError, KeyError):
            continue
    try:
        # Read-only snapshot fingerprint makes later unexpected changes visible.
        before_rules = command(["iptables-save"]).stdout
    except PronetError:
        before_rules = "unavailable"
    import hashlib
    raw_ports, unresolved_raw = existing_raw_ports()
    ports.update(raw_ports)
    nat_reserved = []
    nft_readable = True
    if shutil.which("nft"):
        try:
            nat_reserved.extend(native_nat_reservations(json.loads(command(["nft", "-j", "list", "ruleset"]).stdout)))
        except (PronetError, ValueError, TypeError):
            nft_readable = False
    for line in before_rules.splitlines():
        if not line.startswith("-A "):
            continue
        fields = shlex.split(line)
        def option(name, fallback=None):
            return fields[fields.index(name) + 1] if name in fields else fallback
        if option("-j") not in ("DNAT", "REDIRECT") or option("-p", "tcp") not in ("tcp", "all"):
            continue
        destination = option("-d", "0.0.0.0/0")
        if "!" in fields:
            destination = "0.0.0.0/0"  # Conservatively reserve inverted/complex rules.
        text = option("--dport", option("--dports", "1:65535"))
        for item in text.split(","):
            try:
                bounds = [int(x) for x in item.replace("-", ":").split(":")]
                nat_reserved.append({"destination": destination, "first": bounds[0], "last": bounds[-1]})
            except ValueError:
                nat_reserved.append({"destination": "0.0.0.0/0", "first": 1, "last": 65535})
    ephemeral_range = [32768, 60999]
    with contextlib.suppress(OSError, ValueError):
        low, high = (int(x) for x in pathlib.Path("/proc/sys/net/ipv4/ip_local_port_range").read_text().split()[:2])
        ephemeral_range = [low, high]
    from . import __version__
    return {"version": __version__, "ips": ips, "ports": sorted(ports), "listeners": listeners, "ephemeral_range": ephemeral_range, "ssh_ports": sorted(ssh_ports | {22}), "nat_reserved": nat_reserved,
            "unresolved_raw_engines": unresolved_raw, "firewall_readable": before_rules != "unavailable" and nft_readable,
            "routes": [row["dst"] for row in routes if row.get("dst") not in (None, "default")],
            "reserved_subnets": reservations, "tun": pathlib.Path("/dev/net/tun").exists(),
            "systemd": pathlib.Path("/run/systemd/system").is_dir(), "arch": engines.architecture(),
            "iptables": bool(shutil.which("iptables")), "resources": resources(),
            "firewall_fingerprint": hashlib.sha256(re.sub(r"\[\d+:\d+\]", "[0:0]", "\n".join(x for x in before_rules.splitlines() if not x.startswith("#"))).encode()).hexdigest()}


def systemd_quote(value):
    if not isinstance(value, str) or any(ord(c) < 32 for c in value):
        raise PronetError("Invalid service argument")
    return '"' + value.replace("%", "%%").replace("\\", "\\\\").replace('"', '\\"') + '"'


def systemd_path(value):
    # WorkingDirectory is a single path setting, not an ExecStart word list.
    # Quotes are literal there and make an otherwise absolute path invalid.
    value = str(value)
    if not value.startswith("/") or any(ord(c) < 32 for c in value):
        raise PronetError("Service directory must be an absolute path")
    return value.replace("%", "%%")


def unit_name(pair_id, profile, kind, role):
    identifier(pair_id)
    if profile not in PROFILES or kind not in ("engine", "echo") or role not in ("iran", "foreign"):
        raise PronetError("Unknown service resource")
    return "pronetf-" + pair_id + "-" + role + "-" + str(list(PROFILES).index(profile)) + "-" + kind + ".service"


def unit_path(name):
    if not name.startswith("pronetf-") or not name.endswith(".service") or "/" in name or ".." in name:
        raise PronetError("Refusing unmanaged service")
    return pathlib.Path("/etc/systemd/system") / name


def write_unit(name, owner, args, working_directory, temporary=True, firewall_kind=None):
    path = unit_path(name)
    marker = "# Pronet Fleet owner=" + owner + "\n"
    if path.is_symlink() or (path.exists() and not path.read_text().startswith(marker)):
        raise PronetError("Service already exists outside this pair")
    # Permanent services must never enter a terminal "failed" state: with the
    # old 5-starts-per-10-minutes limit, a boot-time race (IP not yet assigned,
    # xtables lock held by Docker) or a brief upstream outage left a committed
    # carrier dead until someone logged in. Temporary trial services keep the
    # bounded limit and still expire.
    limits = "StartLimitIntervalSec=600\nStartLimitBurst=5\n" if temporary else "StartLimitIntervalSec=0\n"
    text = marker + "[Unit]\nDescription=Pronet Fleet isolated tunnel resource\nAfter=network-online.target\nWants=network-online.target\n" + limits + "[Service]\nType=simple\n"
    text += "WorkingDirectory=" + systemd_path(working_directory) + "\n"
    for key, value in (("PRONET_STATE", str(ROOT)), ("PRONET_CONFIG", str(CONFIG))):
        text += "Environment=" + systemd_quote(key + "=" + value) + "\n"
    # Used only by the privileged Linux integration harness; never accepted
    # from network jobs or generated by the normal installer.
    namespace = os.environ.get("PRONET_TEST_NETNS", "")
    if namespace:
        import re
        if not re.fullmatch(r"/run/netns/pronettest-[a-f0-9]{8}-(iran|foreign)", namespace):
            raise PronetError("Invalid isolated test namespace")
        text += "NetworkNamespacePath=" + namespace + "\n"
    text += "ExecStart=" + " ".join(systemd_quote(str(x)) for x in args) + "\n"
    if firewall_kind:
        prefix = ["/usr/bin/python3", str(APP / "main.py"), "managed-firewall", str(working_directory), firewall_kind]
        text += "ExecStartPre=" + " ".join(map(systemd_quote, prefix + ["up"])) + "\n"
        text += "ExecStopPost=" + " ".join(map(systemd_quote, prefix + ["down"])) + "\n"
    # Restart=always also covers an engine that exits 0 on a lost peer.
    # Capacity: a commercial gateway holds thousands of sockets; 384M/128 tasks
    # risked OOM-kill or pthread_create failure of Go engines under load.
    text += ("Restart=no\n" if temporary else "Restart=always\n") + "RestartSec=5\nTimeoutStopSec=15\nKillMode=control-group\nUMask=0077\nLimitNOFILE=65536\nTasksMax=512\nMemoryMax=1G\n"
    if temporary:
        text += "RuntimeMaxSec=900\n"
    text += "[Install]\nWantedBy=multi-user.target\n"
    atomic_write(path, text, 0o644)


def service(name, action):
    unit_path(name)
    if action not in ("start", "stop", "restart", "enable", "disable", "reset-failed"):
        raise PronetError("Unsupported service action")
    return command(["systemctl", action, name], timeout=35, check=action not in ("stop", "disable", "reset-failed"))


def is_active(name):
    return command(["systemctl", "is-active", name], check=False).stdout.strip() == "active"


def stop_confirmed(name):
    service(name, "stop")
    state = command(["systemctl", "show", name, "--property=ActiveState", "--value"]).stdout.strip()
    if state not in ("inactive", "failed"):
        raise PronetError("Service stop was not confirmed; ownership files were retained")


def owned_directory(path):
    path = pathlib.Path(path)
    base = (ROOT / "pairs").resolve()
    if path.is_symlink() or not path.resolve().is_relative_to(base):
        raise PronetError("Refusing directory outside managed pairs")
    relative = path.resolve().relative_to(base)
    if len(relative.parts) != 2 or relative.parts[1] not in PROFILES:
        raise PronetError("Invalid managed directory")
    identifier(relative.parts[0])
    return path


def firewall_rules(plan, kind):
    spec = PROFILES[plan["profile"]]
    iran = plan["role"] == "iran"
    peer = plan["foreign_ip"] if iran else plan["iran_ip"]
    tag = "pronetf:" + plan["pair_id"] + ":" + plan["profile"] + ":" + kind
    rules = []
    def add(chain, match):
        rules.append([chain] + match + ["-m", "comment", "--comment", tag, "-j", "ACCEPT"])
    if kind == "engine":
        # PCK's engine owns its raw packet/RST guard; ordinary carrier permits
        # are still restricted to this pair's IP and port, never all traffic.
        protocols = ["udp"] if spec["family"] == "udp" else ["tcp"]
        if spec["family"] == "icmp":
            protocols = []
            add("INPUT", ["-s", peer, "-d", plan["bind_ip"], "-p", "icmp"])
            add("OUTPUT", ["-d", peer, "-s", plan["bind_ip"], "-p", "icmp"])
        if spec["engine"] == "frp" and spec["carrier"] == "quic":
            protocols = ["tcp", "udp"]
        for protocol in protocols:
            for field in ("--dport", "--sport"):
                add("INPUT", ["-s", peer, "-d", plan["bind_ip"], "-p", protocol, field, str(plan["control_port"])])
                add("OUTPUT", ["-d", peer, "-s", plan["bind_ip"], "-p", protocol, field, str(plan["control_port"])])
        if spec["kind"] == "l3":
            own, other = tunnel_ips(plan) if iran else tuple(reversed(tunnel_ips(plan)))
            for number in inbound_ports(plan):
                for field in ("--dport", "--sport"):
                    add("INPUT", ["-i", iface(plan), "-s", other, "-d", own, "-p", "tcp", field, str(number)])
                    add("OUTPUT", ["-o", iface(plan), "-s", own, "-d", other, "-p", "tcp", field, str(number)])
    elif kind == "echo":
        if spec["kind"] == "l3":
            own, other = tunnel_ips(plan) if iran else tuple(reversed(tunnel_ips(plan)))
            for field in ("--dport", "--sport"):
                add("INPUT", ["-i", iface(plan), "-s", other, "-d", own, "-p", "tcp", field, str(plan["echo_port"])])
                add("OUTPUT", ["-o", iface(plan), "-s", own, "-d", other, "-p", "tcp", field, str(plan["echo_port"])])
    elif kind == "gateway" and iran:
        tag = "pronetf:" + plan["pair_id"] + ":gateway"
        for number in inbound_ports(plan):
            add("INPUT", ["-d", plan.get("gateway_bind_ip", plan["bind_ip"]), "-p", "tcp", "--dport", str(number)])
            add("OUTPUT", ["-s", plan.get("gateway_bind_ip", plan["bind_ip"]), "-p", "tcp", "--sport", str(number)])
    else:
        raise PronetError("Invalid managed firewall scope")
    return rules


def managed_firewall(directory, kind, action):
    directory = owned_directory(directory)
    if action not in ("up", "down"):
        raise PronetError("Invalid rule action")
    plan = validate_profile(read_json(directory / "plan.json"))
    executable = shutil.which("iptables")
    if not executable:
        raise PronetError("iptables compatibility tool is required; existing firewall is not replaced")
    for chain, *rule in firewall_rules(plan, kind):
        exists = command([executable, "-w", "5", "-C", chain] + rule, check=False).returncode == 0
        if action == "up" and not exists:
            command([executable, "-w", "5", "-I", chain, "1"] + rule)
        elif action == "down" and exists:
            command([executable, "-w", "5", "-D", chain] + rule, check=False)


def inbound_report(plan):
    """Panel inbound state on the foreign node. "inbound" stays the single
    summary older views use: open only when EVERY client port listens."""
    states = {str(number): tcp_state(("127.0.0.1", number)) for number in inbound_ports(plan)}
    values = set(states.values())
    summary = "open" if values == {"open"} else "refused" if "refused" in values else "unconfirmed"
    result = {"inbound": summary}
    if len(states) > 1:
        result["inbound_ports"] = states
    return result


class Runtime:
    def __init__(self, identity):
        self.identity = identity
        self.root = ROOT / "pairs"
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)

    def validate(self, plan):
        validate_profile(plan)
        if plan["role"] != self.identity["role"] or plan["bind_ip"] != self.identity["bind_ip"]:
            raise PronetError("Job does not match this node's fixed identity")
        own_public = plan["iran_ip"] if plan["role"] == "iran" else plan["foreign_ip"]
        if own_public != self.identity["public_ip"]:
            raise PronetError("Job public IP differs from enrollment")
        allowed = self.identity.get("allowed_inbound_ports", [2053])
        if any(number not in allowed for number in inbound_ports(plan)):
            raise PronetError("Inbound port was not locally authorized during enrollment")
        return plan

    def directory(self, plan):
        self.validate(plan)
        return self.root / plan["pair_id"] / plan["profile"]

    def prepare(self, plan, info=None):
        directory = self.directory(plan)
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        previous = read_json(directory / "plan.json", {})
        immutable = ("token", "subnet", "control_port", "echo_port", "health_port", "data_port", "inbound_port",
                     "bridge_data_port", "bridge_health_port", "probe_front_port", "direction")
        if previous and (any(previous.get(k) != plan.get(k) for k in immutable)
                         or inbound_ports(previous) != inbound_ports(plan)):
            raise PronetError("Existing profile differs; refusing overwrite")
        info = info or inventory()
        if plan["bind_ip"] not in info["ips"]:
            raise PronetError("Bind IP is not assigned to this host (public NAT address must be configured separately)")
        if plan["role"] == "iran" and plan.get("gateway_bind_ip", plan["bind_ip"]) not in info["ips"]:
            raise PronetError("Public gateway bind address is not assigned to Iran")
        if not info["systemd"] or not info["iptables"]:
            raise PronetError("Linux systemd and iptables tools are required")
        if any(number in info["ssh_ports"] for number in inbound_ports(plan)):
            raise PronetError("Requested inbound port belongs to SSH")
        if not previous:
            for key in ("control_port", "echo_port", "health_port", "data_port", "bridge_data_port", "bridge_health_port", "probe_front_port"):
                if plan[key] in info["ports"]:
                    raise PronetError("A reserved port became occupied; no existing service was changed")
            network = ipaddress.ip_network(plan["subnet"])
            if PROFILES[plan["profile"]]["kind"] == "l3":
                if not info["tun"]:
                    raise PronetError("TUN device unavailable")
                for destination in info["routes"] + info["reserved_subnets"]:
                    with contextlib.suppress(ValueError):
                        if network.overlaps(ipaddress.ip_network(destination)):
                            raise PronetError("Tunnel subnet overlaps an existing route")
        write_json(directory / "plan.json", plan)
        (directory / "retired.json").unlink(missing_ok=True)
        write_json(directory / "before.json", info) if not (directory / "before.json").exists() else None
        engine = PROFILES[plan["profile"]]["engine"]
        binaries = engines.install_asset(engine, ROOT / "engines")
        reply = {"profile": plan["profile"], "prepared": True}
        if plan["role"] == "iran" and engine in ("frp", "wstunnel"):
            make_cert = engines.wstunnel_certificate if engine == "wstunnel" else engines.certificate
            reply["server_cert"] = make_cert(directory, "pn-" + plan["pair_id"] + ".invalid", plan["iran_ip"])
        if plan["role"] == "iran" and engine == "chisel":
            reply["server_fingerprint"] = engines.chisel_key(directory)
        if plan["role"] == "iran" and engine == "rathole":
            from .extra_engines import noise_key
            reply["server_noise_public_key"] = noise_key(directory, binaries["rathole"])
        return reply

    def start(self, plan):
        directory = self.directory(plan)
        previous = read_json(directory / "plan.json")
        if (any(previous.get(k) != plan.get(k) for k in ("token", "subnet", "control_port", "echo_port", "health_port", "data_port", "inbound_port", "bridge_data_port", "bridge_health_port", "probe_front_port", "direction"))
                or inbound_ports(previous) != inbound_ports(plan)):
            raise PronetError("Profile changed after preparation")
        write_json(directory / "plan.json", plan)
        (directory / "retired.json").unlink(missing_ok=True)
        if plan.get("server_cert"):
            certificate = plan["server_cert"]
            if not isinstance(certificate, str) or len(certificate) > 16384 or not certificate.startswith("-----BEGIN CERTIFICATE-----"):
                raise PronetError("Invalid peer certificate")
            atomic_write(directory / "peer.crt", certificate)
        binaries = engines.install_asset(PROFILES[plan["profile"]]["engine"], ROOT / "engines")
        recipe = engines.render(plan, directory, binaries)
        if recipe["validate"]:
            command(recipe["validate"])
        write_json(directory / "launch.json", recipe)
        self.write_services(plan, temporary=not (directory / "committed.json").exists())
        command(["systemctl", "daemon-reload"])
        for kind in ("engine", "echo"):
            name = unit_name(plan["pair_id"], plan["profile"], kind, plan["role"])
            service(name, "reset-failed")
            if not is_active(name):
                service(name, "start")
        return {"started": True, "profile": plan["profile"]}

    def prepare_batch(self, plans):
        """Prepare several carriers with ONE host inventory (it walks /proc,
        iptables and nft, so per-carrier inventories cost seconds each)."""
        info = inventory()
        replies = {}
        for plan in plans[:MAX_BATCH]:
            name = plan.get("profile")
            try:
                replies[name] = self.prepare(plan, info)
            except Exception as error:
                replies[str(name)] = {"error": clean(error)}
        return {"profiles": replies}

    def start_batch(self, plans):
        replies = {}
        for plan in plans[:MAX_BATCH]:
            name = plan.get("profile")
            try:
                replies[name] = self.start(plan)
            except Exception as error:
                replies[str(name)] = {"error": clean(error)}
        return {"profiles": replies}

    def probe_batch(self, pair_id, profiles, seconds=REACH_WAIT):
        """Wait for end-to-end reachability of several carriers IN PARALLEL.

        Each carrier is reported as soon as its first authenticated echo
        succeeds, or as failed when its temporary engine exits (no restart is
        configured for trial units) or the shared deadline passes.
        """
        import concurrent.futures
        identifier(pair_id)
        if not isinstance(profiles, list) or len(profiles) > MAX_BATCH or any(p not in PROFILES for p in profiles):
            raise PronetError("Invalid probe batch")
        seconds = max(5, min(60, int(seconds)))
        deadline = time.monotonic() + seconds
        def probe(profile):
            try:
                plan = self.validate(read_json(self.root / pair_id / profile / "plan.json"))
            except (OSError, ValueError, KeyError, PronetError) as error:
                return profile, {"reachable": False, "reason": "plan unavailable: " + clean(error)}
            address = engines.probe_address(plan)
            unit = unit_name(pair_id, profile, "engine", plan["role"])
            started = time.monotonic()
            while time.monotonic() < deadline:
                try:
                    delay = echo(address, plan["token"], 2)
                    return profile, {"reachable": True, "rtt_ms": round(delay, 1),
                                     "seconds": round(time.monotonic() - started, 1)}
                except (OSError, ValueError, PronetError):
                    pass
                if time.monotonic() - started > 3 and not is_active(unit):
                    return profile, {"reachable": False, "reason": "local engine exited (see: sudo pronet logs " + pair_id + ")"}
                time.sleep(1)
            return profile, {"reachable": False, "reason": "no end-to-end connectivity within %d s" % seconds}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, len(profiles))) as pool:
            results = dict(pool.map(probe, profiles))
        return {"profiles": results}

    def retire_batch(self, pair_id, profiles):
        identifier(pair_id)
        retired = []
        for profile in profiles[:len(PROFILES)]:
            if profile not in PROFILES:
                raise PronetError("Unknown profile")
            if (self.root / pair_id / profile / "plan.json").exists():
                self.remove_profile(pair_id, profile)
            retired.append(profile)
        return {"retired": retired}

    def write_services(self, plan, temporary):
        directory = self.directory(plan)
        for kind in ("engine", "echo"):
            args = ["/usr/bin/python3", str(APP / "main.py"), "managed-run", str(directory), kind]
            write_unit(unit_name(plan["pair_id"], plan["profile"], kind, plan["role"]), plan["pair_id"], args,
                       directory, temporary=temporary, firewall_kind=kind)

    def measure(self, plan, wait=None):
        self.validate(plan)
        address = engines.probe_address(plan)
        wait = wait if wait is not None else plan.get("reach_wait", REACH_WAIT)
        deadline = time.monotonic() + wait
        reached = False
        while time.monotonic() < deadline:
            try:
                echo(address, plan["token"], 2)
                reached = True
                break
            except (OSError, ValueError, PronetError):
                time.sleep(1)
        if not reached:
            # Fast-fail: an unreachable carrier used to spend another ~60 s in
            # benchmark timeouts before reporting the same failure.
            return {"profile": plan["profile"], "passed": False, "echo_ms": [], "success_ratio": 0,
                    "upload_mbps": None, "download_mbps": None, "half_close": False, "after_idle": False,
                    "integrity": False, "utc": utc(), "stage": "reach", "errors": ["unreachable"],
                    "reason": "no end-to-end connectivity within %d s" % wait}
        if plan.get("long_test") is True:
            if plan.get("test_quality") == "quick":
                result = benchmark(address, plan["token"], rounds=6, size=1024 * 1024, idle=3, budget=70)
            else:
                result = benchmark(address, plan["token"], rounds=15, size=4 * 1024 * 1024, idle=10, timeout=20, budget=80)
            result["stage"] = "soak"
        else:
            if plan.get("test_quality") == "quick":
                result = benchmark(address, plan["token"], rounds=3, size=262144, idle=1)
            else:
                result = benchmark(address, plan["token"])
            result["stage"] = "screen"
        result["profile"] = plan["profile"]
        return result

    def commit(self, pair_id, profiles):
        identifier(pair_id)
        if not isinstance(profiles, list) or not 1 <= len(profiles) <= 2 or any(p not in PROFILES for p in profiles):
            raise PronetError("Commit requires one winner and at most one standby")
        plans = []
        for profile in profiles:
            directory = self.root / pair_id / profile
            plan = self.validate(read_json(directory / "plan.json"))
            self.write_services(plan, temporary=False)
            write_json(directory / "committed.json", {"utc": utc()})
            plans.append(plan)
        command(["systemctl", "daemon-reload"])
        for plan in plans:
            for kind in ("engine", "echo"):
                name = unit_name(pair_id, plan["profile"], kind, plan["role"])
                service(name, "enable")
                service(name, "reset-failed")
                service(name, "restart")
        for directory in (self.root / pair_id).iterdir():
            if directory.is_dir() and directory.name in PROFILES and directory.name not in profiles:
                self.remove_profile(pair_id, directory.name)
        write_json(self.root / pair_id / "selection.json", {"profiles": profiles, "active": profiles[0],
                   "failures": 0, "switches": [], "auto_paused": False, "utc": utc()})
        return {"committed": profiles}

    def activate(self, pair_id):
        identifier(pair_id)
        selected = read_json(self.root / pair_id / "selection.json")
        directory = self.root / pair_id / selected["active"]
        plan = self.validate(read_json(directory / "plan.json"))
        if plan["role"] != "iran":
            result = dict(inbound_report(plan), gateway="not-required")
            write_json(self.root / pair_id / "active.json", result)
            return result
        name = "pronetf-" + pair_id + "-gateway.service"
        config_path = self.root / pair_id / "gateway.json"
        current_inventory = inventory()
        bind_ip = plan.get("gateway_bind_ip", plan["bind_ip"])
        ports = inbound_ports(plan)
        for number in ports:
            if endpoint_has_nat(current_inventory, bind_ip, number):
                raise PronetError("An external NAT rule took port %d during setup; it was not modified" % number)
        if not config_path.exists():
            # The OS bind is authoritative and happens before publishing success.
            for number in ports:
                with socket.socket() as sock:
                    try:
                        sock.bind((bind_ip, number))
                    except OSError as error:
                        raise PronetError("Port %d on %s is already in use (%s)" % (number, bind_ip, clean(error)))
        write_json(config_path, {"bind_ip": bind_ip, "port": ports[0], "ports": ports,
                                "active_backend": list(engines.data_address(plan)), "connection_limit": DEFAULT_CONNECTION_LIMIT,
                                "mode": "plain" if PROFILES[plan["profile"]]["kind"] == "l3" else "framed", "frame_key": plan["token"]})
        write_unit(name, pair_id, ["/usr/bin/python3", str(APP / "main.py"), "managed-gateway", pair_id],
                   directory, temporary=False, firewall_kind="gateway")
        command(["systemctl", "daemon-reload"])
        service(name, "enable")
        service(name, "reset-failed")
        if not is_active(name):
            service(name, "start")
        time.sleep(.3)
        if not is_active(name):
            raise PronetError("Public gateway could not bind; inspect pair logs")
        address = (plan.get("gateway_bind_ip", plan["bind_ip"]), plan["inbound_port"])
        result = {"gateway": "active", "local_endpoint": tcp_state(address), "tls": tls_state(address, plan.get("sni", "")),
                  "external_client_test": "not-performed"}
        if len(ports) > 1:
            result["local_endpoints"] = {str(number): tcp_state((bind_ip, number)) for number in ports}
        write_json(self.root / pair_id / "active.json", result)
        return result

    def remove_profile(self, pair_id, profile):
        directory = self.root / identifier(pair_id) / profile
        if profile not in PROFILES or directory.is_symlink() or not (directory / "plan.json").is_file():
            raise PronetError("Refusing removal of unowned profile")
        plan = self.validate(read_json(directory / "plan.json"))
        for kind in ("echo", "engine"):
            name = unit_name(pair_id, profile, kind, plan["role"])
            path = unit_path(name)
            marker = "# Pronet Fleet owner=" + pair_id + "\n"
            if path.exists() and not path.read_text().startswith(marker):
                raise PronetError("Service ownership changed; refusing removal")
            if path.exists():
                service(name, "disable")
                stop_confirmed(name)
                path.unlink()
            with contextlib.suppress(PronetError):
                managed_firewall(directory, kind, "down")
        # Keep files as a root-only recovery record; do not reallocate old slots
        # while an external process could still be using them.
        write_json(directory / "retired.json", {"utc": utc()})

    def cleanup(self, pair_id):
        directory = self.root / identifier(pair_id)
        name = "pronetf-" + pair_id + "-gateway.service"
        path = unit_path(name)
        if self.identity["role"] == "iran" and path.exists():
            if not path.read_text().startswith("# Pronet Fleet owner=" + pair_id + "\n"):
                raise PronetError("Gateway ownership mismatch")
            service(name, "disable")
            stop_confirmed(name)
            path.unlink()
        if directory.exists():
            for child in directory.iterdir():
                if child.is_dir() and child.name in PROFILES and (child / "plan.json").is_file():
                    self.remove_profile(pair_id, child.name)
            write_json(directory / "stopped.json", {"utc": utc()})
            (directory / "active.json").unlink(missing_ok=True)
        command(["systemctl", "daemon-reload"])
        return {"cleaned": pair_id}

    def status(self, pair_id):
        directory = self.root / identifier(pair_id)
        selected = read_json(directory / "selection.json", {})
        result = {"id": pair_id, "selection": selected, "profiles": {},
                  "traffic": read_json(directory / "traffic.json", {}), "active": read_json(directory / "active.json", {})}
        for profile in selected.get("profiles", []):
            plan = self.validate(read_json(directory / profile / "plan.json"))
            result["profiles"][profile] = {"engine_active": is_active(unit_name(pair_id, profile, "engine", plan["role"]))}
            if self.identity["role"] == "foreign":
                result.update(inbound_report(plan))
        if (directory / "stopped.json").exists():
            result["state"] = "STOPPED"
        if self.identity["role"] == "iran":
            result["health"] = {"probe_seconds": probe_seconds(), "failover_seconds": failover_seconds(),
                                "failover_probes": failover_probes()}
            result["events"] = recent_events(directory / "events.jsonl")
        return result

    def watchdog(self):
        if self.identity["role"] != "iran":
            return
        for directory in self.root.iterdir():
            if not directory.is_dir() or not (directory / "active.json").exists() or (directory / "stopped.json").exists():
                continue
            try:
                with lock(directory / "watchdog.lock", blocking=False):
                    selected = read_json(directory / "selection.json")
                    active = selected["active"]
                    plan = self.validate(read_json(directory / active / "plan.json"))
                    try:
                        delay = echo(engines.probe_address(plan), plan["token"], 3)
                        healthy = selected.get("healthy_probes", 0) + 1
                        selected.update(failures=0, last_probe="OK", rtt_ms=round(delay, 2), healthy_probes=healthy)
                        if selected.get("auto_paused") and healthy >= rearm_probes():
                            # The path came back by itself (e.g. a server whose
                            # traffic quota was recharged). Re-arm automatic
                            # failover instead of leaving it off until a manual
                            # repair. The 30-minute switch budget still applies.
                            selected.update(auto_paused=False, pause_id=None)
                            event(directory / "events.jsonl", "AUTO_FAILOVER_REARMED",
                                  "primary healthy again for %d probes" % healthy)
                        gateway = read_json(directory / "gateway.json")
                        desired = list(engines.data_address(plan))
                        if gateway.get("active_backend") != desired:
                            # A working primary is not a failover: keep the
                            # connections that are currently established.
                            gateway.update(active_backend=desired, frame_key=plan["token"], failed_backends=[],
                                           mode="plain" if PROFILES[active]["kind"] == "l3" else "framed")
                            write_json(directory / "gateway.json", gateway)
                    except (OSError, ValueError, PronetError):
                        selected["failures"] += 1
                        selected["healthy_probes"] = 0
                        selected["last_probe"] = "UNCONFIRMED"
                    # Exercise the warm carrier even while the primary works. This
                    # keeps idle UDP mappings/session state in use and reports an
                    # unhealthy standby before it is needed. Never switch/restart
                    # a working primary solely because a backup probe failed.
                    previous_health = selected.get("standby_health", {})
                    health = {}
                    for candidate in selected["profiles"]:
                        if candidate == active:
                            continue
                        previous = previous_health.get(candidate, {})
                        row = {"utc": utc()}
                        try:
                            other = self.validate(read_json(directory / candidate / "plan.json"))
                            delay = echo(engines.probe_address(other), other["token"], 3)
                            row.update(state="OK", failures=0, rtt_ms=round(delay, 2))
                            if previous.get("failures", 0) >= 3:
                                event(directory / "events.jsonl", "STANDBY_RECOVERED", candidate)
                        except (OSError, ValueError, PronetError):
                            failures = previous.get("failures", 0) + 1
                            row.update(state="UNCONFIRMED", failures=failures)
                            if failures == 3:
                                event(directory / "events.jsonl", "STANDBY_UNCONFIRMED", candidate)
                        health[candidate] = row
                    selected["standby_health"] = health
                    if selected["failures"] >= failover_probes() and not selected.get("auto_paused"):
                        switches = [t for t in selected.get("switches", []) if time.time() - t < 1800]
                        if len(switches) >= 3:
                            selected["auto_paused"] = True
                            selected["pause_id"] = secrets.token_hex(12)
                            event(directory / "events.jsonl", "RECOVERY_BUDGET_EXHAUSTED", "Automatic switches paused; use local repair after inspection")
                        else:
                            for candidate in selected["profiles"]:
                                if candidate == active:
                                    continue
                                try:
                                    # A missing/invalid standby record must not abort
                                    # the cycle before failures are persisted.
                                    other = self.validate(read_json(directory / candidate / "plan.json"))
                                    echo(engines.probe_address(other), other["token"], 3)
                                except (OSError, ValueError, KeyError, PronetError):
                                    continue
                                gateway = read_json(directory / "gateway.json")
                                # The primary failed three probes; sessions still
                                # bound to it are black-holed. The gateway closes
                                # them so clients reconnect through the standby.
                                gateway["failed_backends"] = [list(engines.data_address(plan))]
                                gateway["active_backend"] = list(engines.data_address(other))
                                gateway["mode"] = "plain" if PROFILES[candidate]["kind"] == "l3" else "framed"
                                gateway["frame_key"] = other["token"]
                                write_json(directory / "gateway.json", gateway)
                                selected.update(active=candidate, failures=0, switches=switches + [time.time()])
                                event(directory / "events.jsonl", "FAILOVER", active + " -> " + candidate)
                                break
                            else:
                                selected["auto_paused"] = True
                                selected["pause_id"] = secrets.token_hex(12)
                                event(directory / "events.jsonl", "NO_HEALTHY_STANDBY", "No measured fallback is reachable; heavy recovery stopped")
                    selected["utc"] = utc()
                    write_json(directory / "selection.json", selected)
            except (BlockingIOError, OSError, ValueError, KeyError, PronetError) as error:
                event(ROOT / "agent-events.jsonl", "WATCHDOG_ERROR", error)

    def execute(self, job):
        operation, payload = job["op"], job["payload"]
        pair_id = identifier(job["pair_id"])
        if operation == "inventory":
            return inventory()
        if operation in ("prepare", "start", "benchmark"):
            if payload.get("pair_id") != pair_id:
                raise PronetError("Job pair identity mismatch")
            if operation == "prepare":
                return self.prepare(payload)
            if operation == "start":
                return self.start(payload)
            return self.measure(payload)
        if operation in ("prepare_batch", "start_batch"):
            plans = payload.get("plans")
            if not isinstance(plans, list) or not 1 <= len(plans) <= MAX_BATCH:
                raise PronetError("Invalid carrier batch")
            if any(not isinstance(p, dict) or p.get("pair_id") != pair_id for p in plans):
                raise PronetError("Job pair identity mismatch")
            return self.prepare_batch(plans) if operation == "prepare_batch" else self.start_batch(plans)
        if operation == "probe_batch":
            return self.probe_batch(pair_id, payload.get("profiles"), payload.get("seconds", REACH_WAIT))
        if operation == "retire_batch":
            profiles = payload.get("profiles")
            if not isinstance(profiles, list):
                raise PronetError("Invalid retire batch")
            return self.retire_batch(pair_id, profiles)
        if operation == "commit":
            return self.commit(pair_id, payload["profiles"])
        if operation == "retire":
            if payload["profile"] not in PROFILES:
                raise PronetError("Unknown profile")
            if not (self.root / pair_id / payload["profile"] / "plan.json").exists():
                return {"retired": payload["profile"], "already_absent": True}
            self.remove_profile(pair_id, payload["profile"])
            return {"retired": payload["profile"]}
        if operation == "resume":
            profile = payload.get("profile")
            if profile not in PROFILES: raise PronetError("Unknown recovery profile")
            directory = self.root / pair_id / profile
            if (self.root / pair_id / "stopped.json").exists():
                raise PronetError("Operator removed this pair; automatic recovery refused")
            plan = self.validate(read_json(directory / "plan.json"))
            self.start(plan)
            for kind in ("engine", "echo"):
                name = unit_name(pair_id, profile, kind, plan["role"])
                service(name, "reset-failed")
                service(name, "restart")
            return {"resumed": profile}
        if operation == "remeasure":
            profile = payload.get("profile")
            if profile not in PROFILES: raise PronetError("Unknown recovery profile")
            plan = self.validate(read_json(self.root / pair_id / profile / "plan.json"))
            return self.measure(dict(plan, long_test=True))
        if operation == "activate":
            return self.activate(pair_id)
        if operation == "cleanup":
            return self.cleanup(pair_id)
        if operation == "status":
            return self.status(pair_id)
        raise PronetError("Unknown operation; no remote shell is available")
